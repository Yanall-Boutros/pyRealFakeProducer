\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Home Fries"
  composer = "Joshua Redman"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble_8"
    \key es \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              | es1:7 
      | es1:7 | s1 | s1 | s1 | aes1:7 | ges1:11+.9 | f1:7 | bes1:7 
      | es1:7 | s1 | aes1:7 | a1:dim | g2:min7 c2:7 | f2:min7 bes2:7 | es1:7 | s1 
      | s1 | s1 | s1 | s1 | aes1:7 | ges1:11+.9 | f1:7 | bes1:7 
      | es1:7 | s1 | aes1:7 | a1:dim | g2:min7 c2:7 | f2:min7 bes2:7 | es1:7 | s1 
      | s1 | s1 | s1 | s1 | aes1:7 | ges1:11+.9 | f1:7 | bes1:7 
      | es1:7 | s1 | aes1:7 | a1:dim | g2:min7 c2:7 | f2:min7 bes2:7 | es1:7 | s1 
      | s1 | s1 | s1 | s1 | aes1:7 | ges1:11+.9 | f1:7 | bes1:7 
      | es1:7 | s1 | aes1:7 | a1:dim | g2:min7 c2:7 | f2:min7 bes2:7 | es1:7 | s1 
      | s1 | s1 | s1 | s1 | aes1:7 | ges1:11+.9 | f1:7 | bes1:7 
      | es1:7 | s1 | aes1:7 | a1:dim | g2:min7 c2:7 | f2:min7 bes2:7 | es1:7 | s1 
      | s1 | s1 | s1 | s1 | aes1:7 | ges1:11+.9 | f1:7 | bes1:7 
      | es1:7 | s1 | aes1:7 | a1:dim | g2:min7 c2:7 | f2:min7 bes2:7 | es1:7 | s1 
      | s2 r4 s4|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 181
      \set Score.currentBarNumber = #0
     
      \bar "||" \mark \default r8 cis'8 ais8 dis8 a8 gis16 f16 dis4 
      \bar "||" \mark \default r2 \tuplet 3/2 {dis4 fis8} gis8. gis16~ 
      | gis8\glissando  a8 \tuplet 3/2 {gis4 fis8} gis4 \tuplet 5/4 {fis4 gis16~} 
      | gis8\glissando  a8 gis8 fis8 gis4~ \tuplet 6/4 {gis16 fis4 a16~} 
      | a16\glissando  ais8 cis'16\glissando  dis'4~ dis'16 d'8 cis'16~ cis'16 b8 gis16 
      | b8\glissando  c'8 f'4.^\markup{\left-align \small vib} r8 r4 
      | ais4 e'4.. d'16 dis'4~ 
      | dis'8 d'8 cis'8 c'8 ais8 a8 c16 dis8 g16 
      | f8 dis8 \tuplet 3/2 {a,8 c8 cis8} d4 \tuplet 3/2 {b4 a8} 
      | ais4^\markup{\left-align \small vib} r2 \tuplet 3/2 {gis'4 fis'8} 
      | g'4.^\markup{\left-align \small vib} r8 r4 f''8 e''8 
      | dis''4.^\markup{\left-align \small vib} r8 r4 \tuplet 3/2 {c''4 gis'8~} 
      | gis'8 fis'4 r8 r4 d'8 g'8~ 
      | g'8 ais'8 \tuplet 3/2 {gis'4 fis'8} \tuplet 3/2 {g'4 f'8} e'8 g'8 
      | f'8 g'8 gis'8 ais'8 fis'8 ais8 \tuplet 3/2 {d'4 dis'8~} 
      | dis'8 g'8 \tuplet 3/2 {fis'8 f'8 e'8} dis'8 d'8 cis'8 f8 
      | a8 c'8 b8 a8 ais8 gis8 f8. fis16~ 
      \bar "||" \mark \default fis4 g4 gis4 a4 
      | ais4 c'4 cis'4 \tuplet 3/2 {dis'4 dis'8\glissando } 
      | f'4.. cis'16~ cis'16 c'8 ais16 \tuplet 3/2 {a4 f8} 
      | \tuplet 3/2 {gis4 f8~} f16 fis8 g16~ g4 r4 
      | r4 r8. ais'16~ ais'4 r4 
      | r4 gis'8 fis'8 f'4 dis'8. f'16~ 
      | f'4 a4 r4 r8 dis'8 
      | d'8 ais'8 r2 \tuplet 6/4 {r4 r16 g''16~} 
      | g''8 r8 r4 \tuplet 3/2 {c''4 cis''8~} cis''8 r8 
      | r8 f'8 a'8 c''8~ c''16 b'8 e'16~ e'4 
      | ais'8 r8 r4 c'8. gis'16~ gis'8 r8 
      | r8. fis'16~ fis'16 a8 ais16 f'8. dis'16~ dis'8. fis16 
      | d'4 r4 \tuplet 3/2 {c'4 b8~} b16 c'8 ais16~ 
      | ais16 gis8 dis16~ dis8 c8 b,8 g8~ g8. f16~ 
      | f16 dis8 f16 \tuplet 3/2 {g4 ais8~} \tuplet 3/2 {ais8 e8 fis8} gis4 
      | \tuplet 3/2 {e'4 cis'8~} \tuplet 3/2 {cis'8 b8 a8} gis8 ais8~ \tuplet 3/2 {ais8 b8 cis'8~} 
      \bar "||" \mark \default cis'8 dis'8~ dis'16 c'8 cis'16 f'4 c''4~^\markup{\left-align \small vib} 
      | c''8 r8 r2 r8 a'16 ais'16 
      | c''8 cis''8~ cis''16 f'16 a'16 c''16~ \tuplet 3/2 {c''8 b'8 a'8} ais'8 gis'16 f'16~ 
      | \tuplet 3/2 {f'8 fis'8 g'8~} \tuplet 3/2 {g'8 dis'8 f'8} \tuplet 3/2 {cis'4 c'8} b8 ais8~ 
      | ais16 a8 g16~ \tuplet 3/2 {g8 gis8 f8~} f16 fis8 ais16~ \tuplet 3/2 {ais8 cis'8 dis'8} 
      | e'4 dis''4 d'8 dis'8~ dis'16 d''8 c''16~ 
      | c''8 ais'8 a'4~ a'16 dis'8 c'16~ c'16 gis8 f16 
      | cis'8 d'8 r2. 
      | \tuplet 6/4 {r4 r16 dis'16~} dis'4 \tuplet 3/2 {f'8\glissando  fis'8 dis'8~} dis'8 dis'8~ 
      | dis'8 r8 r4 ais'8 gis'8 dis'4 
      | r4 r8. c''16~ c''8 dis'4 dis'8~ 
      | dis'8 r8 r4 \tuplet 3/2 {r8 d''8 dis''8} c''8 d''8 
      | ais'8 g'4 f'8 e'8 cis'8 c'8 ais8 
      | g8 gis8 \tuplet 3/2 {c'8 dis'8 g'8} ais'8 fis'8 d'8 b8 
      | ais8 gis'8~ \tuplet 6/4 {gis'4~ gis'16 g'16~} g'8\glissando  gis'8 a'8 ais'8~ 
      | ais'8 r8 r4 ais'8 a'8 gis'8 cis''8 
      \bar "||" \mark \default fis'8 a'8 \tuplet 3/2 {c''4 a'8} b'4 g'8 ais'8 
      | \tuplet 3/2 {e'4 gis'8~} gis'16 fis'8 d'16~ \tuplet 6/4 {d'8 fis'8 e'16 d'16~} d'16 b8 a16~ 
      | \tuplet 3/2 {a8 b8 cis'8} a8 ais4 f8 \tuplet 6/4 {gis8. ais8 g16~} 
      | g8 dis8 \tuplet 6/4 {cis8. ais,8 a,16~} a,8. b16~ b8 dis8~ 
      | dis8 r8 r4 r16 fis8 a16 \tuplet 3/2 {cis'8 f'8 e'8} 
      | dis'16 cis'16 c'16 ais16 \tuplet 3/2 {gis8 g8 fis8} \tuplet 3/2 {f8 e8 d8} \tuplet 6/4 {dis8 cis8 c16 ais,16~} 
      | ais,16 a,16 g16 dis16 cis8 f16 e16 \tuplet 3/2 {dis8 f8 dis8} f16 gis16 c'16 fis16~ 
      | fis16 g16 ais16 a16 \tuplet 3/2 {gis8 ais8 c'8} fis'16 g'16 ais'16 f'16 \tuplet 6/4 {fis'8 d'16 b16 a8} 
      | ais8 r8 r4 r8 fis8 g16 ais16 cis'16 f'16 
      | c'8 dis'8~ \tuplet 3/2 {dis'8 d'8 c'8} cis'8 dis'8 f'8 gis'8 
      | c''4. f'8 f'8. f'16~ f'8 f'8~ 
      | f'8. fis'16~ fis'8 r8 \tuplet 6/4 {r4 r16 d''16~} d''4~ 
      | d''8 g'8 ais'8 gis'8 g'8 f'8 \tuplet 3/2 {e'4 g'8} 
      | f'8 g'4 a'8 \tuplet 3/2 {ais'4 gis'8~} \tuplet 3/2 {gis'8 a'8 g'8} 
      | g'8 dis'8 \tuplet 3/2 {fis'8 f'8 d'8} dis'8 c'8 gis8 f8 
      | g8 ais8 r4 ais8. c'16 \tuplet 3/2 {dis'4 fis'8} 
      \bar "||" \mark \default g'8. fis'16~ fis'4 dis'4 c'4~^\markup{\left-align \small vib} 
      | c'4 \tuplet 6/4 {r4 r16 ais'16~} ais'8 gis'8 fis'16 dis'8 dis'16~ 
      | dis'4 dis'4 fis'8 g'8 r4 
      | r2 ais8 c'8 dis'8. f'16~ 
      | f'8 dis'8 fis'8. dis'16~ dis'4 c'4 
      | f''4 fis''8 dis''8 cis''8 ais'16 gis'16~ gis'8 fis'8 
      | \tuplet 6/4 {gis'4 g'16 gis'16~} gis'8 fis'8 \tuplet 3/2 {gis'4 gis'8} fis'8 ais'8~ 
      | ais'8. b''16~ b''8 a''4 gis''8~ gis''8. fis''16 
      | g''8 dis''8 f''8 c''8 c''8 ais'8 a'8. dis''16~ 
      | dis''8 b'8 g'8 e'8 dis'8 cis'8 ais8 b8 
      | c'8. b'16~ b'8 c''8 gis'8. gis'16 r4 
      | r8 c''4\glissando  d''8 gis'4 cis''8.\glissando  dis''16~ 
      | dis''16 d''8 c''16~ c''16 ais'8 gis'16 g'8 f'8 e'8 g'8~ 
      | g'16 f'8 g'16 gis'8 a'8 ais'8 c''8 d''8 f''8 
      | d''8 dis''4. \tuplet 3/2 {f''8 g''8 ais''8} c'''8. cis'''16\glissando  
      | d'''8 r8 r8 ais''8 a''8 fis''8 dis''8. dis''16~ 
      \bar "||" \mark \default dis''4 dis''4 r4 dis''8 dis''8 
      | dis''16 dis''16 dis''8 \tuplet 3/2 {dis''8 dis''8 dis''8} \tuplet 3/2 {fis''8 g''4} \tuplet 6/4 {r4 r16 dis''16~} 
      | dis''4 dis''4..\bendAfter #-4  dis''16 dis''8 dis''8 
      | dis''16 dis''8 dis''16~ dis''16 dis''16 dis''16 dis''16 \tuplet 3/2 {gis''8\glissando  ais''16 r8.} \tuplet 6/4 {r4 r16 dis''16~} 
      | \tuplet 6/4 {dis''4~ dis''16 dis''16~^\markup{\left-align \small vib}} dis''4 r2 
      | c'''4 ais''8 a''8 fis''8 fis''8 f''16 e''8. 
      | \tuplet 3/2 {dis''4 c''8} \tuplet 3/2 {ais'4 f'8~} f'16 b'16 gis'16 f'16 dis'8 b8 
      | d'8 f'8 gis'8 c''8~ c''16 d''16\glissando  dis''8 d''8 c''8 
      | ais'8 g'8~ g'16 a'16 gis'16 fis'16 g'4 \tuplet 3/2 {f'4 cis'8~} 
      | cis'16 ais8 f16~ f16 gis8 g16~ g8 r8 r8 a'8\glissando  
      | ais'4 \tuplet 3/2 {gis'4 fis'8} dis'8. c'16~ c'8 fis'8~^\markup{\left-align \small vib} 
      | fis'8 r8 r4 r8 dis'8~ dis'16 a'16 ais'16 cis''16 
      | a'8 r8 r8 dis'8 \tuplet 3/2 {a'8 ais'8 c''8} a'16 gis'16 fis'16 gis'16~ 
      | gis'16 fis'16 dis'8 \tuplet 3/2 {cis'8 ais8 a8} gis16 fis8 dis16 \tuplet 3/2 {gis8 dis8 fis8} 
      | \tuplet 3/2 {g8 ais8 c'8} dis'8. e'16\glissando  f'8 dis'8 \tuplet 3/2 {cis'8 ais8 fis8} 
      | gis16 a16 gis16 fis16 dis8 gis8 fis4 \tuplet 3/2 {b,8 c8 dis8~} 
      \bar "||" dis8 c16 b,16 ais,4 r2\bar  ".."
    }
    >>
>>
}
