\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Six Cats and a Prince"
  composer = "Lester Young"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble_8"
    \key bes \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              
      | bes1:maj | bes1:maj | b1:dim | s1 | c1:min7 | f1:7 | bes1:maj | f1:7 
      | bes1:maj | s1 | b1:dim | s1 | c1:min7 | f1:7 | bes1:maj | s1 
      | bes1:7 | s1 | es1:7 | s1 | c1:7 | s1 | f1:7 | s1 
      | bes1:maj | s1 | b1:dim | s1 | c1:min7 | f1:7 | bes1:maj | f1:7 
      | bes1:maj | s1 | b1:dim | s1 | c1:min7 | f1:7 | bes1:maj | f1:7 
      | bes1:maj | s1 | b1:dim | s1 | c1:min7 | f1:7 | bes1:maj | s1 
      | bes1:7 | s1 | es1:7 | s1 | c1:7 | s1 | f1:7 | s1 
      | bes1:maj | s1 | b1:dim | s1 | c1:min7 | f1:7 | bes1:maj | f1:7|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 220
      \set Score.currentBarNumber = #1
     
      \bar "||" \mark \default g4 f4 g4 f8 g8~ 
      | g4. f8 g4. f8 
      | gis4. f8 gis8. f16~ f8 gis8~ 
      | gis4 f4 gis4 f4 
      | g4 r2 r8 g8 
      | fis8 ais8 \tuplet 3/2 {cis'4 d'8} dis'8 e'8~ e'16 f'16 g'16 f'16 
      | cis'8. d'16~ d'4 ais8 g8 r4 
      | r8 f16 ais16~ ais8 ais4 a8 g4 
      \bar "||" c'4 \tuplet 3/2 {ais4 g8} fis8 f8 g4 
      | c'4. ais8 g8 fis8 g4 
      | gis4 r2 r8 ais8 
      | b4. d'4. b4 
      | c'4 b8. g16~ g2 
      | dis4 fis4 r2 
      | \tuplet 3/2 {f4 ais8~} ais4 f2 
      | f8 ais8 r2 r8 g8 
      \bar "||" \tuplet 3/2 {gis4 c'8} d'8 g'8~ g'16 f'8 c'16~ c'16 gis8 fis16 
      | g4. gis8 c'8 dis'8 f'8 r8 
      | r2 \tuplet 3/2 {fis4 g8~} \tuplet 3/2 {g8 ais8 d'8} 
      | \tuplet 3/2 {dis'4 f'8~} f'8 g'8 f'16 d'8 dis'16~ dis'8 d'8~ 
      | \tuplet 6/4 {d'16 ais4 f16~} f8 f8~ \tuplet 6/4 {f16 g4 d'16~} d'8. a16 
      | d4 \tuplet 3/2 {e8 f8 a8~} a8 c'8~ c'8. g16~ 
      | g2 d16 dis8 f16 \tuplet 3/2 {fis4 dis8} 
      | f4. r8 r4 c'4\bendAfter #+4  
      \bar "||" cis'8. c'16~ c'2 ais8. c'16~ 
      | c'8 d'8 r2 r8. e'16~ 
      | e'8. f'16~ f'4 \tuplet 3/2 {d'4 dis'8} e'8 f'8 
      | \tuplet 6/4 {d'8. b8 gis16~} gis8 f8 d8. c16~ c8. dis16~ 
      | dis2 fis8 g4 f8~ 
      | f4 r2 r8 ais8~ 
      | ais2 ais4. ais8~ 
      | ais4 \tuplet 3/2 {g4 ais8} \tuplet 3/2 {cis'4 d'8} dis'8 e'8 
      \bar "||" \mark \default \tuplet 3/2 {f'8 g'8 f'8} cis'16 d'8 dis'16 e'8. f'16~ \tuplet 6/4 {f'8. gis'16 fis'16 f'16} 
      | cis'4 d'16 dis'8 e'16~ e'16 f'8 fis'16 f'16 d'8 dis'16~ 
      | dis'16 e'8 f'16 r4 r8 d'8 dis'8 e'16 f'16~ 
      | f'16 fis'16 g'16 gis'16~ gis'8. g'16 fis'16 g'16 fis'16 f'16 d'4 
      | dis'2~ dis'8. g16~ g8 fis8~ 
      | fis4. f8~ f4. ais8~ 
      | ais8 r8 r2 ais,4 
      | b,2.. ais,8~ 
      \bar "||" ais,8 ais4. g4 r4 
      | r8. f16 \tuplet 3/2 {g4 ais8} cis'8 d'8 dis'8 e'8 
      | \tuplet 3/2 {fis'8 g'8 f'8} \tuplet 3/2 {d'4 b8~} b4. gis8 
      | e8 b,8~ b,2~ b,8 r8 
      | r4 r8 c8 \tuplet 3/2 {dis4 ais8} \tuplet 3/2 {c'8 d'8 e'8} 
      | g'8 ais'8 b'16 c''8.~ c''4. g'8~ 
      | g'8. ais'16~ ais'4. g'4. 
      | r2. r8 d'8 
      \bar "||" dis'8 e'16 f'16~ \tuplet 6/4 {f'8 fis'16 g'16 gis'16 a'16} ais'16 c''8.~ c''8 c'16 g'16 
      | \tuplet 3/2 {gis'4 ais'8~} ais'4 g'8. gis'16~ gis'4~ 
      | gis'16 d'16 dis'16 e'16 f'8 fis'16 g'16~ g'2 
      | \tuplet 3/2 {d'8 dis'8 e'8} f'4~ f'16 c'16 cis'8 dis'4 
      | d'8 r8 r4 r16 cis16 dis16 e16 f8 fis16 g16 
      | gis16 a8 d'16~ d'4 a8 cis'4. 
      | \tuplet 3/2 {g8 c'4~} c'4~ c'16 fis8 c'16~ c'4~ 
      | \tuplet 3/2 {c'8 fis8 c'8~} c'4 f4. r8 
      \bar "||" r4 r8. f16 g8 c'8~ \tuplet 3/2 {c'8 g8 f8~} 
      | f16 g8 c'16~ c'8 g16 f16 g8 f8~ f16 g8 f16 
      | gis8 f8 gis8 f8~ f16 gis8 d'16~ d'16 gis8 f16~ 
      | f16 gis8 f16 gis8 d'8 gis8 f8 gis8. f16 
      | g4 r4 r8. g16~ g16 c8 d16 
      | dis8 e8 \tuplet 3/2 {f8 fis4~} fis4~ fis16 f8 ais16~ 
      | ais4~ ais16 g8 a16~ a16 cis'8 d'16 dis'8 e'8 
      | f'8 g'16 f'16~ \tuplet 3/2 {f'8 dis'8 f'8} dis'8 cis'16 d'16~ d'4\bar  ".."
    }
    >>
>>
}
