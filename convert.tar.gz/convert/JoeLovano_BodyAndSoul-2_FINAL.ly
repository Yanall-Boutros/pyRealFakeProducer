\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Body and Soul (Solo 2)"
  composer = "Joe Lovano"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble_8"
    \key des \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              | s2 e4:min7 a4:7 
      | d2:maj e2:min7 | d2:/fis g4:min7 c4:7 | fis4:min7 b4:min7 e4:min7 a4:7 | d1:maj | d2:min7 g2:7 | c2:maj es2:dim | d2:min7 g2:7 | c4:7 b4:7 bes2:7 
      | es2:min7 bes2:9- | es2:min7 d2:7 | des2:maj ges2:7 | f2:min7 e2:dim7 | es1:min7 | c2:min5-7 f2:7 | bes4:min7 es4:7 es4:min7 aes4:7 | des2:6 bes2:7 
      | r1|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 60
      \set Score.currentBarNumber = #0
     
      \bar "||" \mark \default r2 r8. fis16 \tuplet 3/2 {a8 g8 cis'8} 
      \bar "||" \mark \default a16 e'16. fis'16 a'32~ \tuplet 5/4 {a'8 b'16\bendAfter #+4  cis''16 a'16} c''16\bendAfter #+4  cis''16 a'16 a'16 \tuplet 3/2 {a'8 fis'8 f'8~} 
      | \tuplet 6/4 {f'16 fis'8. cis'16 e'16} \tuplet 6/4 {d'16 e'16 fis'4~} \tuplet 14/16 {fis'16~ fis'64 fis'64 g'64~ g'16 a'32 ais'64} c''16 a'8 ais'16 
      | a'4~^\markup{\left-align \small vib} \tuplet 12/8 {a'16. c''32\glissando  cis''16. g'8 fis'32~} \tuplet 9/8 {fis'16. e'8\bendAfter #+4  a'32 b'32~^\markup{\left-align \small vib}} b'4~ 
      | b'16 a'8 fis'4. e'8 cis'16~ \tuplet 6/4 {cis'8 a8 gis16\bendAfter #+4  a16~} 
      | a16 g8 f16~ f8 g8 \tuplet 3/2 {g8 e8 d8} b,8 d8 
      | a,8..^\markup{\left-align \small vib} a32~ \tuplet 3/2 {a8 fis8 g8~^\markup{\left-align \small vib}} \tuplet 6/4 {g8. a16 ais16 e'16} \tuplet 6/4 {f'16 a'8 c''16 cis''16 ais'16~} 
      | ais'32 f'16 ais'32 a'16. e'32~ \tuplet 6/4 {e'16 g'8 f'8 a16~} a8 e'8 \tuplet 3/2 {d'4 b8} 
      | g4 fis4 f8 ais4.^\markup{\left-align \small vib} 
      \bar "||" r4 \tuplet 7/8 {r16. dis16 f32 dis32~} \tuplet 6/4 {dis16 f16 dis16 f16 dis16 f16} \tuplet 5/4 {dis16 f16 dis16 d16 dis16} 
      | f16 dis16 ais,16\bendAfter #+4  g32 ais32~^\markup{\left-align \small vib} ais4~ \tuplet 9/8 {ais16 d32 e32 fis32 ais32 a32 gis32 c'32} gis32 ais32 c'32 e'32 fis'32 gis'32 c''32 fis'32 
      | \tuplet 3/2 {gis'8 f'4~^\markup{\left-align \small vib}} f'4~ f'16 dis'16 cis'16 c'16 \tuplet 3/2 {dis'8 f'8 gis'8} 
      | \tuplet 3/2 {ais'8\bendAfter #+4  c''4~^\markup{\left-align \small vib}} \tuplet 3/2 {c''8 gis'8 gis'8} gis'16 b'16\bendAfter #+4  cis''16 b'16~^\markup{\left-align \small vib} \tuplet 6/4 {b'4~ b'16 cis''16} 
      | dis''16 ais'8.~^\markup{\left-align \small vib} ais'4. cis''16 ais'16 \tuplet 3/2 {fis'8 g'8\bendAfter #+4  gis'8} 
      | f'4~^\markup{\left-align \small vib} \tuplet 14/16 {f'16. c'32 cis'64 dis'64 g'64 a'64 b'64 g'64} \tuplet 12/8 {gis'32 a'16 c'32 dis'32 g'32 e'32 f'32 fis'32 a'32 fis'32 f'32} \tuplet 10/8 {e'32 dis'32 a'32 f'32 cis'32 c'32 ais32 f32 gis32 a32} 
      | \tuplet 7/8 {dis'32 c'32 ais32 g32 dis32 g32\bendAfter #+4  a32} fis32 dis32 c32 ais,32 a,8~ \tuplet 6/4 {a,8 dis'16\bendAfter #+4  f'8 ais16} cis'8 cis'8~^\markup{\left-align \small vib} 
      | cis'16 dis'16 f'16 fis'16~ fis'32. gis'16. gis'32. b'32. a'64~ \tuplet 14/16 {a'32. dis''32~ dis''8 b'64~} b'8. a'16~^\markup{\left-align \small vib} 
      \bar "||" a'1~ 
      | \tuplet 5/4 {a'16 gis'16 f'16 c''16 gis'16} \tuplet 6/4 {f'8 gis'16 fis'8 ais16} \tuplet 3/2 {f'8 dis'8 e'8~} e'8 c'8 
      | cis'16\bendAfter #+4  dis'8.~^\markup{\left-align \small vib} dis'8 c'8~^\markup{\left-align \small vib} c'2~ 
      | c'1~ 
      | c'2. r4\bar  ".."
    }
    >>
>>
}
