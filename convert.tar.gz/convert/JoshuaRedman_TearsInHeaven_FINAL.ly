\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Tears in Heaven"
  composer = "Joshua Redman"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble_8"
    \key bes \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              | s2 r2 
      | bes2 f2:/a | g2:min g2:min/f | es2:/g bes2:/f | f2. f4:7 | bes2 f2:/a | g2:min g2:min/f | es2:/g bes2:/f | f2 fis2:dim 
      | g1:min | d1:/fis | f1:min | g1:7 | c1:min | f1:sus4 | bes2 f2:/a | g2:min g2:min/f 
      | es2:/g f4:sus4 f4 | bes2 aes4:7sus4 aes4:7 | des2 c2:dim | bes2:min es2:/g | aes2 es4:/g c4 | f2:min aes2 | des2 c2:dim | bes2:min es2:/g 
      | aes2 g2:dim | f1:7 | bes2 f2:/a | g2:min g2:min/f | es2:/g f2:sus4 | f1 | bes2 f2:/a | g2:min g2:min/f 
      | es2:/g f2:sus4 | f2. fis4:dim | g1:min|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 84
      \set Score.currentBarNumber = #0
     
      \bar "||" \mark \default r2 r8.. c'32~ c'16 d'16 dis'16 f'16 
      \bar "||" \mark \default e'16 d'8.~ \tuplet 5/4 {d'8 g16 ais16 c'16~} c'16 d'16 d'16 ais16 e'16 f'16 f'16 g'16 
      | d'8 d'8~ d'8. c'16 ais16 c'16 f16 ais16 g16 d16 f32 g32 f32 d32 
      | dis8 r8 r8 dis'16 g'16 ais'16 c''16 d''16 dis''16 d''16 c''16 ais'16 g'16 
      | \tuplet 6/4 {c''16 cis''16 d''8 ais'8~} \tuplet 10/8 {ais'32 c''8 a'16 f'32 c'32 a32~} a32 f32 dis'16 d'32 ais32 g32 d32 \tuplet 6/4 {f16 d16 dis16 d'16 cis'16 gis16} 
      | \tuplet 7/8 {f32 c'32 a32 ais32 d'32 f'32 a'32} \tuplet 10/8 {c''16 ais'32 g'16 dis'32 ais16 g32 d'32~} d'32 f'32 c'16 gis32 f32 ais32 g32~ \tuplet 10/8 {g32 dis32 c16 fis16 d16 c32 ais,32~} 
      | ais,8 r8 r4 d'16\bendAfter #-4  cis'32 c'32 ais32 g16.~ g8 ais8~ 
      | ais4 dis'16\bendAfter #-4  d'16 cis'16 g16~ g8 ais8~ \tuplet 5/4 {ais8 dis'16 d'16 c'16} 
      | \tuplet 5/4 {ais16 a16 f16 a16 c'16} g16 fis16 f16 dis16 d16 fis16 a16 c'16 dis'16 fis'16 d'16 c'16 
      \bar "||" ais4.. d16 ais8 ais16 ais16 \tuplet 3/2 {ais8 ais8 c'8} 
      | \tuplet 10/8 {a8 a16. g16 a32~} \tuplet 3/2 {a8 a8 g8} \tuplet 3/2 {a8 a8 fis8} a8 a16 d16 
      | r4 r8. d16 \tuplet 3/2 {gis8 gis8 g8} gis8 gis16 ais16 
      | \tuplet 3/2 {g8 g8 fis8} g8 g16 f16 \tuplet 3/2 {g8 dis8 g8} \tuplet 6/4 {c'8 cis'16 d'8 dis'16~} 
      | dis'2. \tuplet 7/8 {d'16 g'32 fis'32 cis'32 c'32 ais32} 
      | c'8 a16 ais16 c'8 gis16\bendAfter #+4  a16~ a8 f16 fis16 f16 d16 dis16 cis16 
      | \tuplet 6/4 {d8 ais8 a16 d16} dis16 c'8.~ \tuplet 10/8 {c'8.. f16 g32~} g16 d'16 a16 ais16 
      | g'8 ais16 c'16 \tuplet 6/4 {a'16 gis'16 c'16 d'16 ais'16 a'16} d'16 g'16 d''8 a'16 c''16 ais'8~ 
      | ais'16. d''32 dis''16. d''32~ d''16 ais'16 g'16 dis'16~ dis'32 c''32 cis''32 d''32 c''16 ais'32 b'32~ b'32 a'32 g'16 f'16 dis'32 d'32~ 
      | d'16 ais16 f16 dis32 d32~ \tuplet 6/4 {d16 c'16 cis'16 d'16 ais16 f16} \tuplet 10/8 {cis'8 ais16 fis32 dis16 c'32~} c'16 ais16 gis16 fis16 
      \bar "||" f4~ f16 e'16 f'16 f'16 dis'4 cis'16 c'16 ais8~ 
      | \tuplet 6/4 {ais4~ ais16 f16} cis'8 cis'16 ais16 \tuplet 6/4 {cis'16 d'16 dis'4} ais8 ais16 f16 
      | c'4. r8 r8. g'16~ \tuplet 5/4 {g'16 ais'16 gis'16 g'16 f'16} 
      | e'16 f'16 g'16 gis'16 f'16 c'16 gis16 f16~ \tuplet 5/4 {f16 dis'16 e'16 c'16 a16~} \tuplet 6/4 {a16 gis16 fis16 f16 gis16 g16} 
      | dis16 cis8. e'16 f'8 f'16 dis'4 cis'16 c'16 ais8~ 
      | ais4~ \tuplet 6/4 {ais8 cis'8 ais16 d'16} dis'8. cis'16 \tuplet 6/4 {d'16 dis'16 cis'8 ais16 c'16~} 
      | c'2. c'16 dis'16 f'16 g'16 
      | gis'16 a'16 ais'16 c''16 \tuplet 6/4 {g'8. f'8 g'16\bendAfter #-4 } fis'16 f'8. g'16 ais'16 c''8 
      \bar "||" \mark \default \tuplet 3/2 {b'8\bendAfter #+4  c''8\bendAfter #+4  cis''8\bendAfter #+4 } \tuplet 3/2 {d''8 cis''8 ais'8} dis''16 e''16 f''8 \tuplet 6/4 {g''8. c''16 cis''16\bendAfter #+4  d''16~} 
      | d''4~ d''16. cis''32 c''32 b'32 ais'32 c''32~ c''16 g'16 a'16 ais'16 \tuplet 5/4 {g'16 f'16 cis'16 c'16 ais16} 
      | g8 ais4. cis''16\bendAfter #+4  d''16 dis''8 d''16 c''16 ais'16 g'16 
      | c''16 d''16 dis''16 c''16~ c''8~ c''32 b'32 a'32 g'32~ \tuplet 10/8 {g'32 f'16 e'16 dis'16 d'16 c'32~} c'16 ais16 a16 g16 
      | \tuplet 11/8 {f16. dis16 d16. f16 ais32~} ais16 d'16 ais16 g16 f'16 d'16 ais16 f16 c'16 d'16 ais16 d16 
      | g4 r4 r8 g16 ais16 \tuplet 3/2 {c'8 d'8 c'8} 
      | d'16 dis'8. \tuplet 6/4 {d'16 dis'8. d'16 dis'16~} dis'16 d'32 dis'8 d'32~ d'16 c'16 ais16 g16 
      | d'16 dis'16 c'8 c'2 a16 fis16 d16 c16 
      \bar "||" g4 r2.\bar  ".."
    }
    >>
>>
}
