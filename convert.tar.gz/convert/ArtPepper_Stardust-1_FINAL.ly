\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Stardust"
  composer = "Art Pepper"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble_8"
    \key es \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              | s2. r4 
      | aes1:6 | aes1:6 | aes1:min6 | s2 des2:7 | es2 f2:min7 | g2:min7 c2:7 | f2.:min7 e4:dim7 | f1:min7 
      | bes2:7 bes2:dim | f2:min7 bes2:7 | es1:maj | g2:min7 c2:min7 | f1:9 | c2:min7 f2:7 | bes2:7 bes2:7sus4 | bes2:dim7 bes4:7 es4:775+ 
      | aes1:6 | s1 | aes1:min6 | s2 des2:7 | es1 | g2:min7 c2:7 | f2.:min7 e4:dim | f1:min7 
      | aes1:min7 | des1:13.9 | es2:maj c2:min7 | g2:min7 c2:7 | f1:min7 | bes1:7 | es1:6 | bes2:min7 es2:7 
      | aes1:6 | s1 | aes1:min6 | s2 des2:7 | es1 | g2:min7 c2:7 | f2.:min7 e4:dim7 | f1:min7 
      | bes2:7 bes2:dim | f2:min7 bes2:7 | es1 | c2:min7 g2:min7 | f1:9 | c2:min7 f2:7 | bes2:7 bes2:7sus4 | bes2:dim7 bes2:7 
      | aes1:6 | s1 | aes1:min6 | s2 des2:7 | es1:6 | g2:min7 c2:7 | f1:min7 | s1 
      | aes1:min7 | des1:7 | es2:maj c2:min7 | g2:min7 c2:7 | f1:min7 | bes1:7 | es1:maj | bes2:min7 es2:7 
      | aes1:6|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 61
      \set Score.currentBarNumber = #0
     
      \bar "||" \mark \default r2. \tuplet 3/2 {r8 d'8 dis'8~} 
      \bar "||" \mark \default dis'16 e'16 c'16 f'16~^\markup{\left-align \small vib} f'8 dis'8 c'4~^\markup{\left-align \small vib} \tuplet 6/4 {c'4 g16 gis16} 
      | f2^\markup{\left-align \small vib} r4 r8 gis32 c'16 dis'32~ 
      | \tuplet 6/4 {dis'4~ dis'16 dis'16~} \tuplet 6/4 {dis'16 f'16\glissando  g'16 f'16\glissando  g'8~^\markup{\left-align \small vib}} g'4.. fis'16~ 
      | fis'8 f'4^\markup{\left-align \small vib} dis'16 b16 \tuplet 3/2 {gis8 g8 f8~} f8 r8 
      | \tuplet 14/16 {r8. fis64 g64~} \tuplet 6/4 {g16 ais16 c'16 ais16 dis'8} dis'4.^\markup{\left-align \small vib} r8 
      | r4 r16 d'16 g'8~ g'16 d'16 ais16 g16~ g8 cis'8 
      | r4 \tuplet 5/4 {r8 c'16 dis'16 c'16} gis8 ais8~ ais16 g16 gis16 g16 
      | fis16 f8.~^\markup{\left-align \small vib} f4 r4 r16 g16 f16 e16 
      | f16 ais16 gis16 ais16~^\markup{\left-align \small vib} ais4 r2 
      | \tuplet 6/4 {r16 dis16 d8. ais16} gis4 d'32 cis'32 b32 ais16. gis32 fis32~ \tuplet 6/4 {fis8 gis16 ais16 gis16 cis'16~} 
      | cis'4 ais16 g32 a32 c'16 g32 ais32 c'8^\markup{\left-align \small vib} r8 r4 
      | r4 \tuplet 3/2 {ais8 c'8 ais8~} ais16 ais16 dis'16 f'16 \tuplet 6/4 {cis'16 d'16 ais4~^\markup{\left-align \small vib}} 
      | \tuplet 6/4 {ais8. c'16 dis'16 f'16~} \tuplet 6/4 {f'16 dis'16 f'16\glissando  g'8.~} \tuplet 7/8 {g'8 f'32 dis'32 c'32~^\markup{\left-align \small vib}} c'8 r8 
      | r4 \tuplet 3/2 {d'8\glissando  fis'8 g'8} d'16 ais16 cis'8~ \tuplet 3/2 {cis'8 g'8 cis'8} 
      | r4 r8 ais8~ \tuplet 10/8 {ais32 ais8.. b32 c'32} f'8 b8 
      | a16 ais8.~^\markup{\left-align \small vib} ais8 r8 r4 \tuplet 6/4 {r8 d'8 dis'16 e'16~} 
      \bar "||" e'16 dis'16 f'4^\markup{\left-align \small vib} dis'8 c'4~^\markup{\left-align \small vib} \tuplet 6/4 {c'4 g16 gis16} 
      | f4.^\markup{\left-align \small vib} r8 r4 r16 gis16 c'16 dis'16~ 
      | \tuplet 6/4 {dis'4~ dis'16 c'16\glissando } \tuplet 6/4 {gis'16 ais'16\glissando  gis'16 ais'8.~} ais'8. gis'32 ais'32 \tuplet 6/4 {gis'16 fis'16 gis'8.^\markup{\left-align \small vib} fis'16} 
      | \tuplet 3/2 {dis'8 cis'8 dis'8~^\markup{\left-align \small vib}} dis'8 r8 r8. gis16 \tuplet 6/4 {c'16 dis'16 fis'16 dis'16 gis'16 fis'16} 
      | \tuplet 5/4 {dis'16 d'16 f'16\glissando  g'16 ais'16~^\markup{\left-align \small vib}} ais'4. r8 \tuplet 15/16 {r8. g'32 ais'64~} 
      | ais'8. g'32 ais'32 \tuplet 3/2 {d''8 d''8 g'8~} \tuplet 6/4 {g'16 ais'16 c''16 ais'16 c''16\glissando  cis''16~} cis''4 
      | c''2~^\markup{\left-align \small vib} c''8 dis''16 c''16~ c''32 gis'16 ais'16. g'32\glissando  gis'32 
      | f'4.^\markup{\left-align \small vib} r8 r8. g'16 \tuplet 9/8 {f'32 e'8 g'16 f'32 e'32~} 
      | e'32 f'32~ f'8 gis'32\glissando  ais'32~ \tuplet 6/4 {ais'4 a'16 dis'16} gis'4^\markup{\left-align \small vib} r4 
      | r4 r8 ais'16 gis'16~ gis'8 cis''16 ais'16~^\markup{\left-align \small vib} \tuplet 7/8 {ais'16 gis'32 fis'32 dis'32 ais32 gis32} 
      | g4.^\markup{\left-align \small vib} ais8 dis'8^\markup{\left-align \small vib} r8 \tuplet 14/16 {r8 r32 g'64 gis'64 ais'64 d''64} 
      | f''16 d''8.~^\markup{\left-align \small vib} d''8 r8 \tuplet 7/8 {r16. b'32 cis''32 c''32 c''32~} c''4 
      | dis''8^\markup{\left-align \small vib} r8 r4 \tuplet 6/4 {r8 c''16 gis'16 ais'16 g'16} gis'8^\markup{\left-align \small vib} r8 
      | r4 g'16 a'16\glissando  ais'8~ \tuplet 6/4 {ais'16\glissando  fis'16 g'16 gis'8 g'16~} g'32 dis'32 ais32 gis16. ais32 gis32 
      | \tuplet 12/8 {fis32 g8.. g32\glissando  a32 dis'32 ais32} cis'16 dis'4.^\markup{\left-align \small vib} ais16 gis16 dis'8.^\markup{\left-align \small vib} 
      | r8.. g32~ \tuplet 10/8 {g8 g32 gis32 ais32 fis32 g32 a32} \tuplet 12/8 {cis'16 f'32 e'16 d'32 dis'16. cis'32 dis'32 d'32} \tuplet 10/8 {cis'32 d'32 f'32 gis'32 c''32 ais'32 b'32 g'32 dis'32 d'32} 
      \bar "||" \mark \default \tuplet 6/4 {cis'16 f'16\glissando  e'16 c'16 dis'8~^\markup{\left-align \small vib}} dis'8 r8 r8. dis'16 f'8. fis'16 
      | f'16 dis'8.~ \tuplet 6/4 {dis'16 dis'16 gis'16 ais'16 b'16\glissando  c''16~} \tuplet 9/8 {c''8~ c''32 gis'16. dis'32} \tuplet 3/2 {ais'8 gis'8 gis'8~^\markup{\left-align \small vib}} 
      | \tuplet 6/4 {gis'4 b'16 ais'16} gis'4 \tuplet 6/4 {r8. b'16 ais'16 gis'16} dis''4~^\markup{\left-align \small vib} 
      | dis''4. cis''8\bendAfter #+4  b'32 cis''32~ cis''8 ais'32 c''32 \tuplet 6/4 {ais'16 gis'16 ais'8.^\markup{\left-align \small vib} gis'16} 
      | ais'16 fis'16\glissando  g'8~^\markup{\left-align \small vib} g'2 \tuplet 5/4 {ais16 c'16 dis'16 f'16 g'16} 
      | ais'16 d''16 ais'16 d''16~^\markup{\left-align \small vib} d''8 r8 \tuplet 12/8 {r4 f'32\glissando  g'16 ais'32} c''16 ais'16\glissando  c''16 cis''16 
      | \tuplet 3/2 {c''8 f'8 f'8~^\markup{\left-align \small vib}} f'8 r8 r8.. c'32 \tuplet 3/2 {e'8 c''4~^\markup{\left-align \small vib}} 
      | c''8. c'16 g'32 gis'32 g'32 f'32 g'8^\markup{\left-align \small vib} r4 r8 c'16 d'16~ 
      | \tuplet 6/4 {d'4 ais16 d'16} cis'16\glissando  d'16 f'8 \tuplet 6/4 {r4 r16 ais16} \tuplet 3/2 {c'8 dis'8 g'8} 
      | \tuplet 3/2 {ais'8 gis'8 c'8} \tuplet 9/8 {c'8.^\markup{\left-align \small vib} g'32 gis'32 g'32~} \tuplet 10/8 {g'16 fis'8. d'32 ais32} \tuplet 3/2 {gis8 ais4^\markup{\left-align \small vib}} 
      | r4 \tuplet 10/8 {r8. ais32 c'32 d'32 f'32} \tuplet 10/8 {d'32 dis'32 d'32 g'32 gis'32 ais'32 fis'32 g'32 gis'32 ais'32} \tuplet 10/8 {d''32 c''16 d''32 c''32 ais'32 g'16 d'32 ais32} 
      | f'16 ais'16 f'8^\markup{\left-align \small vib} r4 \tuplet 12/8 {r8.. g'32 gis'32 f'32 dis'32\glissando  e'32} \tuplet 12/8 {g'32 ais'32 cis''32 c''32 b'32 c''32 d''32 g''32 e''32 f''16.} 
      | r4 r8 c'''4^\markup{\left-align \small vib} g''8 \tuplet 6/4 {f''8 f''8.^\markup{\left-align \small vib} dis''16~} 
      | \tuplet 10/8 {dis''8.. d''32 e''32 d''32} c''16 d''8 g''16 cis''16\glissando  d''8^\markup{\left-align \small vib} c''16 \tuplet 3/2 {d''8 c''8 dis''8~^\markup{\left-align \small vib}} 
      | \tuplet 6/4 {dis''8. c''16 gis'16 f'16} r4 r8 cis''4\bendAfter #+4  d''8 
      | c''4.^\markup{\left-align \small vib} gis'16 g'16~ g'16. ais'32 c''32 ais'32 gis'32 ais'32 fis'32 d'32 ais32 gis32 c'16 g32 ais32 
      \bar "||" gis4 \tuplet 13/16 {r16.. c'32. dis'32 gis'64~} \tuplet 11/8 {gis'8. c''32 cis''32 c''32 gis'32 ais'32} c''16 gis'16 dis'8 
      | r2 \tuplet 6/4 {r8 dis'16 gis'16 ais'16 ais'16} gis'16\glissando  ais'16 c''16 dis''16~^\markup{\left-align \small vib} 
      | dis''4~ dis''16 dis'16 gis'8~ \tuplet 15/16 {gis'16~ gis'64 dis'32. gis'32. ais'32. ais'64~} \tuplet 14/16 {ais'32 c''64 ais'64 gis'32. ais'64~ ais'16 c''64 ais'64} 
      | gis'4 \tuplet 6/4 {gis'16 b'16 dis''4~} dis''16 cis''32 c''32 b'32 ais'16.~^\markup{\left-align \small vib} ais'8 r8 
      | r4 r8 r32 g'32 ais'32 c''32 \tuplet 3/2 {g'8 ais'4^\markup{\left-align \small vib}} \tuplet 3/2 {g'8 f'8 ais'8^\markup{\left-align \small vib}} 
      | r4 r16 d'16 dis'8~ \tuplet 7/8 {dis'16. d'32 e'32 f'32 dis'32} e'8^\markup{\left-align \small vib} r8 
      | r4 \tuplet 6/4 {r16 f'8 gis'16\glissando  b'16 c''16} ais'4~^\markup{\left-align \small vib} \tuplet 5/4 {ais'8 g'16 e'16 cis'16~^\markup{\left-align \small vib}} 
      | cis'8 r8 \tuplet 6/4 {r4 c'16 d'16~} \tuplet 12/8 {d'16 g'16 gis'32 g'32 f'16. e'16 g'32~} g'16 e'16 f'16 g'16 
      | f'16 gis'16\glissando  ais'8~^\markup{\left-align \small vib} ais'8. a'16 r2 
      | r8 r32 gis'32 g'32 f'32~ \tuplet 6/4 {f'8. fis'16 f'16 dis'16~} \tuplet 12/8 {dis'16 cis'32 dis'32 cis'32 c'32 ais32 a32 gis32 c'16 g32} \tuplet 7/8 {f32 ais32 g32 gis32 ais32 cis'32 b32} 
      | \tuplet 7/8 {ais32 gis32 g32 c'32 f32 c'32 dis32~^\markup{\left-align \small vib}} dis8 r8 r4 \tuplet 12/8 {ais32 gis32 c'32 dis'32 f'16. dis'32 g'32 ais'32 d''32 ais'32~} 
      | ais'8.. ais'32 d''16 f''8.~^\markup{\left-align \small vib} f''4 g''16 gis''8.^\markup{\left-align \small vib} 
      | \tuplet 3/2 {g''8 dis''8 dis''8~^\markup{\left-align \small vib}} dis''8 r8 r4 c'''8^\markup{\left-align \small vib} r8 
      | \tuplet 6/4 {r4 r16 ais''16~} ais''4 gis''16 f''16\glissando  fis''8^\markup{\left-align \small vib} dis''16\glissando  c''16 cis''8~ 
      | cis''8~ cis''32. ais'32 c''64 ais'64 gis'64~ \tuplet 10/8 {gis'16 fis'32\glissando  g'16. d'32 ais32 gis32 ais32} fis16\glissando  g16 dis'8^\markup{\left-align \small vib} r4 
      | r8 ais16 dis'16~ dis'16 cis'32 dis'16. ais32 cis'32 dis'8 cis'16 dis'16~ \tuplet 12/8 {dis'32 ais32 cis'16 dis'16 c''16. ais'32 b'32\glissando  c''32~} 
      \bar "||" \mark \default \tuplet 5/4 {c''16 ais'16 c''16 gis'16 dis'16} dis'8^\markup{\left-align \small vib} r8 r2\bar  ".."
    }
    >>
>>
}
