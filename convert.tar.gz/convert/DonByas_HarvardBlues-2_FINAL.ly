\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Harvard Blues (Solo 2)"
  composer = "Don Byas"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble_8"
    \key des \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              | s2 r2 
      | des1:7 | ges2:7 g2:dim | des1:7 | s1 | ges1:7 | s2 g2:dim | des1:7 | bes2:min es2:7 
      | aes1:7 | ges1:7 | des1:7 | s1 | r1|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 99
      \set Score.currentBarNumber = #0
     
      \bar "||" \mark \default r2 r8. gis16~ \tuplet 5/4 {gis16 cis'16 e'16 f'16 gis'16} 
      \bar "||" \mark \default \tuplet 3/2 {cis'4 cis'8} cis'8 f'8~^\markup{\left-align \small vib} f'8. gis'16~ gis'16 f'16 cis'16 b16~ 
      | b16 ais8 ais16~ \tuplet 3/2 {ais8 cis'8 e'8~} e'8. gis'16~ gis'16 e'16 cis'16 ais16~ 
      | ais16 dis'8 dis'16 ais4^\markup{\left-align \small vib} r4 \tuplet 6/4 {r8 gis8. fis16~} 
      | fis16 f16 f16 cis'16 dis'8 b8 \tuplet 5/4 {gis16 ais16 gis16 dis16 fis16} f4~^\markup{\left-align \small vib} 
      | \tuplet 7/8 {f8~ f32 e32 fis32~} \tuplet 5/4 {fis16 gis16 ais16 cis'16 dis'16~} \tuplet 6/4 {dis'16 e'16 fis'16 gis'8 dis'16~} \tuplet 6/4 {dis'16 cis'16 ais8 d'16 dis'16~} 
      | dis'8 cis'16 dis'16 \tuplet 6/4 {d'16 cis'16 ais8 gis16 fis16} gis8 dis8 ais8 a8 
      | gis4~ \tuplet 3/2 {gis8 f8 cis8} \tuplet 3/2 {c8 e8 gis8} ais16 c'16 ais16 f16~ 
      | \tuplet 6/4 {f16 gis16 ais16 f16 gis8~} gis8 dis8~ dis16 d16 f16 gis16~ gis16 ais16 b16 a16 
      | ais8 dis'8~ dis'8. ais16 d'8 fis'16 ais'16~ \tuplet 6/4 {ais'16 g'16 fis'16 d'8 ais16~} 
      | \tuplet 7/8 {ais32 cis'16. fis'16 ais'32~} \tuplet 6/4 {ais'16 fis'16 g'16 fis'16 cis'16 ais16} \tuplet 3/2 {fis8 c'8 ais8~} \tuplet 5/4 {ais16 fis'16 c'16 ais16 fis16} 
      | e4.^\markup{\left-align \small vib} ais16 f16~ \tuplet 6/4 {f16 fis8 cis'8 dis'16~} dis'16 g16. cis'16 dis'32~ 
      | dis'16 gis8 cis16~ cis16 f16\glissando  fis8 f2~^\markup{\left-align \small vib} 
      \bar "||" f4. r8 r2\bar  ".."
    }
    >>
>>
}
