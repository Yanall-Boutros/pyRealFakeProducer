\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Soultrane"
  composer = "John Coltrane"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble_8"
    \key es \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              | r1 
      | es1:maj | g2:min5-7 c2:7 | f1:min7 | des1:7 | aes2:min7 des4:7 d4:dim | es2:maj g4:7 c4:7 | f2:7 bes2:7 | g4:min7 c4:7 f4:min7 bes4:7 
      | es1:maj | g2:min5-7 c2:7 | f1:min7 | des1:7 | aes2:min7 des4:7 d4:dim | es2:maj g4:7 c4:7 | f2:7 bes2:7 | es2:maj a4:min5-7 d4:7 
      | g1:min7 | a2:min5-7 d2:7 | g1:min7 | c2:7 b2:7 | bes2:maj g2:min7 | c2:min5-7 f2:7 | f2:min7/bes bes2:dim | b2:7 bes4:7 e4:7 
      | es1:maj | g2:min5-7 c2:7 | f1:min7 | des1:7 | aes2:min7 des4:7 d4:dim | es2:maj g4:7 c4:7 | f2:7 bes2:7 | es1:maj 
      | s1|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 82
      \set Score.currentBarNumber = #0
     
      \bar "||" \mark \default r2 r16 g'16 f'16 dis'16 \tuplet 6/4 {c'8 gis16 f16 d'16 c'16~} 
      \bar "||" \mark \default c'16 ais16 a16 ais16 c'16 d'16 dis'16 f'32 g'32~ g'16 gis'16 ais'8~^\markup{\left-align \small vib} \tuplet 6/4 {ais'8 g'8 f'16 dis'16} 
      | cis'4^\markup{\left-align \small vib} r4 \tuplet 5/4 {r8 g'16 gis'16 g'16} f'16 e'16 c'16 d'16 
      | e'16 e'16\glissando  f'16 c'16~ \tuplet 5/4 {c'16 ais16 gis16 b16 c'16~} c'16 gis16 g16 f16 \tuplet 3/2 {ais8 gis4} 
      | b4~ \tuplet 12/8 {b16 ais16 b32 cis'16. dis'32 fis'32 ais'32 cis''32~} cis''8 b'32 ais'16 gis'32~ gis'16 fis'16 dis'16 cis'16 
      | b8. ais16~ \tuplet 6/4 {ais16 b8 dis'8 fis'16~} \tuplet 6/4 {fis'16 gis'16\glissando  ais'8. gis'16~} \tuplet 6/4 {gis'8 dis'16 f'8 g'16~} 
      | g'8\glissando  ais32 a32 ais32 c'32 \tuplet 6/4 {d'16 dis'16 f'16 g'4.} dis'8\glissando  f'16 gis'16 g'16 e'16 
      | \tuplet 6/4 {d'8. fis'16 g'16 dis'16~} \tuplet 3/2 {dis'8 dis'8 c'8~} c'16 g'16 f'16 dis'16 c'16 d'16 dis'16 f'16 
      | g'16 gis'16 a'16 ais'16~^\markup{\left-align \small vib} ais'2 \tuplet 5/4 {cis''16 c''16 b'16 fis'16 d'16} 
      \bar "||" cis'16 b16 ais8^\markup{\left-align \small vib} dis'4 r4 \tuplet 3/2 {d'8 dis'8 d'8} 
      | \tuplet 3/2 {c'8 cis'4~} \tuplet 10/8 {cis'16 c'32 cis'16 d'32 dis'32 d'32 e'32 fis'32} g'8 a'16 ais'16 \tuplet 3/2 {c''8 cis''8 c''8} 
      | c'4 r4 \tuplet 5/4 {r8 f16 gis16 c'16} dis'16 fis'16 ais'16 gis'16~ 
      | gis'16 g'16 gis'16 dis'16~^\markup{\left-align \small vib} dis'8. cis'16~ cis'16 ais16 dis8 gis16 ais16 gis8~^\markup{\left-align \small vib} 
      | gis4~ gis16 b16 dis'16 fis'16~ \tuplet 6/4 {fis'16 a'16 ais'16 c''16\glissando  cis''16 b'16} \tuplet 3/2 {ais'8 gis'8 dis'8} 
      | b16 ais16 gis'16 g'16 \tuplet 10/8 {d'16. f'16 dis'16 d'32 dis'32 g'32} ais'16 c''16 dis''16\glissando  cis''16 r4 
      | r4 \tuplet 12/8 {r16 c''8. b'16 ais'32 a'32~} a'16 ais'16 a'16 gis'16~ \tuplet 11/8 {gis'16 ais'16. a'32 gis'32 g'16 gis'32 g'32} 
      | \tuplet 6/4 {f'8 g'16 f'16 e'16 dis'16} dis'8 dis'8~^\markup{\left-align \small vib} dis'4~ \tuplet 7/8 {dis'16 gis'32 ais'32 a'32 g'32 fis'32} 
      \bar "||" \tuplet 10/8 {dis'32 d'16 c'16 ais16. e32 g32~} g32 a32 fis32 g32 a32 ais32 c'32 d'32 e'32 f'32 fis'32 g'32 a'32 ais'16.~ ais'8. ais'16~ 
      | ais'16 ais'16 c''4 g'8~ \tuplet 6/4 {g'16 d'16 e'16\glissando  f'4.^\markup{\left-align \small vib}} dis'8 
      | cis'16 d'8 d'16~^\markup{\left-align \small vib} d'4. ais16 g16 d'16 c'16 ais16 g16 
      | cis'16\glissando  d'8.~^\markup{\left-align \small vib} d'4 \tuplet 6/4 {fis16 gis16 cis'16 gis'16 b'8} a'16 gis'16 fis'16 f'16 
      | dis'16 cis'16\glissando  d'8~ d'16 dis'16 f'16 g'16~^\markup{\left-align \small vib} g'4 r4 
      | r8 a'16 ais'16~ ais'16 b'16 c''16 g'16 dis'16 d'16 c'16 g16 ais16 a32 c'32 dis'32 g'32 f'32 dis'32~ 
      | \tuplet 10/8 {dis'16 cis'16\glissando  d'16. ais16 f32} ais4^\markup{\left-align \small vib} r2 
      | r16. fis32 gis32 b32 cis'32 gis'32 b'16 gis'8 fis'16~ \tuplet 10/8 {fis'32 f16 gis32 ais32 c'32 d'32 dis'32 ais'32 g'32~^\markup{\left-align \small vib}} g'8. f'16 
      \bar "||" dis'16 cis'16\glissando  d'4^\markup{\left-align \small vib} r8 \tuplet 10/8 {r8 d'16. dis'16 fis'32~} fis'16 g'16 a'16 ais'16~ 
      | ais'16\glissando  cis''8\glissando  ais'16~ ais'8. g'16 fis'16 d'16 f'16 d'16 e'8\glissando  c''8^\markup{\left-align \small vib} 
      | r4 \tuplet 10/8 {r8 e'16. f'16 g'32~} g'16 gis'16 ais'16 c''16~ \tuplet 6/4 {c''16 d''16 dis''16 c''16 ais'16 gis'16~} 
      | gis'16 g'8 dis'16 b8 fis'8 \tuplet 6/4 {dis'16 b16 ais16 gis8.~^\markup{\left-align \small vib}} gis16 dis16 ais16 gis16^\markup{\left-align \small vib} 
      | r4 r16 b16 dis'16 fis'16~ \tuplet 10/8 {fis'32 ais'16. gis'16. g'16 gis'32~} \tuplet 3/2 {gis'8\glissando  dis''8 b'8} 
      | ais'16 gis'16 g'8~^\markup{\left-align \small vib} g'16 dis'16 ais16 g16 dis'8 d'16\bendAfter #+4  dis'16~^\markup{\left-align \small vib} dis'8 cis'8\glissando  
      | \tuplet 3/2 {c'8 gis8\glissando  c'8~^\markup{\left-align \small vib}} c'4~ \tuplet 6/4 {c'16 d'16 ais8 fis'16 g'16~} g'8.\glissando  ais16 
      | d'16 dis'16 dis'8~^\markup{\left-align \small vib} dis'4.. dis'16 c'16 cis'16 d'8 
      \bar "||" \mark \default ais8 r8 r2.\bar  ".."
    }
    >>
>>
}
