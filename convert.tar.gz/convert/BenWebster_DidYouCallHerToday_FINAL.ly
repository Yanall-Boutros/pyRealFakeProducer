\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Did You Call Her Today"
  composer = "Ben Webster"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble_8"
    \key aes \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              
      | bes1:7 | es1:7 | aes1:6 | s1 | es1:min7 | aes1:7 | des1:6 | s1 
      | des1:7 | d1:dim | aes1:6 | f1:7 | bes1:7 | s1 | bes1:min7 | es1:7 
      | bes1:7 | es1:7 | aes1:6 | s1 | es1:min7 | aes1:7 | des1:6 | s1 
      | des1:7 | d1:dim | aes1 | f1:7 | bes1:min7 | es1:7 | aes1:6 | s1 
      | bes1:7 | es1:7 | aes1:6 | s1 | es1:min7 | aes1:7 | des1:6 | s1 
      | des1:7 | d1:dim | aes1:6 | f1:7 | bes1:7 | s1 | bes1:min7 | es1:7 
      | bes1:7 | es1:7 | aes1:6 | s1 | es1:min7 | aes1:7 | des1:6 | s1 
      | des1:7 | d1:dim | aes1:6 | f1:7 | bes1:min7 | es1:7 | aes1:6 | s1 
      | r1|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 118
      \set Score.currentBarNumber = #1
     
      \bar "||" \mark \default r4 \tuplet 3/2 {g'4 gis'8~^\markup{\left-align \small vib}} gis'4 \tuplet 3/2 {f'4 d'8} 
      | \tuplet 3/2 {cis'8 dis'8 c'8} ais4^\markup{\left-align \small vib} r2 
      | r8 d'8 dis'8 fis'8~ \tuplet 3/2 {fis'8 fis'8\glissando  g'8} f'8 dis'8 
      | \tuplet 6/4 {gis'8 f'8. b16~} b8\glissando  c'4 r8 r4 
      | r8 dis'8~ dis'16\glissando  f'8 cis'16 \tuplet 3/2 {gis'4 f'8} e'8. c'32 dis'32~ 
      | dis'8 c'8 gis4 fis8 gis4^\markup{\left-align \small vib} r8 
      | r2 \tuplet 3/2 {g8\glissando  ais8 cis'8~} \tuplet 3/2 {cis'8 d'8\glissando  f'8} 
      | gis'8 ais'8~ ais'16 cis'8 cis'16~^\markup{\left-align \small vib} cis'4 r4 
      | r4 ais8 c'8 cis'8 dis'8 e'8 g'8 
      | gis'8 gis8~^\markup{\left-align \small vib} gis8. b16~ b8. ais16~ ais8. gis16 
      | \tuplet 3/2 {c'4 dis'8} r4 r8. g16\glissando  \tuplet 3/2 {a8 c'8 d'8~} 
      | d'16 f'16 g'16 d'16~ \tuplet 3/2 {d'8 f'8 c'8} \tuplet 3/2 {d'8 a8 c'8} g8 r8 
      | r4 r16 g32 a32 d'16 e'32 gis'32\bendAfter #+4  \tuplet 3/2 {g'8 gis'8 gis'8~^\markup{\left-align \small vib}} gis'8 gis'8~ 
      | \tuplet 3/2 {gis'8 gis'8 f'8} \tuplet 3/2 {cis'4 d'8~} d'16 g'8 f'16~ f'8 fis'16\glissando  g'16 
      | ais'8 dis'16 d'16 dis'8^\markup{\left-align \small vib} r8 r4 r8 e'8 
      | f'8. ais16~ ais8 b8 \tuplet 3/2 {c'8 g8 a8} c'8 f'8~ 
      \bar "||" \mark \default f'16 c'8 c'16~^\markup{\left-align \small vib} c'4 r4 \tuplet 3/2 {r8 gis8 c'8} 
      | cis'8 d'16 ais16 \tuplet 3/2 {cis'8 d'8 b8} \tuplet 3/2 {cis'8 d'8 ais8} \tuplet 3/2 {d'8 dis'8 c'8} 
      | dis'4.^\markup{\left-align \small vib} e'8 f'8. gis16~ \tuplet 6/4 {gis8 ais16 gis16 g8} 
      | gis16 gis8 dis'16~ dis'8 c'8 r4 \tuplet 3/2 {r8 f'8 dis'8~} 
      | \tuplet 3/2 {dis'8 g'8\glissando  gis'8} f'8 dis'8 \tuplet 3/2 {ais'4 f'8} dis'8 ais8 
      | \tuplet 3/2 {cis'8 c'8 gis8} fis8^\markup{\left-align \small vib} r8 r4 dis'16\glissando  f'8. 
      | \tuplet 3/2 {ais8 cis'8 ais8} dis'4\glissando  f'4.\bendAfter #-4  fis8 
      | \tuplet 3/2 {f4 dis8~} \tuplet 3/2 {dis8 dis8 dis8} r2 
      | \tuplet 3/2 {r8 gis8 b8} \tuplet 3/2 {cis'4 cis'8} r4 r8 gis16 ais16 
      | \tuplet 3/2 {cis'8 d'8 cis'8~} cis'16 cis'16 c'8~ c'8. gis16 \tuplet 3/2 {b4 d'8} 
      | dis'8. b16 c'4 dis'4.^\markup{\left-align \small vib} gis8 
      | \tuplet 3/2 {a8 c'8 d'8} f'8 g'8 \tuplet 3/2 {d'8 cis'8 c'8} a8 g8 
      | gis8 r8 r4 fis'16 g'16 fis'16 f'16 \tuplet 3/2 {d'8 g'4} 
      | \tuplet 3/2 {g8 dis'8 c'8} b8 r8 r4 dis8. cis'16 
      | c'8. gis16~ gis16 ais16 gis16 g16 gis8 r8 r4 
      | r4 e'16 f'8 gis'16 ais'16.\glissando  b'8 c''32~ c''8. gis'16 
      \bar "||" \mark \default ais'8\bendAfter #+4  b'8 r2. 
      | \tuplet 6/4 {f'4~ f'16 gis'16} \tuplet 3/2 {b'4 gis'8~^\markup{\left-align \small vib}} gis'4 \tuplet 3/2 {f'4 dis'8} 
      | \tuplet 6/4 {gis'4 dis'16 cis'16} b4 cis'8 dis'8^\markup{\left-align \small vib} r4 
      | r4 r8 g'8 \tuplet 3/2 {gis'8 ais'8 gis'8} g'16\glissando  gis'8 ais'16 
      | fis'8 g'8\glissando  gis'8 ais'16 f'16 g'16\glissando  gis'8 ais'32 gis'32 fis'4 
      | f'8 gis'8 \tuplet 6/4 {e'4 d'16 dis'16~} dis'8 r8 r4 
      | r4 \tuplet 3/2 {dis'8\glissando  f'8 gis'8} r2 
      | \tuplet 6/4 {ais8 cis'8 dis'16 cis'16~^\markup{\left-align \small vib}} cis'4 r2 
      | r2 dis'8\glissando  f'16 gis'16 ais'4 
      | \tuplet 3/2 {ais'8 b'4} ais'8 gis'8~^\markup{\left-align \small vib} \tuplet 6/4 {gis'4 ais'16 gis'16} f'8 r8 
      | r4 a8\glissando  ais16 b16 \tuplet 3/2 {c'8 cis'8 b8} d'8 b16 dis'16~ 
      | \tuplet 3/2 {dis'8 b8 e'8} \tuplet 3/2 {f'4 ais8~} ais16 a16 c'16 cis'16~ cis'16 f'16\glissando  fis'16 f'16~ 
      | f'16 dis'16 d'16 f'16 \tuplet 3/2 {c'8 ais8 c'8~^\markup{\left-align \small vib}} c'8 r8 r8. g16~ 
      | g16 gis8 f'16\glissando  g'16 gis'16 g'16 f'16 g'8 gis4 g8 
      | \tuplet 6/4 {dis'8. c'8 cis'16} dis'8 c'8 ais8^\markup{\left-align \small vib} r8 r4 
      | \tuplet 7/8 {r16. e16 f32 fis32~} \tuplet 6/4 {fis8 f16 a8 f16} c'16 f16 dis'8 \tuplet 6/4 {f'8.\glissando  fis'8 e'16} 
      \bar "||" \mark \default \tuplet 3/2 {f'8 ais8 c'8~^\markup{\left-align \small vib}} c'8 r8 r8 fis'8~ \tuplet 6/4 {fis'16 gis'16 ais'16 gis'16 f'8} 
      | cis'8 r8 r4 c''8 ais'8 c'16 cis'8 g16 
      | c'8. g'16\glissando  \tuplet 5/4 {gis'8 ais'16 gis'16 f'16} \tuplet 6/4 {ais4\glissando  b16 c'16~^\markup{\left-align \small vib}} c'8 r8 
      | r8 gis8 a16\glissando  b8. \tuplet 3/2 {c'4 cis'8~} cis'8 ais16 c'16~ 
      | \tuplet 3/2 {c'8 ais8 cis'8} \tuplet 3/2 {ais4 c'8} \tuplet 3/2 {c'4 gis8} fis8 r8 
      | r8. dis'16\glissando  e'8 f'8 \tuplet 3/2 {dis'8\glissando  e'8 cis'8} \tuplet 3/2 {dis'4 c'8} 
      | \tuplet 3/2 {cis'4 gis8} e4 \tuplet 3/2 {e'8\glissando  f'8 cis'8~^\markup{\left-align \small vib}} cis'8 r8 
      | r4 r8 gis8 \tuplet 3/2 {b4 cis'8} d'8 dis'8 
      | cis'16\bendAfter #+4  dis'16 cis'8 \tuplet 3/2 {d'4 d'8\glissando } \tuplet 3/2 {dis'4 gis8~} gis4 
      | \tuplet 3/2 {gis4 ais8~^\markup{\left-align \small vib}} ais8 r8 r4 \tuplet 3/2 {fis8 gis8 c'8} 
      | dis'8 fis'16\glissando  g'16~ g'16 fis'16\glissando  g'16 fis'16\glissando  \tuplet 3/2 {g'8 f'8 c''8~} c''16 g'16 f'16 g'16~ 
      | g'8\glissando  r8 r4 cis'16\glissando  d'8. \tuplet 3/2 {gis'4 gis'8~^\markup{\left-align \small vib}} 
      | gis'8 r8 r8. g32 a32 \tuplet 6/4 {d'8 f'16 g'16 gis'16 gis'16~} gis'8 gis'8~^\markup{\left-align \small vib} 
      | gis'8 r8 r4 e'16 f'8 gis'16 ais'16\glissando  b'8 c''16 
      | c''8\bendAfter #-4  b'8 \tuplet 3/2 {gis'4 dis'8} gis'4.^\markup{\left-align \small vib} f'8 
      | \tuplet 3/2 {dis'8 gis'4} cis'8 gis'8 c'8. b16~ b16 ais8 f16 
      \bar "||" gis8 r8 r2.\bar  ".."
    }
    >>
>>
}
