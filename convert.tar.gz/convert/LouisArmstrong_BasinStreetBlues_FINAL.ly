\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Basin Street Blues"
  composer = "Louis Armstrong"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble"
    \key bes \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              
      | bes1 | d1:7 | g1:7 | s1 | c1:7 | f1:7 | bes2 bes2:dim | c2:min7 f2:7 
      | bes1 | d1:7 | g1:7 | s1 | c1:7 | f1:7 | bes2 bes2:dim | c2:min7 f2:7 
      | bes1 | d1:7 | g1:7 | s2 s2 | c1:7 | f1:7 | bes2 bes2:dim | c2:min7 f2:7 
      | bes1 | d1:7 | g1:7 | s1 | c1:7 | f1:7|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 107
      \set Score.currentBarNumber = #1
     
      \bar "||" \mark \default d''16 ais'16 f'16 d'16~ d'16 f'16 ais'16 d''16 d''8 d''16 d''16 r4 
      | r2 \tuplet 6/4 {d''16 dis''16 d''16 cis''8 d''16~} \tuplet 3/2 {d''8 g''8 d''8~} 
      | d''16 a''8 e''16 d''8 d''4.^\markup{\left-align \small vib} \tuplet 3/2 {g'8 ais'8 d''8} 
      | g''8 fis''8 \tuplet 3/2 {f''4 g'8} dis''4.^\markup{\left-align \small vib} d''8 
      | e'16 g'16 ais'16 d''16 d''8 d''8 \tuplet 3/2 {d''8 d''8\bendAfter #+4  ais'8} r4 
      | dis'16 a'16 a'16 d''16~ d''8 d''8 d''16 d''16^\markup{\left-align \small vib} r8 r4 
      | g''8 fis''8 f''8 ais'16 dis''16~ \tuplet 5/4 {dis''16 d''16 a'''16 cis''16 d''16} c''16 ais'16 g'8 
      | a'16 ais'16 g'16 dis'16 c'16 b16 ais16 gis16 a16 e'16 a'8 g'4^\markup{\left-align \small vib} 
      \bar "||" \mark \default r4 f'16 e'16 g'16 f'16 \tuplet 3/2 {ais'8 d''8 f''8} a''8 a''8 
      | a''8 d''4^\markup{\left-align \small vib} a''8 d''8 a''16 d''16~ \tuplet 6/4 {d''16 ais''8. d''16 a''16~} 
      | a''8 a''8 d''4^\markup{\left-align \small vib} \tuplet 3/2 {a''8 d''8 a''8} \tuplet 3/2 {d''8 a''8 g''8} 
      | f''16 fis''16 g''16 d''16 \tuplet 6/4 {d''16\glissando  dis''16 e''16 f''8 d''16} b'8 g'8 \tuplet 3/2 {dis''8 d''8 f''8\glissando } 
      | g''8~ g''32 a'16 d''32~ d''8 d''16 d''16~^\markup{\left-align \small vib} d''4~ \tuplet 3/2 {d''8 cis''8 d''8} 
      | f''8 d''8 \tuplet 3/2 {e''4\bendAfter #+4  f''8} d''4^\markup{\left-align \small vib} r4 
      | r4 ais''2~^\markup{\left-align \small vib} ais''8 g''8 
      | \tuplet 3/2 {a''8\bendAfter #+4  ais''4} ais''4 \tuplet 6/4 {ais''4~ ais''16\glissando  c'''16~} c'''8 g''8 
      \bar "||" \mark \default ais''4 ais''4 f''4 r8 d''8 
      | \tuplet 3/2 {a''4 a''8~^\markup{\left-align \small vib}} a''8. a''16~ a''16 d''16 dis''16 d''16 \tuplet 3/2 {cis''8 d''8 a''8} 
      | g''8 d''8^\markup{\left-align \small vib} r2 r8 ais'16 b'16 
      | \tuplet 3/2 {d''8 g''8 fis''8~} fis''32 f''16. e''16. dis''32 \tuplet 3/2 {f''8 dis''4~^\markup{\left-align \small vib}} dis''8 b'8 
      | cis''8\bendAfter #+4  d''8~^\markup{\left-align \small vib} d''4. g'16 gis'16 a'8 d''16 c''16 
      | d''16 c''8.^\markup{\left-align \small vib} \tuplet 3/2 {g'8 gis'8 a'8} f''16 d''8.~^\markup{\left-align \small vib} d''8 a'8 
      | \tuplet 3/2 {c''4 c''8} ais'8 ais'8 a'8 g'4^\markup{\left-align \small vib} g'8 
      | \tuplet 3/2 {gis'8\glissando  ais'8 a'8~} \tuplet 3/2 {a'8 a'8 g'8} a'16 g'8.~^\markup{\left-align \small vib} g'8 f'8 
      \bar "||" d'8 d'8 d'4^\markup{\left-align \small vib} r4 \tuplet 6/4 {r4 cis'16\bendAfter #+4  d'16~} 
      | d'8 dis'8 d'2^\markup{\left-align \small vib} cis'16 d'16 dis'16 d'16 
      | \tuplet 3/2 {dis'8 d'8 g'8} a'4 d'4.^\markup{\left-align \small vib} r8 
      | r4 \tuplet 6/4 {r8 gis'16\bendAfter #+4  a'8 g'16~} \tuplet 3/2 {g'8 f'8 d'8} \tuplet 3/2 {dis'4\bendAfter #-4  b8} 
      | \tuplet 3/2 {d'4 d'8~^\markup{\left-align \small vib}} d'4 r2 
      | r8 cis'8 \tuplet 3/2 {d'8 g'8 d'8} \tuplet 3/2 {f'8 d'8 f'8} d'4^\markup{\left-align \small vib}\bar  ".."
    }
    >>
>>
}
