\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Tenor Madness"
  composer = "Sonny Rollins"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble_8"
    \key bes \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              
      | bes1:7 | s1 | s1 | s1 | es1:7 | s1 | bes1:7 | s1 
      | c1:min7 | f1:7 | bes1:7 | s1 | s1 | es1:7 | bes1:7 | s1 
      | es1:7 | s1 | bes1:7 | g1:7 | c1:min7 | f1:7 | bes1:7 | s1 
      | s1 | es1:7 | bes1:7 | s1 | es1:7 | s1 | bes1:7 | s1 
      | c1:min7 | f1:7 | bes1:7 | s1 | s1 | es1:7 | bes1:7 | s1 
      | es1:7 | aes1:7 | bes1:7 | s1 | c1:min7 | f1:7 | bes1:7 | s1 
      | s1 | es1:7 | bes1:7 | s1 | es1:7 | bes1:7 | s1 | s1 
      | c1:min7 | f1:dim | bes1:7 | s1 | s1 | es1:7 | bes1:7 | s1 
      | es1:7 | s1 | bes1:7 | g1:7 | c1:min7 | f1:7 | bes1:7 | s1 
      | s1 | es2:7 es2:min7 | bes1:7 | f2:min7 bes2:7 | es1:7 | es1:min7 | d1:min7 | cis1:min7 
      | c1:min7 | f1:7 | bes1:7 | s2 f2:7 | bes1:7 | es1:7 | bes1:7 | s1 
      | es1:7 | s1 | bes1:7 | s1 | c1:min7 | f1:7 | bes2:7 g2:7 | c2:min7 f2:7 
      | bes1|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 176
      \set Score.currentBarNumber = #1
     
      \bar "||" \mark \default r2 d'8 d'8 ais4 
      | d'4 ais2. 
      | \tuplet 3/2 {d'4 ais8~} ais8 ais8 \tuplet 3/2 {d'4 ais8} ais8 ais8 
      | r2 r8 f8 \tuplet 3/2 {ais4 cis'8~} 
      | cis'8 cis'8 ais8 r8 r2 
      | f'2~ \tuplet 3/2 {f'8 e'8 dis'8} cis'16 ais8. 
      | d'4 ais4 r2 
      | r4 r8 a8 ais8 d'8 f'8 g'8 
      | a'8 ais'8 g'8 dis'8 d'8 c'8 f'8 d'8 
      | dis'8 ais8 \tuplet 3/2 {g4 f8} cis'4 a8 f8 
      | \tuplet 3/2 {c'4 a8} f8 d8 g8 g8 r4 
      | r4 r8. f16 ais,4 ais4 
      \bar "||" \mark \default d'16 f'8 f'16 \tuplet 3/2 {f'4 d'8~} d'8 ais4 g'8~ 
      | g'8 dis'8 \tuplet 3/2 {dis'4 c'8~} c'8 a8 f8 r8 
      | r2 r8. gis16~ gis16 b8 d'16~ 
      | d'16 g'8 d'16 f'8 fis'8~ \tuplet 6/4 {fis'16 d'8. d'16 b16~} b16 ais8 gis16 
      | g4 ais8 cis'8 f'8 cis'8 dis'4 
      | cis'8 ais8~ ais16 f8 e16~ \tuplet 3/2 {e8 e8 f8~} \tuplet 3/2 {f8 g8 e8~} 
      | \tuplet 5/4 {e16 f8. d16~} d8 r8 r2 
      | r8 gis4 ais'4 gis'4 ais'8 
      | g'4 f'8. g'16~ g'4. r8 
      | r8. fis16~ fis8. gis'16~ gis'8 fis'8~ fis'8. gis'16~ 
      | gis'8 f'4 dis'8 f'8 r8 r4 
      | r2. r8. c'16~ 
      \bar "||" \mark \default \tuplet 5/4 {c'16 f'8 f'16 ais'16} c''8 ais'8~ ais'16 g'8 f'16~ f'8 c'8 
      | r4 r8. ais16~ ais8 g8~ g8. f16~ 
      | f8 c8 c4 r2 
      | gis,16 g8 f16 c4 dis16 d8 cis'16 b8 fis8 
      | ais4 g8 r8 r2 
      | r2. r8. ais'16~ 
      | ais'8. ais'16~ ais'8 ais'8~ \tuplet 6/4 {ais'8 ais'8. ais'16~} ais'8 ais'8~ 
      | ais'16 a'8 c''16~ c''8 a'8 g'8. g'16~ g'8 f'8~ 
      | f'8 ais'8~ ais'2 ais'4 
      | a'4 a'4 dis'4 g'4~ 
      | \tuplet 6/4 {g'16 f'4 f'16} r2 r8 d'8~ 
      | d'16 f'8 d'16~ d'16 dis'8 f'16 d'4 g8 f8 
      \bar "||" \mark \default c'8 gis8 r4 r8. fis16~ \tuplet 5/4 {fis16 g16 d'16 f'16 f'16} 
      | dis'8 ais4 ais8~ ais16 e'8 f'16 g'8 e'8 
      | f'8 d'8~ d'16 dis'8 dis'16 d'8 r8 r4 
      | r2. r8. g'16~ 
      | g'8 ais'4 g'8 c''4 ais'4 
      | fis'4 d''8 c''8 ais'8 fis'8 \tuplet 3/2 {f'4 dis'8} 
      | d'8 g'8 ais'8 g'8 c''4 \tuplet 3/2 {ais'4 f'8~} 
      | f'8 e'4 ais'4 c''8 ais'8. e'16~ 
      | e'8 dis'4 r8 r2 
      | r16 d''8 c''16~ c''16 ais'8 g'16~ g'16 a'8 g'16~ g'16 f'8 dis'16~ 
      | dis'16 d'8 c'16~ c'16 ais8 f16~ f8 a8 ais8 r8 
      | r2 r8 ais8 dis'8 g'8~ 
      \bar "||" \mark \default g'8. gis'16~ gis'4 r4 r8 g'8 
      | r4 r8 e'8 \tuplet 3/2 {f'4 d'8} dis'8 cis'8~ 
      | cis'16 d'16 d'16 ais16~ ais16 c'8 a16~ a16 ais8 g16 gis8 e8 
      | g8 dis8 \tuplet 3/2 {f4 d8~} d16 dis8 cis16~ \tuplet 6/4 {cis16 d16 d8. d16~} 
      | d8 cis8 r2. 
      | r8 cis'8 fis'16 g'16 ais'16 c''16~ c''8 cis''4.~ 
      | cis''8 cis''8 r2 r8 a'8 
      | ais'8. g'16 gis'8 f'8 \tuplet 3/2 {g'4 e'8} \tuplet 3/2 {f'8 g'8 e'8~} 
      | e'8 e'16 d'16 dis'8. c'16 d'4 b8 c'8 
      | g16 ais8 g16~ \tuplet 6/4 {g8 a8. f16~} f16 g8 dis16 r4 
      | r2 r8. ais16~ ais16 cis'16 d'16 g'16~ 
      | g'8 gis'4. e'8 g'8~ g'16 f'8 dis'16~ 
      \bar "||" \mark \default dis'16 cis'8 d'16~ \tuplet 3/2 {d'8 ais8 a8} gis8. ais16~ ais16 g'8 f'16~ 
      | \tuplet 3/2 {f'8 dis'8 a8} \tuplet 3/2 {ais4 c'8~} c'16 cis'8 ais16 c'8 a8~ 
      | a16 ais8 f16 d8 dis8 f8 r8 r4 
      | r4 r8 ais8 g4 ais4 
      | cis'4 g4 ais8 r8 r4 
      | r2. r8 ais8~ 
      | ais8 f'8 r4 ais4 f'4~ 
      | f'16 dis'8 dis'16 d'8 c'8~ c'16 b8 gis16~ \tuplet 3/2 {gis8 g8 f8~} 
      | \tuplet 6/4 {f16 dis4 f16} g8 ais8 d'8 f'8 \tuplet 3/2 {dis'4 ais8} 
      | d'4 d'8 dis'8 d'8 ais8 \tuplet 3/2 {f4 dis8} 
      | d8 r8 r2 r8. a16 
      | ais16 d'16 f'16 g'16~ g'4 gis'4~ \tuplet 6/4 {gis'16 g'8 fis'8 e'16~} 
      \bar "||" \mark \default e'16 g'8 f'16 r2. 
      | \tuplet 6/4 {r16 g'4 ais'16} \tuplet 3/2 {c''4 ais'8} fis'8 fis'8 \tuplet 3/2 {f'4 dis'8} 
      | d'8. ais16 r4 r8. f'16 \tuplet 3/2 {g'8 ais'8 c''8} 
      | d''4~ d''16 d''8 c''16~ c''16 ais'8 a'16~ \tuplet 3/2 {a'8 gis'8 ais'8} 
      | g'4 cis'8 r8 r2 
      | r8 c''8 \tuplet 3/2 {ais'4 fis'8~} \tuplet 6/4 {fis'8 f'8. dis'16} r4 
      | r4 c''4 a'8 f'8 d'4~ 
      | d'16 ais'8 b'16~ \tuplet 6/4 {b'16 gis'4 e'16~} e'16 e'16 d'8 r4 
      | \tuplet 3/2 {r8 ais'8 ais'8~} ais'16 g'8 dis'16~ dis'16 c'8 dis'16~ dis'16 g'8 ais'16~ 
      | \tuplet 3/2 {ais'8 g'8 gis'8~} gis'16 fis'8 cis'16~ cis'16 a8 fis16 r4 
      | r2 r8 ais8 d'8 f'8 
      | a'8 g'8 a'8 g'8 \tuplet 3/2 {gis'4 fis'8~} fis'16 cis'16 cis'16 dis'16 
      \bar "||" \mark \default f'8 a8 \tuplet 3/2 {ais4 d'8} dis'8 d'8~ \tuplet 3/2 {d'8 ais8 g8} 
      | ais4 dis'4. dis'8 \tuplet 3/2 {d'4 ais8} 
      | \tuplet 3/2 {dis'4 d'8~} d'16 ais8 gis16 ais4 ais8 r8 
      | r1 
      | r2 \tuplet 3/2 {r8 ais8 cis'8} \tuplet 3/2 {dis'8 f'4~} 
      | f'16 e'8 cis'16~ cis'16 ais16 ais16 e'16~ \tuplet 3/2 {e'8 f'8 e'8} \tuplet 3/2 {cis'8 ais16 r8.} 
      | r4 r8 f8~ f16 gis8 b16~ b8 c'8~ 
      | c'4 c'8. c'16 ais16 a16 g8 f4 
      | r2 r8 g8 \tuplet 5/4 {b16 dis'8. f'16} 
      | \tuplet 6/4 {g'16 ais'8 a'8 g'16~} \tuplet 3/2 {g'8 a'8 fis'8} g'16 dis'16 cis'16 d'16 \tuplet 3/2 {f'8 e'8 dis'8} 
      | \tuplet 3/2 {d'8 f'8 c'8} a16 ais16 cis'16 d'16 \tuplet 5/4 {g'8 fis'16 f'16 dis'16} \tuplet 6/4 {d'8 b16 g16 e16 c'16} 
      | b8 c'8 dis'16 d'8 c'16 b16 ais16 a16 g16 gis16 a16 fis16 g16 
      | dis16 d16 r8 r2.\bar  ".."
    }
    >>
>>
}
