\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Tautology"
  composer = "Warne Marsh"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble_8"
    \key f \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              
      | f1 | f1:7 | a1:min | d1:7 | g1:min | c1:7 | f1:maj | s1 
      | c2:maj11+.9 bes2:11+.9 | aes2:11+.9 ges2:maj11+.9 | f1:maj | d1:7 | g1:min | c1:7 | f1:maj | s1 
      | bes1:min7 | es1:7 | bes2:dim bes2:min7 | aes1 | a1:min7 | d1:7 | g1:7 | c1:7 
      | f1 | f1:7 | a1:min | d1:7 | g1:min | c1:7 | f1:maj | s1 
      | f1 | f1:7 | a1:min | d1:7 | g1:min | c1:7 | f1:maj | s1 
      | c2:maj11+.9 bes2:11+.9 | aes2:11+.9 ges2:maj11+.9 | f1:maj | d1:7 | g1:min | c1:7 | f1:maj | s1 
      | bes1:min7 | es1:7 | bes2:dim bes2:min7 | aes1 | a1:min7 | d1:7 | g1:7 | c1:7 
      | f1 | f1:7 | a1:min | d1:7 | g1:min | c1:7 | f1:maj|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 270
      \set Score.currentBarNumber = #1
     
      \bar "||" \mark \default r2 \tuplet 3/2 {gis'4 a'8~} a'16 c''8 a'16~ 
      | a'8 f'8 d'16 e'8.~ e'8 cis'8 d'4 
      | a2^\markup{\left-align \small vib} r2 
      | r2 r16 c'8 dis'16~ \tuplet 3/2 {dis'8 d'8 c'8~} 
      | c'16 f'8 d'16~ d'16 ais8 g16~ g4 ais8 a16 g16~ 
      | g16 c'8 a16~ a16 ais8 c'16 d'8 e'8 f'8 g'8 
      | a'8 r8 r2. 
      | r2 ais'8 g'8 \tuplet 3/2 {c''4 a'8~} 
      \bar "||" \tuplet 3/2 {a'8 f'8 d'8} r4 r16 e'8 cis'16~ cis'8 r8 
      | r2 d'8 b8 cis'8 d'8 
      | e'8 d'8 cis'8 d'8 f'4 a'16 d''8 cis''16 
      | c''8 a'4 fis'8 dis'16 c'8 a16~ \tuplet 3/2 {a8 fis8 g8~} 
      | g16 ais8 d'16~ d'8 ais8~ \tuplet 3/2 {ais8 c'8 b8~} \tuplet 3/2 {b8 ais8 c'8} 
      | d'8 e'8~ e'16 a'8 g'16 e'8 c'8 \tuplet 3/2 {d'8 f'8 a'8} 
      | c''4. c'8 \tuplet 3/2 {d'8 f'8 a'8} ais'8 r8 
      | r8. a'16~ a'8 ais'8 a'8 f'8 c'8 a8~ 
      \bar "||" \tuplet 3/2 {a8 g8 gis8} c'16 dis'8 c'16 cis'8 f'16 gis'16 \tuplet 3/2 {c''4 dis''8~} 
      | dis''8 r8 r2. 
      | r4 \tuplet 3/2 {r8 dis'8 f'8~} f'16 gis'8 cis''16~ cis''8 c''8 
      | ais'8 gis'8 \tuplet 3/2 {g'8 f'8 dis'8~} dis'8 cis'8 c'8 ais8 
      | gis8 a8 \tuplet 3/2 {c'8 e'4~} e'8 g'8 e'16 f'16 fis'16 g'16~ 
      | g'8 a'4. d''2 
      | r1 
      | r2 \tuplet 3/2 {r8 d'8 f'8~} f'16 e'8 f'16 
      \bar "||" g'4~ g'16 c''8 a'16~ \tuplet 3/2 {a'8 f'8 d'8~} d'4 
      | e'4. cis'8~ cis'16 a8 b16 cis'8 d'8 
      | e'8 d'8 cis'8 d'8 f'8. a'16 d''8 cis''8~ 
      | cis''16 c''8 a'16~ a'16 fis'8 dis'16~ dis'16 c'8 a16~ a16 fis8 g16~ 
      | g8. d'16 g'4 \tuplet 3/2 {fis'8 f'8 cis'8} ais8 c'8 
      | cis'8 f'8 a'8. gis'16 g'8 e'8 c'8 a8 
      | g8 f8 e8 f8 g8 a8 ais8 c'8~^\markup{\left-align \small vib} 
      | c'4. r8 r2 
      \bar "||" \mark \default r4 c8 d8 e8 f8 \tuplet 3/2 {g4 e8} 
      | \tuplet 3/2 {f4 g8~} \tuplet 3/2 {g8 a8 b8} cis'8 d'8~ d'16 e'8 cis'16~ 
      | cis'16 d'8 e'16~ \tuplet 3/2 {e'8 f'8 g'8} a'8 ais'8 c''8 d''8 
      | dis''8 d''8 c''8 b'8 ais'8 a'8 g'8 fis'8 
      | f'8 d'8 ais8 g8 c'8 b8 ais8 c'8 
      | cis'8 e'8 a'8 g'8 e'8 c'8 \tuplet 3/2 {d'8 f'8 a'8} 
      | c''4 c'8 d'8 dis'8 fis'16 a'16 c''4~ 
      | c''8 ais16 c'16~ c'16 cis'16 e'8 gis'16 c''8 gis'16 \tuplet 3/2 {dis'8 cis'8 ais8} 
      \bar "||" e8 f8 r2. 
      | r8 c'8 a8 f8 \tuplet 3/2 {cis'4 a8~} a16 e8 f16~ 
      | \tuplet 3/2 {f8 g8 a8~} \tuplet 3/2 {a8 cis'8\glissando  d'8~^\markup{\left-align \small vib}} d'4. r8 
      | r2. r16 g8 ais16 
      | d'4 g'8. fis'16~ \tuplet 3/2 {fis'8 f'8 d'8} \tuplet 3/2 {ais4 c'8} 
      | cis'4~ \tuplet 6/4 {cis'16 a'4 gis'16} g'8 e'8 c'8 d'8 
      | e'8 g'8 \tuplet 3/2 {c''4 b'8} ais'8 gis'8~ \tuplet 3/2 {gis'8 g'8 f'8~} 
      | f'8 e'8 c'8 d'8 e'4 f'8 g'8 
      \bar "||" gis'8 r8 r4 r16 ais8 c'16~ c'16 cis'8 dis'16~ 
      | dis'4~ dis'16 ais8 c'16~ c'8 cis'8 dis'8 f'8~ 
      | f'8 ais'4.^\markup{\left-align \small vib} r2 
      | r2 dis''8 c''8 gis'8 dis'8 
      | cis'8 d'8 g'4 \tuplet 3/2 {c''4 b'8} a'8 g'8 
      | fis'8 e'8 d'8 c'8 b8 a8 fis8 g8 
      | b8 d'8 \tuplet 3/2 {fis'4 e'8} dis'8 d'8 cis'8 c'8 
      | b8 ais8 a8 g8 f8 e4. 
      \bar "||" f2 a8 c'4 a8~ 
      | a8 cis'8 e'4~ e'16 cis'8 d'16 f'8 a'8 
      | d''4. d''8 r2 
      | r1 
      | f''8 d''8 ais'8 g'8 d'8 f'8 e'8 d'8 
      | cis'8 e'8 g'8 b'8 c''8 a'8 f'8 c'8 
      | a8 c'8 ais8 a8 g8 ais8 d'8 f'8 
      | fis'8 e'8 dis'8 cis'8 c'8 ais8 gis8 g8 
      \bar "||" f8 r8 r2.\bar  ".."
    }
    >>
>>
}
