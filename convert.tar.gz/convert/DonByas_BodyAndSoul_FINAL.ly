\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Body and Soul"
  composer = "Don Byas"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble_8"
    \key des \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              | des2:6 bes2:7 
      | es2:min7 bes2:9- | es2:min7 d2:7 | des2:maj ges2:7 | f2:min7 e2:dim7 | es1:min7 | c2:min5-7 f2:7 | bes4:min7 es4:7 es4:min7 aes4:7 | des2:6 bes2:7 
      | es2:min7 bes2:9- | es2:min7 d2:7 | des2:maj ges2:7 | f2:min7 e2:dim7 | es1:min7 | c2:min5-7 f2:7 | bes4:min7 es4:7 es4:min7 aes4:7 | des2 a2:7 
      | d2:maj e2:min7 | d2 g4:min7 c4:7 | fis4:min7 b4:min7 e4:min7 a4:7 | d1:maj | d2:min7 g2:7 | c2:maj es2:dim | d2:min7 g2:7 | c4:7 b4:7 bes2:7 
      | es2:min7 bes2:9- | es2:min7 d2:7 | des2:maj ges2:7 | f2:min7 e2:dim7 | es1:min7 | c2:min5-7 f2:7 | bes4:min7 es4:7 es4:min7 aes4:7 | des2:6 bes2:7 
      | es2:min7 bes2:9- | es2:min7 d2:7 | des2:maj ges2:7 | f2:min7 e2:dim7 | es1:min7 | c2:min5-7 f2:7 | bes4:min7 es4:7 es4:min7 aes4:7 | des2:6 bes2:7 
      | es2:min7 bes2:9- | es2:min7 d2:7 | des2:maj ges2:7 | f2:min7 e2:dim7 | es1:min7 | c2:min5-7 f2:7 | bes4:min7 es4:7 es4:min7 aes4:7 | des2 a2:7 
      | d2:maj e2:min7 | d2 g4:min7 c4:7 | fis4:min7 b4:min7 e4:min7 a4:7 | d1:maj | d2:7 g2:7 | c2:maj es2:dim | d2:min7 g2:7 | c4:7 b4:7 bes2:7 
      | es2:min7 bes2:9- | es2:min7 d2:7 | des2:maj ges2:7 | f2:min7 e2:dim7 | es1:min7 | c2:min5-7 f2:7 | bes4:min7 es4:7 es4:min7 aes4:7 | des2:6 bes2:7|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 99
      \set Score.currentBarNumber = #0
     
      \bar "||" \mark \default r2 r8 dis8~ dis16 gis16 b16 ais16 
      \bar "||" \mark \default dis2~^\markup{\left-align \small vib} \tuplet 3/2 {dis8 e8 f8} \tuplet 10/8 {fis16. gis16. f16. dis32~} 
      | \tuplet 3/2 {dis8 ais8 ais8~^\markup{\left-align \small vib}} ais4~ \tuplet 6/4 {ais4 e16 gis16~} \tuplet 6/4 {gis16 e'8 c'16 ais16 fis16} 
      | f4~^\markup{\left-align \small vib} \tuplet 6/4 {f8 gis8 ais16 gis16~} \tuplet 6/4 {gis16 ais8. dis16 fis16} ais16 dis'16 cis'16 ais16 
      | fis16 f8. gis8\glissando  dis'16 cis'16 c'4 ais8 e16 f16 
      | dis4.^\markup{\left-align \small vib} fis8 ais8\glissando  cis'16 ais16~ ais32 gis16 fis16 cis16 dis32 
      | f4.^\markup{\left-align \small vib} f8~ f16\glissando  fis16 f16 a16 \tuplet 3/2 {cis'8 f8 a8~} 
      | a16 c'8\glissando  b16 ais8 f8~ \tuplet 5/4 {f16 b8. ais16~} ais16 a16 e16 fis16 
      | gis4.^\markup{\left-align \small vib} f16 e16 dis16 gis16 b16 dis16 d4~^\markup{\left-align \small vib} 
      \bar "||" \tuplet 6/4 {d4 dis16 f16} fis16 gis16 ais16 cis'16 f'16 dis'16 d'16 f'16 \tuplet 3/2 {gis'8 b'8\glissando  a'8} 
      | \tuplet 6/4 {ais'8 fis'16 f'16 e'16 dis'16} \tuplet 6/4 {d'8 ais'8 fis'16 d'16~} d'32 cis'16 ais16 fis32 dis32 cis32~ cis32 c16. gis32 fis16 f32~^\markup{\left-align \small vib} 
      | f4~ f16 gis16 ais16 c'16 \tuplet 6/4 {dis'8 c'8 cis'16 dis'16~} dis'16 f'16 gis'16 fis'16 
      | f'16 fis'16 gis'16 ais'16 \tuplet 3/2 {c''8 f'4~} \tuplet 6/4 {f'16 e'16 fis'8 g'16 a'16} b'8 e'8~^\markup{\left-align \small vib} 
      | e'16 dis'16 f'16 fis'16 gis'16 ais'8.~^\markup{\left-align \small vib} ais'8 gis'16 fis'16 \tuplet 6/4 {d'16 f'16 dis'16 cis'16 ais16 fis16} 
      | \tuplet 6/4 {f8 a8 c'16 d'16~} \tuplet 6/4 {d'16 dis'16 f'8 g'16 dis'16~} dis'16 b16 d'16 c'16 \tuplet 6/4 {ais16 a16 fis8 f16 dis16} 
      | r4 \tuplet 10/8 {r8 gis8~ gis32\glissando  g32~} g16 e'16 cis'16 g16 \tuplet 6/4 {fis8 dis'8 c'16 fis16} 
      | f4.^\markup{\left-align \small vib} a4\glissando  fis'8^\markup{\left-align \small vib} e'16 d'16 cis'16 g16 
      \bar "||" \tuplet 6/4 {fis8. a8 b16} e'16 d'16 a16 g16 g8 d'4.^\markup{\left-align \small vib} 
      | a8\glissando  ais16 cis'16 e'16 cis'16 d'16 fis'16~ fis'16 a'16 g'16 d'16 c'8 ais16 a16~^\markup{\left-align \small vib} 
      | a4~ \tuplet 6/4 {a16 g'16 f'8 fis'16 e'16~} \tuplet 5/4 {e'16 f'16 d'16 b16 gis16} g16 e'16 cis'16 g16 
      | fis8 a16 b16 e'16 b16 d'32 dis'32 d'32 b32 a4.^\markup{\left-align \small vib} b'8 
      | \tuplet 6/4 {d''16 cis''16 c''16 b'8 a'16} g'16 fis'16 f'16 e'16 d'16 cis'16 ais16 a16 gis16 f16 dis8~ 
      | dis16 g16 e16 f32 g32 a16 b16 d'16 b16 \tuplet 6/4 {c'8 a16 g8 e16} \tuplet 3/2 {fis8 dis'4~^\markup{\left-align \small vib}} 
      | \tuplet 6/4 {dis'8 gis'16 fis'16 f'16 d'16~} \tuplet 6/4 {d'16 cis'16 f'8 a'16 cis''16} c''16 f'16 a'16 c''16 b8\glissando  d'16 f'16 
      | g'16 f'16 e'16 g16 fis16 dis'16 b16 dis16 d8. gis16~ gis16 ais16 b16 cis'16 
      \bar "||" d'16 f'16 dis'16 cis'16 ais4~^\markup{\left-align \small vib} ais16 dis'16 d'16 fis'16 ais'16 d'8.~^\markup{\left-align \small vib} 
      | d'8 cis'16 ais16 \tuplet 6/4 {gis16 ais16 gis16 fis16 dis16 cis16~} cis32 c32 fis32 gis16. fis32 ais32 \tuplet 7/8 {g16 gis32 c'32 a32 fis32 ais32} 
      | fis16 f8.~ f8 gis16 f16~ \tuplet 6/4 {f16 fis16 ais16 dis'16 cis'16 ais16} \tuplet 10/8 {fis4^\markup{\left-align \small vib} e32 f32~} 
      | \tuplet 6/4 {f16 gis16 cis'16 c'8 gis16} f8.^\markup{\left-align \small vib} dis16 \tuplet 5/4 {e16 g16 cis'16 b16 g16} e4~^\markup{\left-align \small vib} 
      | e8 dis32 fis32 ais32 cis'32~ \tuplet 10/8 {cis'32 f'16. dis'16 cis'16. ais32~^\markup{\left-align \small vib}} ais4 gis32 ais32 gis32 fis32 dis16 cis16 
      | c8 fis8 f4~^\markup{\left-align \small vib} \tuplet 3/2 {f8 a8 c'8} cis'8 f16 a16~ 
      | a32 c'8\glissando  ais16 f'32~^\markup{\left-align \small vib} f'4~ \tuplet 3/2 {f'8 b8 a8} \tuplet 5/4 {e'4 ais16~} 
      | ais16 gis16 dis'8~^\markup{\left-align \small vib} dis'4~ \tuplet 3/2 {dis'8 d'8 f'8} \tuplet 3/2 {gis'8 b'8 a'8~} 
      \bar "||" \mark \default a'16 ais'16 dis''16 gis'16~^\markup{\left-align \small vib} gis'4~ gis'16. fis'16 f'16 c''32 dis'4~^\markup{\left-align \small vib} 
      | \tuplet 6/4 {dis'4 cis'16 d'16~} \tuplet 6/4 {d'16 f'16 dis'8 d'16 b16} ais16 gis16 fis16 f16 dis16 d16 b16 a16 
      | gis4.^\markup{\left-align \small vib} cis'16 f'16~ f'16\glissando  gis'16 fis'16 dis'16 cis'8^\markup{\left-align \small vib} fis16 e16 
      | f8 gis16 ais16 c'16 f'16 gis'16 c''16 b8 cis'16 e'16 g'16 b'16 fis'16 e'16 
      | dis'4.^\markup{\left-align \small vib} \tuplet 6/4 {fis'8 gis'16~} gis'32 ais'8\glissando  fis'32 gis'32 fis'32 dis'16 cis'16 ais16 fis16 
      | f4.^\markup{\left-align \small vib} a'8\glissando  \tuplet 10/8 {d''16 cis''32 c''32 b'16 ais'32 a'16 c''32} b'32 g'32 fis'32 e'32 dis'16 c'32 cis'32 
      | \tuplet 6/4 {dis'16 c'16 cis'16 dis'16 f'8~^\markup{\left-align \small vib}} f'4 fis'32 f'32 e'32 d'32 cis'32 b32 a32 g32 \tuplet 6/4 {fis16 cis'16 dis'16 f'16 dis'16 c'16} 
      | ais32 gis32 fis32 f32 gis32 cis'32 f'16 \tuplet 7/8 {gis'32 g'32 e'32 d'32 c'32 b32 a32} \tuplet 6/4 {g16 fis16 dis'16 f'16 dis'16 b16} f8.^\markup{\left-align \small vib} f32 gis32 
      \bar "||" b16 ais8.~^\markup{\left-align \small vib} \tuplet 5/4 {ais8. dis'16 f'16~} \tuplet 5/4 {f'16 g'16 fis'16 f'16 dis'16} d'16 f'16 gis'16 b'16~ 
      | b'16 ais'16 fis'16 d'16 f'16. dis'16. ais32 fis32 \tuplet 3/2 {dis8 d8 b8} a4~^\markup{\left-align \small vib} 
      | a8 gis16 ais16 c'16 dis'16 cis'16 gis16 \tuplet 6/4 {fis8 ais16 dis'8 ais16} cis'4~^\markup{\left-align \small vib} 
      | \tuplet 5/4 {cis'8 e16 f16 fis16} gis16 ais16 c'16 cis'16 dis'16 d'16 b16 d16 f16 gis16 b16 a16 
      | ais4.^\markup{\left-align \small vib} f'16 d'16 dis'16 f'16 fis'16 gis'16 ais'16 fis'16 f'16 dis'16 
      | cis'16 c'16 fis'16 f'16~^\markup{\left-align \small vib} f'8~ f'32 dis'16 cis'32~ cis'16 c'32 ais16 a16 cis'32 fis4~^\markup{\left-align \small vib} 
      | \tuplet 6/4 {fis4 f16 a16~} a16 c'16 ais16 dis16~ dis16 d16 b16 fis16 \tuplet 3/2 {e'8 b8 a8} 
      | gis4.^\markup{\left-align \small vib} cis'8~^\markup{\left-align \small vib} cis'4~ \tuplet 6/4 {cis'8 e'16 g8 fis16~} 
      \bar "||" fis8 a16 b16 \tuplet 6/4 {e'16 f'16 e'16 d'16 g8~^\markup{\left-align \small vib}} g4. a16 b16 
      | e'16 cis'16 d'16 e'16~ \tuplet 6/4 {e'16 a'16 b'16 a'16 g'16 c'16~} c'8 ais4.~^\markup{\left-align \small vib} 
      | \tuplet 10/8 {ais32 g'16 f'16. fis'32 g'32 fis'32 e'32} d'16 b16 a16 g16 \tuplet 5/4 {gis16 b16 d'16 f'16 dis'16} \tuplet 5/4 {e'16 cis'16 b16 g16 f16} 
      | fis16 a16 b16 e'16 d'4.^\markup{\left-align \small vib} d''16 ais'16 \tuplet 3/2 {fis'8 c'8 b8\glissando } 
      | e'16 b16 d'16 e'16 f'16 g'16 gis'16 a'16~ a'8 g''16 dis''16 b'16 g'16 fis'16 f'16 
      | e'16 g16 a16 b16 d'16 b16 c'16 d'16 e'16 g'16 a'16 cis''16 fis'4~^\markup{\left-align \small vib} 
      | fis'16 f'8\glissando  a'16 \tuplet 6/4 {dis'16 f'16 e'16 d'16 cis'16 a16} c'16 a16 f16 c16~ c16 a16 f8 
      | e4 dis16 fis16 cis'16 b16 dis16 f16 c'16 ais16 d'16 f'16 gis'16 f'16 
      \bar "||" fis'4.^\markup{\left-align \small vib} dis8 \tuplet 3/2 {f8 dis8 f8~^\markup{\left-align \small vib}} \tuplet 6/4 {f4~ f16 dis16} 
      | ais2~^\markup{\left-align \small vib} \tuplet 3/2 {ais8 c'8 cis'8} ais16 c'16 gis16 e16 
      | f4.^\markup{\left-align \small vib} gis16 ais16 c'16 dis'16 cis'16 ais16 fis4~^\markup{\left-align \small vib} 
      | \tuplet 6/4 {fis8 e16 f16 gis16 c'16} dis'8 cis'8 c'8 ais8~^\markup{\left-align \small vib} \tuplet 6/4 {ais4~ ais16 fis16} 
      | dis4. fis8 ais8\glissando  cis'16 ais16~ \tuplet 6/4 {ais16 gis16 fis8 cis16 dis16} 
      | f4.^\markup{\left-align \small vib} f8~ \tuplet 3/2 {f8\glissando  fis8 a8} c'8 cis'16 f16 
      | a8 c'8~^\markup{\left-align \small vib} c'4. ais16 f16 \tuplet 6/4 {dis8 c8 cis16 dis16~} 
      | dis16 f16 ais16 b16~^\markup{\left-align \small vib} b4. r8 r4\bar  ".."
    }
    >>
>>
}
