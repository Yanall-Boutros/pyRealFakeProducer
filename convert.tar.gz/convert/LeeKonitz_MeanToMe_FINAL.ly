\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Mean to Me"
  composer = "Lee Konitz"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble_8"
    \key es \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              | r1 
      | aes1:maj | bes2:7 es2:7 | aes1:maj | des2:7 c2:7 | f1:min7 | des2:7 c2:7 | f1:7 | f2:min7 bes2:7 
      | es2:maj e2:dim | f2:min7 bes2:7 | es2:maj bes4:min7 es4:7 | aes2:maj des2:7 | g2:min7 c2:7 | f2:min7 bes2:7 | es2:maj c2:min7 | f2:min7 bes2:7 
      | es2:maj e2:dim | f2:min7 bes2:7 | es2:maj bes4:min7 es4:7 | aes2:maj des2:7 | g2:min7 c2:7 | f2:min7 bes2:7 | es2:maj c2:9+ | f2:min7 bes2:7 
      | es2:maj e2:dim | f2:min7 bes2:7 | es2:maj bes4:min7 es4:7 | aes2:maj des2:7 | g2:min7 c2:7 | f2:min7 bes2:7 | es2:maj c2:min7 | es2:maj es2:7 
      | aes1:maj | bes2:7 es2:7 | aes1:maj | des2:7 c2:7 | f1:min7 | des2:7 c2:7 | f1:7 | c1:7 
      | es2:maj e2:dim | f2:min7 bes2:7 | es2:maj bes4:min7 es4:7 | aes2:maj des2:7 | g2:min7 c2:7 | f2:min7 bes2:7 | es2:maj c2:min7 | f2:min7 bes2:7 
      | es2:maj e2:dim | f2:min7 bes2:7 | es2:maj bes4:min7 es4:7 | aes2:maj des2:7 | g2:min7 c2:7 | f2:min7 bes2:7 | es2:maj c2:min7 | f2:min7 bes2:7 
      | es2:maj e2:dim | f2:min7 bes2:7 | es2:maj bes4:min7 es4:7 | aes2:maj des2:7 | g2:min7 c2:7 | f2:min7 bes2:7 | es2:maj c2:min7 | es2:maj bes4:min7 es4:7 
      | aes1:maj | bes2:7 es2:7 | aes1:maj | des2:7 c2:7 | f1:min7 | des2:7 c2:7 | f1:7 | c1:7 
      | es2:maj e2:dim | f2:min7 bes2:7 | es2:maj bes4:min7 es4:7 | aes2:maj des2:7 | g2:min7 c2:7 | f2:min7 bes2:7 | es2:maj c2:min7 | f2:min7 bes2:7 
      | es1:maj|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 139
      \set Score.currentBarNumber = #0
     
      \bar "||" \mark \default r2 c''4 c''4 
      \bar "||" \mark \default \tuplet 3/2 {ais'4 gis'8~^\markup{\left-align \small vib}} gis'4 r2 
      | r4 \tuplet 3/2 {c''4 b'8} c''8 g'8 \tuplet 3/2 {ais'4 ais'8~} 
      | ais'8 gis'8~^\markup{\left-align \small vib} gis'2 \tuplet 3/2 {c''4 ais'8~^\markup{\left-align \small vib}} 
      | ais'4 \tuplet 3/2 {cis''4 c''8~^\markup{\left-align \small vib}} c''4~ c''16 e''8 g''16~ 
      | g''16 f''8 c''4.^\markup{\left-align \small vib} gis'8 g'16~ g'16 f'8 dis'16~ 
      | dis'16 d'8 c'16~ \tuplet 5/4 {c'8 cis'16 e'16 g'16~} g'16 a'8 ais'16 c''8 d''8~^\markup{\left-align \small vib} 
      | d''4 c''8 f'4.^\markup{\left-align \small vib} r4 
      | r8 ais'8 a'8 gis'8 \tuplet 3/2 {fis'4 g'8} c''8 ais'8 
      \bar "||" \tuplet 3/2 {g'4 dis'8} f'8 fis'8 \tuplet 3/2 {g'4 dis'8} f'8 g'8 
      | gis'8 gis'8 g'8 f'8~ \tuplet 6/4 {f'4~ f'16 f'16} ais'4 
      | r1 
      | r4 dis''8 cis''8 dis''8 cis''8 b'8 ais'8 
      | b'8 ais'8 a'8 ais'8 d''8 c''8 ais'8 g'8 
      | \tuplet 3/2 {f'4 dis'8~} \tuplet 6/4 {dis'16 f'4 dis'16} \tuplet 3/2 {gis'4 g'8} f'4 
      | ais'4.^\markup{\left-align \small vib} r8 r4 r16 c''8 g'16~^\markup{\left-align \small vib} 
      | g'4 \tuplet 3/2 {f'4 dis'8~} dis'4 \tuplet 3/2 {c'4 ais8~^\markup{\left-align \small vib}} 
      \bar "||" \mark \default ais4~ ais16 c'8 dis'16 g'4 dis'16 g'8.~ 
      | \tuplet 6/4 {g'16 ais'4 g'16} \tuplet 3/2 {ais'4 ais'8~} ais'16 c''8 ais'16~ ais'16 g'8 dis'16~ 
      | \tuplet 6/4 {dis'16 f'4 dis'16} \tuplet 3/2 {f'4 g'8~} \tuplet 6/4 {g'16 f'4 dis'16~} dis'8. dis'16~ 
      | \tuplet 6/4 {dis'16 ais'4 gis'16} \tuplet 3/2 {ais'4 b'8~} b'16 ais'8 gis'16~ \tuplet 5/4 {gis'16 g'8 ais'16 c''16} 
      | dis''2 r2 
      | r2. d''8 c''8 
      | ais'4^\markup{\left-align \small vib} g'8 f'8 e'8 g'8 c''8 ais'8 
      | gis'8 g'8 f'8 dis'8~ dis'16 d'8 fis'16 ais'8 cis''8\glissando  
      \bar "||" d''8 f''8 \tuplet 3/2 {d''4 c''8~} c''16 ais'8 g'16~ g'8 f'8 
      | dis'16 f'8 g'16 gis'4~ gis'16 f'8 g'16 gis'8 a'8~ 
      | a'16 ais'8 g'16~ g'16 ais'8 c''16~ c''16 dis''8 c''16~ c''16 ais'16 g'16 dis'16~ 
      | dis'16 f'16 g'16 f'16~ f'16 dis'16 f'16 dis'16~ dis'16 cis'16 dis'16 cis'16~ cis'16 b16 cis'16 b16~ 
      | \tuplet 6/4 {b16 ais8. c'16 ais16~} \tuplet 6/4 {ais8 g16 gis16 ais16 c'16~} c'16 dis'8 c'16~^\markup{\left-align \small vib} c'4 
      | r2 r8. g'16 \tuplet 3/2 {ais'8 c''8 d''8} 
      | dis''8 d''8 c''8 b'8 \tuplet 3/2 {ais'8 g'8 dis'8~} dis'16 gis'16 ais'16 gis'16~ 
      | gis'16 g'8 f'16~ f'8 e'8 \tuplet 3/2 {d'8 dis'4} d'16 cis'8 e'16~ 
      \bar "||" e'16 dis'8 c''16~^\markup{\left-align \small vib} c''4 r4 r8. dis'16~ 
      | \tuplet 6/4 {dis'16 f'4 dis'16~} dis'16 g'8 gis'16~ gis'16 ais'8 gis'16~ gis'16 g'8 f'16~ 
      | f'16 dis''8 c''16~ c''16 cis''8 dis''16~ dis''16 c''8 gis'16~ gis'16 ais'8 c''16~ 
      | c''8 cis''8 ais'8 c''8 cis''8 ais'8~ \tuplet 6/4 {ais'8 g'8 gis'16 ais'16} 
      | c''4.^\markup{\left-align \small vib} r8 r2 
      | r8. gis'16 ais'8 c''8\glissando  \tuplet 3/2 {cis''4 b'8} c''8 ais'8 
      | g'8 gis'8 a'8 c''8 \tuplet 3/2 {g'4 fis'8} \tuplet 3/2 {f'4 dis'8} 
      | d'8 f'8~ f'16 c'8 b16~ b16 ais8 d'16 fis'8 a'8 
      \bar "||" \tuplet 3/2 {c''4 ais'8~^\markup{\left-align \small vib}} ais'4 \tuplet 3/2 {g'4 dis'8} f'8 g'8 
      | gis'8 ais'8 gis'8 g'8 f'4 g'4 
      | ais'2^\markup{\left-align \small vib} r2 
      | r4 r32 dis''32~ dis''8 b'32 gis'32 \tuplet 3/2 {fis'4 gis'8~} \tuplet 6/4 {gis'8.\glissando  ais'16 gis'16 fis'16} 
      | f'4 dis'16 c'8 dis'16 \tuplet 3/2 {g'4 ais'8~} ais'16 c''8 ais'16~ 
      | ais'16 dis''8 f''16~ f''16 dis''8 c''16~ c''16 ais'8 g'16~ g'16 f'8 dis'16 
      | f'8 dis'8 d'8 dis'8~ dis'16 d'8 cis'16~ cis'16 c'16 dis'16 g'16~ 
      | g'16 ais'8 a'16~ \tuplet 5/4 {a'16 gis'8 a'16 ais'16~} \tuplet 6/4 {ais'8 g'8 fis'16 f'16~^\markup{\left-align \small vib}} f'4 
      \bar "||" \mark \default r4 ais'8 c''16 dis''16~ dis''16 cis''16\bendAfter #+4  d''16 cis''16~ cis''16 c''8 b'16 
      | ais'8 gis'8 f'8 fis'8 \tuplet 3/2 {g'4 ais'8} c''8 dis''8 
      | \tuplet 3/2 {g''4 gis''8~} gis''16 g''8 f''16~ f''16 dis''8 ais'16 g'4~ 
      | g'16 gis'8 g'16 \tuplet 3/2 {gis'4 ais'8~} ais'16 b'8\glissando  ais'16 gis'16 g'8. 
      | ais'16 c''8 dis''16~^\markup{\left-align \small vib} dis''4 r2 
      | r2 r8 g'8 \tuplet 3/2 {ais'4 g'8} 
      | \tuplet 3/2 {ais'4 g'8} e'8. c'16 \tuplet 3/2 {dis'4 d'8~} d'16 cis'8 b16~ 
      | b16 c'8 gis'16~ gis'8. c'16 d'4 ais'8 g'8~ 
      \bar "||" g'8. dis'16~ dis'16 f'8 dis'16~ dis'16 b16 dis'16 g'16 \tuplet 3/2 {ais'8 d''8 c''8} 
      | dis''8 c''16 gis'16 f'16 fis'16 g'16 gis'16 a'16 ais'16 g'16 dis'16 c'8 f'16 e'16 
      | dis'8 f'16 g'16 gis'16 a'16 ais'16 c''16 ais'16 a'16 ais'16 dis''16 \tuplet 5/4 {cis''8 dis''16 cis''16 c''16~} 
      | \tuplet 6/4 {c''16 b'8 ais'16 a'16 gis'16~} \tuplet 6/4 {gis'16 g'16 f'8 e'16 dis'16~} \tuplet 6/4 {dis'16 f'8 fis'16 f'16 dis'16} cis'16 d'16 f'16 e'16 
      | d'16 dis'16 f'16 g'16 ais'16 c''16 dis''16 c''16 r2 
      | r4 \tuplet 6/4 {r16 dis''8. e''16 dis''16} d''8 c''8~ c''16 ais'8 gis'16 
      | g'4~ g'16 gis'8 a'16~ a'16 ais'8 gis'16~ gis'16 g'8 f'16~ 
      | f'16 dis'8 d'16~ d'16 cis'8 dis'16~ \tuplet 3/2 {dis'8\glissando  e'8 g'8~} \tuplet 6/4 {g'16 b'4 g'16~} 
      \bar "||" \tuplet 6/4 {g'16 ais'4 gis'16} ais'4^\markup{\left-align \small vib} gis'8 g'8~ g'16 f'8 dis'16 
      | c''8. ais'16 cis''4~^\markup{\left-align \small vib} cis''16 f'8 g'16~ g'16 gis'8 a'16~ 
      | a'16 ais'8 g'16 \tuplet 3/2 {dis'4 f'8~} \tuplet 6/4 {f'16 gis'4 f'16~^\markup{\left-align \small vib}} f'4 
      | r2. \tuplet 3/2 {c''8 d''8 f''8} 
      | g''8. c''16~ c''8 r8 r8 f''8 c''8 gis'16 f'16~ 
      | f'16 ais'16 c''16 ais'16~ ais'16 a'16 ais'16 c''16 cis''4~ cis''16 g'8 ais'16 
      | a'8 c''8 g'8 fis'8 f'4 d''8 dis''8~ 
      | dis''16 d''8 c''16~ c''16 ais'8 a'16~ a'16 gis'8 g'16~ \tuplet 6/4 {g'8 f'8. e'16~} 
      \bar "||" e'32 dis'8. g'32 ais'4 dis'4~ dis'16 g'8 ais'16~ 
      | ais'16 f'8 gis'16 c''4~^\markup{\left-align \small vib} c''16 fis'8 a'16 d''8 c''8 
      | \tuplet 3/2 {ais'4 c''8} dis''8 c''8 ais'4~ ais'16 g'8 ais'16 
      | gis'8 r8 r8. ais16~ ais8 b'16 g'16~ g'16 f'8 d'16~ 
      | d'16 ais8 ais16~^\markup{\left-align \small vib} ais4 r2 
      | r4 \tuplet 3/2 {c'8 d'8 dis'8} f'4~ f'32 cis'16 d'16 f'16 e'32 
      | dis'16 f'16 g'16 gis'16 ais'4 fis'16 g'16 ais'16 a'16 g'16 gis'16 ais'16 c''16 
      | dis''16 c''16 cis''16 d''16~ \tuplet 6/4 {d''16 ais'16 b'8 c''16 fis'16~} fis'8 ais'16 a'16 g'16 gis'16 g'16 f'16 
      \bar "||" \mark \default e'16 dis'16 ais'8 r2.\bar  ".."
    }
    >>
>>
}
