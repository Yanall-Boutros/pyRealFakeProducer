\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Body and Soul"
  composer = "David Murray"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble_8"
    \key des \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              | s2 r2 
      | es2:min7 bes2:9- | es2:min7 d2:7 | des2:maj ges2:7 | f2:min7 e2:dim7 | es1:min7 | c2:min5-7 f2:7 | bes4:min7 es4:7 es4:min7 aes4:7 | des2:6 bes2:7 
      | es2:min7 bes2:9- | es2:min7 d2:7 | des2:maj ges2:7 | f2:min7 e2:dim7 | es1:min7 | c2:min5-7 f2:7 | bes4:min7 es4:7 es4:min7 aes4:7 | des2:6 e4:min7 a4:7 
      | d2:maj e2:min7 | fis2:min7 g4:min7 c4:7 | fis4:min7 b4:min7 e4:min7 a4:7 | d1:maj | d2:min7 g2:7 | c2:maj es2:dim | d2:min7 g2:7 | c4:7 b4:7 bes2:7 
      | es2:min7 bes2:9- | es2:min7 d2:7 | des2:maj ges2:7 | f2:min7 e2:dim7 | es1:min7 | c2:min5-7 f2:7 | bes4:min7 es4:7 es4:min7 aes4:7 | des4:6 ges4:7 f4:min5-7 bes4:7 
      | es2:min7 bes2:7|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 66
      \set Score.currentBarNumber = #0
     
      \bar "||" \mark \default r2. \tuplet 10/8 {r8 ais,32 c16 cis16 dis32~} 
      \bar "||" \mark \default dis16 f16 fis16 gis16 \tuplet 5/4 {ais16 c'16 cis'16 dis'16 f'16~} \tuplet 6/4 {f'16 gis'16 c'8 ais'16 gis'16~} gis'32 cis'32 fis'16 f'16 cis'32 dis'32~ 
      | \tuplet 3/2 {dis'8 gis8 ais8~^\markup{\left-align \small vib}} ais4 ais'32 b'32 ais'32 fis'32 dis'32 b16\glissando  a32 gis16 ais16 fis16 gis16~ 
      | gis32 fis32 f16 cis16 dis32 ais,32~ ais,16 dis16 ais16 dis'16 ais'8 gis'8^\markup{\left-align \small vib} r4 
      | \tuplet 5/4 {r16 c''16 cis''16 c''16 ais'16} gis'16 c''16 gis'16 ais'16 \tuplet 6/4 {fis'16 gis'8 f'16 b'16 e'16~} e'32 gis'32 cis'16 fis'32 b32 e'32 ais32 
      | \tuplet 6/4 {dis'16 f'16 cis'16 ais16 dis'16 c'16} gis16. ais32 g32\bendAfter #+4  gis32 f32 c32 dis16 f8.~^\markup{\left-align \small vib} \tuplet 12/8 {f8.. cis'16 ais16 fis32~} 
      | \tuplet 6/4 {fis16 b'16 cis''16 b'16\glissando  cis''8} \tuplet 6/4 {ais'16 fis'16 dis''16\glissando  f''8 cis''16~} \tuplet 6/4 {cis''16 cis'8 f'16 dis'16 gis16~} gis16 c'16 f16 gis16~ 
      | \tuplet 5/4 {gis16 ais16 f16 ais,16 dis16~} \tuplet 6/4 {dis16 ais16 gis16 dis'16 cis'16 fis'16} \tuplet 5/4 {dis'16 gis'16 fis'16 ais'16 g'16} f'32 fis'32 f'32 dis'32 f'16 cis'32 ais32 
      | \tuplet 7/8 {dis'32 c'32 gis16 dis32 ais32 g32} c4 e32 dis32 d16 b16 a32 gis32 \tuplet 6/4 {fis16 f16 c'8^\markup{\left-align \small vib} ais16 gis16} 
      \bar "||" \tuplet 6/4 {dis'8^\markup{\left-align \small vib} d'16 cis'16 b16 f'16} \tuplet 6/4 {ais'16 gis'16 fis'16 f'16 c'16 ais16} dis16 c8.~^\markup{\left-align \small vib} \tuplet 10/8 {c8. cis''32\glissando  dis''32 cis''32\glissando  dis''32} 
      | \tuplet 6/4 {cis''16 dis''16 cis''8 cis''16 ais'16~} \tuplet 13/16 {ais'64 cis'32. f'16 ais'64\glissando  c''32 ais'64\glissando  c''64~} \tuplet 6/4 {c''16 gis'16 gis'16 ais16 b16 b16} a'32 ais'32 a'32\glissando  ais'32 cis'16 cis'32 gis32~ 
      | \tuplet 7/8 {gis32 gis32 cis'32\glissando  d'32 cis'32\glissando  d'32 gis32} gis16 b16\glissando  c'16 dis16 ais4^\markup{\left-align \small vib} gis4~ 
      | \tuplet 6/4 {gis16\glissando  cis'16 d'16 cis'8 c'16~} \tuplet 7/8 {c'32 b32 ais16 gis32 ais32 b32~} \tuplet 12/8 {b32 dis'16. fis'32 g'16 a'32 ais'16 d''32 e''32~} \tuplet 10/8 {e''32 f''8. e''32 f''32 e''32} 
      | d''16 e''16 f''8~ f''16 dis''16 fis''8~ fis''16 dis''16 e''16\glissando  f''16~ \tuplet 6/4 {f''8. e''16 b'16 dis''16~} 
      | \tuplet 6/4 {dis''8. cis''16 c''16 b'16} r4 r16 c''32 cis''32 b'32 ais'32 gis'32 fis'32 \tuplet 7/8 {gis'32 f'32 cis'32 b32 f'32 c'32 gis32} 
      | \tuplet 7/8 {dis32 ais32 gis32 fis32 f32 cis32 dis32} ais,16 dis16 ais16 gis32 dis'32~ \tuplet 6/4 {dis'16 cis'16 gis'16 fis'16 f'8~} \tuplet 12/8 {f'32 dis'16 c'16 gis16. dis16 a32\glissando  ais32~^\markup{\left-align \small vib}} 
      | \tuplet 9/8 {ais8.. c'32 gis32~} \tuplet 6/4 {gis16 ais8 c'16 dis'16 dis'16} \tuplet 6/4 {cis'16 dis'16 fis'8 gis'16 f'16} gis'16 ais'16 b'8~^\markup{\left-align \small vib} 
      \bar "||" \tuplet 7/8 {b'16. d'32 d'32 cis'32 d'32} e'16 fis'16 a'16 fis'16 \tuplet 10/8 {b'16\glissando  cis''8.. b'32~} \tuplet 6/4 {b'16 a'16 fis'16 b'16 a'16 fis'16} 
      | \tuplet 10/8 {e'32 cis'32 b32 fis'32 e'32 cis'32 b32 fis16 a32} b16 fis16 a16 d16~ \tuplet 12/8 {d8.. d16 cis32 d32 e32} \tuplet 7/8 {b16 a16^\markup{\left-align \small vib} f32 fis32 a32} 
      | \tuplet 5/4 {f16\glissando  fis16 a16 d'16 e'16} cis'16 gis8.~^\markup{\left-align \small vib} \tuplet 10/8 {gis16. cis''32 b'32\bendAfter #-4  fis'32 e'32 gis'32 a'32 fis'32} \tuplet 10/8 {g'32 fis'32 e'32 fis'32 f'8~^\markup{\left-align \small vib} f'32 fis'32\glissando } 
      | \tuplet 12/8 {g'16 gis'16 b'32 c''16 d''16 b'32 ais'32 a'32} \tuplet 9/8 {gis'16 gis'32 f'32 cis'32 b32 dis'32 c'32 gis32} ais16 f16 gis8~^\markup{\left-align \small vib} \tuplet 3/2 {gis8 f8 d8} 
      | \tuplet 5/4 {d16 f16 a16 d'16 a'16~} \tuplet 5/4 {a'16 f'16 d'16 cis''16\glissando  d''16} \tuplet 3/2 {c''8 b'16 r8.} r4 
      | \tuplet 6/4 {r16 d''8 f''16 e''16 d''16~} d''16 c''16 b'16 d'16 d''16 c''16 c'16 ais'16 a'16 gis'16 gis'16 ais'32 b'32~ 
      | b'16 g'16 gis'16 a'16 fis'16 g'16 d'16 f'16 \tuplet 13/16 {dis'16 e'32. e'32. f'32 cis'64~} cis'16 dis'16 d'16 ais16 
      | c'16 b16 dis16 e16~ \tuplet 6/4 {e8. ais16 b16 e16~} \tuplet 6/4 {e16 dis16 ais16\glissando  c'16 b16 dis16~} \tuplet 6/4 {dis16 e8 ais16 gis16 a16} 
      \bar "||" \tuplet 5/4 {ais16 b16 cis'16 dis'16 f'16} \tuplet 5/4 {c'16 gis16 dis16 c16 ais,16} \tuplet 6/4 {dis8 b16 c'16 ais16 gis16~} gis16 dis'16 b'16 gis'16~ 
      | \tuplet 6/4 {gis'16 ais'16 fis'8 f'16 c'16~} c'32 ais16. dis32 ais,16 a,32~ \tuplet 6/4 {a,16 gis,8 ais16 b16 ais16} \tuplet 12/8 {b16. e'16. g'32\glissando  gis'16 a'32 ais'32 a'32} 
      | \tuplet 6/4 {ais'16\glissando  b'16 c''16 cis''16 d''16 dis''16~^\markup{\left-align \small vib}} dis''4 r4 \tuplet 6/4 {r16 c'16 f'16 f'16 gis'8} 
      | c''16 c''16 c''16 gis'16 \tuplet 5/4 {dis'16 b'16 gis'16 dis'16 cis'16} \tuplet 6/4 {c''8 gis'16 dis'16 b'16 ais'16} \tuplet 3/2 {cis'8 gis'4~^\markup{\left-align \small vib}} 
      | \tuplet 10/8 {gis'8.. gis'32 ais'32 c''32~} c''32 gis'32 ais'32 gis'32 f'32 cis'32 gis'32 f'32 cis'32 ais32 dis'32 c'32 gis32 f32 ais32 e'32~ \tuplet 10/8 {e'32 dis''32\glissando  e''32 gis'32 d''32 cis''32 b'32 dis''32 f''32 e''32} 
      | f''32 cis'32 fis''32 g''32 fis''32\glissando  g''16.~ \tuplet 11/8 {g''32 fis''32 e''32 c''32 f'32 cis'32 a16 dis'32 gis''32 ais''32~} \tuplet 6/4 {ais''16 ais''16\glissando  b''16 b''8.~} \tuplet 6/4 {b''16\glissando  dis''16 b''16\glissando  cis'''16 dis'''16 e'''16} 
      | cis'''16 dis'''16 c'''16 fis''16 \tuplet 5/4 {dis''16 f''16 dis''16 cis''16 c''16~} \tuplet 6/4 {c''16 dis'16 ais'16 gis'16 gis'16 g'16} \tuplet 5/4 {f'16 c'16 dis'16 cis'16 gis16} 
      | \tuplet 5/4 {c'16 ais16 f16 ais16 dis16} \tuplet 6/4 {ais16 gis16 f16 cis16 dis16\glissando  c'16} \tuplet 6/4 {ais8 b16 c'16 c'16 ais16} \tuplet 5/4 {gis16 fis16 f16 dis16 f16} 
      \bar "||" cis16 c16 ais,16 dis16~^\markup{\left-align \small vib} dis4 r2\bar  ".."
    }
    >>
>>
}
