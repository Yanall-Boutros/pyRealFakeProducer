\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Riverboat Shuffle"
  composer = "Bix Beiderbecke"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble"
    \key aes \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              | r1 | s1 
      | aes1 | aes2. a4:dim | es1:7 | s1 | aes1 | s2. a4:dim | es1:7 | s1 
      | aes1 | aes1:7 | des1 | des2:7 c4:7 b4:7 | bes1:7 | s1 | es4:7 r2. | s1 
      | aes1 | s2. a4:dim | es1:7 | s1 | aes1:7 | s1 | des1 | s1 
      | des1:min | s1 | aes1 | f2:7 s2 | bes1:7 | es1:7 | aes1|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 211
      \set Score.currentBarNumber = #-1
     
      | \tuplet 3/2 {dis''4 gis''8~} gis''8 c''8 dis''8 gis'8 c''4 
      | dis'4 e'4 f'4^\markup{\left-align \small vib} r4 
      \bar "||" \mark \default r8. dis''16~ dis''4 f''8 c''8 dis''4 
      | c''8 gis'8 g'8 ais'4 gis'8 g'8 f'8 
      | ais'8. fis'16~ fis'8. f'16~ f'8 dis'16 c'16~ c'4 
      | dis'8 f'8 dis'4 dis'4.^\markup{\left-align \small vib} r8 
      | r4 \tuplet 3/2 {dis''4 f''8} gis''8 dis''8 f''8 c''8~ 
      | c''8 dis''8 c''8 gis'8 g'8 ais'8 gis'4 
      | ais'8. ais'16~ ais'4 fis'8 dis'8~ dis'8. f'16~^\markup{\left-align \small vib} 
      | f'4 r4 r8 a'8\glissando  b'8. ais'16~^\markup{\left-align \small vib} 
      | ais'4 r4 ais'4..^\markup{\left-align \small vib} ais'16~ 
      | ais'8 cis''4 ais'16 cis''16~ cis''8 ais'16 e''16\glissando  f''8 r8 
      | r4 ais'8. ais'16~ ais'8 gis'8 f'4 
      | ais'8. ais'16~ ais'8 ais'8 gis'8 g'8 f'4 
      | gis'4 \tuplet 3/2 {d'8 gis'8 ais'8} d''4 \tuplet 3/2 {ais8 d'8 f'8} 
      | ais'4 ais'4 ais'4^\markup{\left-align \small vib} r4 
      | r4 ais'8 r8 \tuplet 6/4 {r4 r16 b'16~} b'4 
      | ais'4 ais'4 ais'4^\markup{\left-align \small vib} gis'8 r8 
      \bar "||" r4 dis'8 f'8 gis'8 c''8 \tuplet 3/2 {dis''4 c''8} 
      | gis'4 ais'8. gis'16~ gis'8 ais'8 g'4 
      | gis'8 ais'8 \tuplet 3/2 {g'4 gis'8~} gis'8 f'4 dis'8 
      | f'4^\markup{\left-align \small vib} r4 \tuplet 3/2 {r8 gis8 c'8} dis'4 
      | gis'8 ais'8 gis'4 ais'2^\markup{\left-align \small vib} 
      | cis''8 b'8 \tuplet 3/2 {ais'4 gis'8~} gis'8 ais'8 e'4 
      | cis'4.^\markup{\left-align \small vib} gis8 cis'8 f'8 \tuplet 6/4 {gis'4 f'16 gis'16~^\markup{\left-align \small vib}} 
      | gis'4 r2 \tuplet 3/2 {gis'8 ais'8 gis'8} 
      | cis''4 gis'16 ais'16 gis'16 b'16~ b'8. gis'16~ gis'8 ais'8~ 
      | ais'8 gis'8 f'8 gis'4 ais8 cis'8 f'8~ 
      | f'8 f'8~^\markup{\left-align \small vib} f'8. f'16~^\markup{\left-align \small vib} f'4 r4 
      | \tuplet 3/2 {c''4 f''8~} f''8 dis''8 cis''8 c''8 ais'8 gis'8 
      | c''4 c''4 ais8 d'16 f'16~ f'8 gis'8 
      | \tuplet 3/2 {g'4 cis''8~} cis''8 ais'16 g'16~ g'8 dis'8 c''8 gis'8 
      | g'4^\markup{\left-align \small vib} r2.\bar  ".."
    }
    >>
>>
}
