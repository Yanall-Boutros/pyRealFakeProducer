\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Soul Station"
  composer = "Hank Mobley"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble_8"
    \key es \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              | es1:7 | s1 
      | es1:7 | s1 | s1 | s1 | aes1:7 | s1 | bes1:7 | s1 
      | es1:7 | bes2:min7 es2:7 | aes1:7 | a1:dim | es2:7 c2:7 | f2:min7 bes2:7 | es1:7 | s1 
      | s1 | s1 | s1 | s1 | aes1:7 | s1 | bes1:7 | s1 
      | es1:7 | bes2:min7 es2:7 | aes1:7 | a1:dim | es2:7 c2:7 | f2:min7 bes2:7 | es1:7 | s1 
      | s1 | s1 | s1 | s1 | aes1:7 | s1 | bes1:7 | s1 
      | es1:7 | bes2:min7 es2:7 | aes1:7 | a1:dim | es2:7 c2:7 | f2:min7 bes2:7 | es1:7 | s1 
      | s1 | s1 | s1 | s1 | aes1:7 | s1 | bes1:7 | s1 
      | es1:7 | bes2:min7 es2:7 | aes1:7 | a1:dim | es2:7 c2:7 | f2:min7 bes2:7 | es1:7 | s1 
      | s1 | s1 | s1 | s1 | aes1:7 | s1 | bes1:7 | s1 
      | es1:7 | bes2:min7 es2:7 | aes1:7 | a1:dim | es2:7 c2:7 | f2:min7 bes2:7 | es1:7 | s1|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 102
      \set Score.currentBarNumber = #-1
     
      \bar "||" \mark \default dis'4 c'8\glissando  cis'8 ais8. gis16 r4 
      | r8 ais'16 c''16~ c''8 ais'8 \tuplet 7/8 {dis'16 gis'16. g'32 dis'32~} dis'16 ais16. gis16 g32~ 
      \bar "||" \mark \default g8 dis'8~^\markup{\left-align \small vib} dis'2 r4 
      | gis'16 ais'16 gis'16 dis'16~ dis'8.. gis'32~ \tuplet 3/2 {gis'8 g'8 dis'8~} dis'8. c'16 
      | dis'8 dis'8 r4 r8 r32 g32 ais32 cis'32~ \tuplet 3/2 {cis'8 f'8 g'8~} 
      | g'16 ais'16 c''4 g'8~ \tuplet 6/4 {g'8 a'16 ais'16 g'16 dis'16} cis'8. dis'16~ 
      | dis'16 b16\glissando  c'8~ c'8. gis'16~ gis'4 r4 
      | r8. gis'16~ \tuplet 3/2 {gis'8 gis'8 ais'8} \tuplet 3/2 {fis'8 f'8 dis'8~} dis'4~ 
      | \tuplet 6/4 {dis'4 a'16\bendAfter #+4  gis'16} ais'4.^\markup{\left-align \small vib} gis'8 gis'16 g'16 f'16 dis'16~ 
      | dis'32 d'32 c'16 ais16. g32~ \tuplet 5/4 {g16 gis16 a16 c'16 d'16} g'16 f'16 d'8 r4 
      \bar "||" \tuplet 6/4 {r4 c'16 ais16} dis'16. f'16. fis'32 g'32~ g'16 gis'8 ais'16~ ais'16 fis'16 g'16 dis'16~ 
      | dis'8. a32 b32 \tuplet 10/8 {d'32 dis'16. f'16. fis'16\glissando  g'32~} g'16 c''8 f'16\glissando  \tuplet 3/2 {g'8 dis'4~} 
      | dis'8 gis16 b16~ b16 c'16 dis'16 f'16~ \tuplet 10/8 {f'32 fis'8 dis'16.\glissando  g'32 a'32} gis'4 
      | \tuplet 3/2 {fis'8 dis'8 ais8~} ais16 gis16 dis16 fis16~^\markup{\left-align \small vib} fis4 r4 
      | r4 r8. c''32 b'32~ \tuplet 6/4 {b'16 ais'16 gis'8 g'16 f'16~} \tuplet 5/4 {f'16 e'16 cis'16 c'16 ais16~} 
      | ais16 a16 c'16 dis'16 g'4 gis8 g'16 gis'16 g'16 f'16 d'16 b16 
      | ais8 dis'8~ dis'32 dis'8. ais32 gis8 dis'8 a8 dis'8 
      | \tuplet 3/2 {ais8 dis'4^\markup{\left-align \small vib}} r4 \tuplet 3/2 {r8 dis'8 dis'8~} \tuplet 6/4 {dis'16 g'16 gis'16 g'8 dis'16~} 
      \bar "||" \mark \default dis'8 dis'8 dis'8 r8 \tuplet 3/2 {r8 dis'8 dis'8~} dis'16 gis'16 ais'16 gis'16 
      | fis'16 dis'8 dis'16 r4 \tuplet 3/2 {r8 dis'8 dis'8~} \tuplet 6/4 {dis'16 g'16 gis'16 g'16 dis'8~} 
      | dis'8 d'8 dis'16 dis'8. dis'16 dis'8. dis'8. cis'16 
      | \tuplet 3/2 {g'8 dis'4} dis'2^\markup{\left-align \small vib} c''8 dis'8~ 
      | dis'8 r8 r2 \tuplet 6/4 {dis'8 f'8 gis'16 ais'16~} 
      | \tuplet 3/2 {ais'8 ais'8\glissando  c''8} ais'16\glissando  c''16 ais'16\glissando  c''16 gis'8 dis'8 dis'4^\markup{\left-align \small vib} 
      | r2 d''16 c''16 ais'16 a'16 \tuplet 3/2 {gis'8 g'8 f'8} 
      | \tuplet 3/2 {e'8 g'8 f'8} \tuplet 6/4 {dis'8 cis'16 d'16 f'16 c''16} ais'16 a'16 gis'16 dis'16 f'16 g'8. 
      \bar "||" \tuplet 6/4 {gis'16 f'16 dis'4~} dis'8. dis'16 f'16\glissando  g'8 ais'16 \tuplet 3/2 {dis''4 c''8~} 
      | \tuplet 6/4 {c''16\glissando  cis''4 c''16} \tuplet 6/4 {b'16 ais'16 gis'8 g'16 f'16} \tuplet 3/2 {dis'8 d'8 cis'8} \tuplet 6/4 {fis'16 c''8. ais'16 c''16} 
      | b'32 g'16 f'16 dis'16 cis'32 c'16 dis'16 f'8 gis'4^\markup{\left-align \small vib} r4 
      | r8 ais'16\glissando  c''16~ c''8\glissando  g'16 a'16 f'16\glissando  fis'16 d'16\glissando  dis'16 ais16\glissando  c'16 gis16\glissando  a16 
      | ais8 g'8 r4 g'8 e'8~ \tuplet 6/4 {e'8. g'8 e'16} 
      | f'8 c'8~ \tuplet 6/4 {c'16 dis'16\glissando  e'8. c'16} dis'16 c'16 d'8 \tuplet 3/2 {ais'8 ais'8 fis'8} 
      | dis'2 dis'4 g'16\glissando  gis'16 g'16 dis'16 
      | ais16 dis'8.^\markup{\left-align \small vib} r2 \tuplet 6/4 {r16 c'16 dis'16 f'8 c'16} 
      \bar "||" \mark \default dis'4.^\markup{\left-align \small vib} ais8 gis4 \tuplet 3/2 {dis'4 f8\glissando } 
      | g4 r2 \tuplet 9/8 {c'16. dis'16. f'16 c'32\glissando } 
      | dis'4. ais8 gis4 dis'8. f32 g32~ 
      | g4 r2 \tuplet 3/2 {f'8 gis'8 ais'8} 
      | \tuplet 3/2 {f'8 gis'4~} gis'8 dis'8 cis'4 fis'16 gis'8 c'16~^\markup{\left-align \small vib} 
      | c'4 r2 d'16 e'16 f'16 g'16~ 
      | \tuplet 3/2 {g'8 gis'8 ais'8~} ais'16 ais'16\glissando  c''8~ c''16 gis'16 g'16 f'16~ \tuplet 6/4 {f'16 e'16 c'16 dis'8 cis'16~} 
      | cis'32 d'32~ d'8 g'32 b'32 ais'8 r8 r2 
      \bar "||" r8 b'16\glissando  cis''16 b'16\glissando  cis''16 ais'16 dis'16~ dis'16 gis'8 gis'16 fis'8 dis'8 
      | f'16\glissando  g'8 gis'16 g'16 dis'16 d'16 fis'16 \tuplet 7/8 {g'16 c''16. ais'32 c''32~} c''16 g'16 f'16 dis'16 
      | \tuplet 6/4 {cis'16 c'16 dis'8 f'16 g'16} ais'4~ \tuplet 5/4 {ais'8 gis'16 g'16 f'16} dis'8 r8 
      | r4 \tuplet 3/2 {r8 c''8 ais'8} \tuplet 6/4 {a'8 g'8 fis'16 cis'16} c'16 dis'16 d'16 c'16 
      | ais16 c'16 dis'16 f'16 \tuplet 5/4 {fis'16 g'16 g'16 gis'16 a'16} ais'16 g'16 gis'16 ais'16 g'16 f'16 e'16 g'16 
      | \tuplet 6/4 {f'8 c'8. ais16} c'4. e'16 f'16 \tuplet 6/4 {b8 cis'8. ais16~} 
      | ais8 dis'4 g'8 \tuplet 6/4 {gis'8 g'16 dis'8 ais16~} ais16 gis16 g16 ais16~ 
      | ais8 dis'8 r4 r8.. dis'32~ \tuplet 3/2 {dis'8 dis'8 c'8} 
      \bar "||" \mark \default dis'16 dis'8 c'16~ c'16 dis'8 c'16~ c'16 dis'8 c'16 dis'8 dis'8 
      | c'8 dis'8~ dis'8. dis'16~ dis'16 gis'16\glissando  a'16 gis'16~ gis'32 g'16.\glissando  gis'16. f'32 
      | \tuplet 6/4 {dis'8. dis'8 c'16~} \tuplet 3/2 {c'8 dis'8 c'8} \tuplet 6/4 {dis'8. g'8\glissando  gis'16~} gis'8 fis'16 dis'16~ 
      | dis'8 dis'4 dis'8 \tuplet 9/8 {g'16\glissando  ais'16. gis'32 f'32 dis'32 cis'32} \tuplet 3/2 {gis'8 f'8 dis'8~} 
      | dis'16 dis'16 dis'8 \tuplet 6/4 {r4 r16 dis'16~} \tuplet 3/2 {dis'8 fis'8 dis'8} fis'8 f'16 fis'16 
      | dis'8 dis'8 r8. dis'16 gis'16 fis'16 dis'8 dis'4 
      | f'8 f'8~ \tuplet 6/4 {f'4 cis'16 e'16~} e'16 g'16 f'16 cis'16 dis'16 cis'16 d'16 c'16 
      | ais4^\markup{\left-align \small vib} r4 r16 ais16 c'16 dis'16~ dis'16 gis'8 f'16~ 
      \bar "||" \tuplet 3/2 {f'8 dis'8 dis'8~} dis'8 gis'16 f'32 g'32~ g'16 dis'16 dis'16. fis'32~ \tuplet 6/4 {fis'16 dis'16 g'8 fis'16 g'16} 
      | dis'4 ais'8\glissando  c''8 ais'16 gis'16 g'16 f'16 dis'16 d'16 cis'16 f'16 
      | \tuplet 5/4 {dis'8 cis'16 c'16 f'16} ais'8 a'16 g'16 gis'16 g'16 f'16 e'16 dis'4^\markup{\left-align \small vib} 
      | r4 r16 ais'16\glissando  c''16 f'16\glissando  fis'16 g'16\glissando  a'16 d'16\glissando  \tuplet 3/2 {dis'8 b8\glissando  c'8} 
      | r4 ais16 c'16 dis'16 f'16 fis'16\glissando  g'16 c''16 b'16 ais'16 g'16 e'16 cis'16~ 
      | \tuplet 6/4 {cis'16 fis'16\glissando  g'16 gis'8 gis'16} fis'16 f'16 c'16 c'16 g'16\glissando  gis'16 fis'16 e'16~ e'16 b16 ais16 gis16 
      | g4 dis'4~ \tuplet 3/2 {dis'8 gis8 dis'8~} dis'16 g16\glissando  a16 dis'16 
      | ais4^\markup{\left-align \small vib} r4 r8 d'16 f'16~ f'4~ 
      \bar "||" \mark \default f'8. dis'16 f'8. dis'16 f'8. dis'16 f'4 
      | f'8 f'8 r4 \tuplet 3/2 {r8 gis'8 g'8~} g'16 e'16\glissando  f'8~ 
      | \tuplet 3/2 {f'8 dis'8 d'8} \tuplet 6/4 {cis'8 ais8 dis'16\glissando  f'16~^\markup{\left-align \small vib}} f'2~ 
      | f'8 cis'16 ais16~ ais16 a16 f16 gis16 g8 dis8 r4 
      | r4 gis,8 dis16 gis16~ \tuplet 3/2 {gis8 ais8\glissando  b8} c'16 f'16 e'16 dis'16 
      | cis'16 c'16 dis'16 f'16 g'16 ais'8 g'16 gis'8 dis'8 r4 
      | r4 r8 dis''32 d''32 cis''32 c''32 \tuplet 6/4 {ais'16 gis'8 g'16 f'16 dis'16~} dis'16 d'16 c''16 g'16~ 
      | g'16 a'16\glissando  ais'16 a'16 gis'16 g'16 f'16 dis'16 \tuplet 6/4 {d'16 e'16 gis'16\glissando  ais'16 c''8} ais'16 gis'16 g'16 f'16 
      \bar "||" dis'8 fis'16\glissando  gis'16~ gis'8~ gis'32 f'16 dis'32~ dis'8 dis'8 r4 
      | r16 b'16 c''8 a'8 f'16 g'16 dis'8 dis'8 \tuplet 3/2 {gis'8 g'8 dis'8} 
      | ais16 dis'16 dis'8 \tuplet 10/8 {gis'8 dis'8 g'32 fis'32~} fis'16 dis'8 dis'16~ \tuplet 6/4 {dis'16 gis'8. f'16\glissando  fis'16} 
      | dis'8 dis'8 g'16 gis'16 dis'8 \tuplet 6/4 {fis'8. dis'8 dis'16} gis'8 f'8 
      | dis'8 r8 r8 c''16 b'16 ais'16 gis'16 g'16 f'16 e'16 cis'16 c'16 ais16 
      | a8 g'8 g'8 a8 gis8 fis'8 fis'8 d'8 
      | dis'8 r8 r4 r16 cis'16 dis'8~ \tuplet 6/4 {dis'16 c'16 dis'8 b16 dis'16} 
      | ais4 \tuplet 3/2 {g8 ais8 g8} \tuplet 3/2 {gis8 c'8 dis'8} \tuplet 3/2 {g'8\bendAfter #-4  fis'16 r8.}\bar  ".."
    }
    >>
>>
}
