\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Stompin' at the Savoy"
  composer = "Clifford Brown"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble"
    \key des \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              
      | des1:maj | des2:maj aes2:7 | des1:maj | s2 d2:dim | es1:min7 | aes1:7 | des2:6 bes2:min7 | es2:min7 aes2:7 
      | des1:maj | s2 aes2:7 | des1:maj | s2 d2:dim | es1:min7 | aes1:7 | des1:6 | des1:7 
      | ges2:7 g2:7 | ges1:7 | b2:7 c2:7 | b1:7 | e2:7 f2:7 | e1:7 | a1:7 | aes1:7 
      | des1:maj | s2 aes2:7 | des1:maj | s2 d2:dim | es1:min7 | aes1:7 | des1:6 | es2:min7 aes2:7 
      | des1:maj | s2 aes2:7 | des1:maj | s2 d2:dim | es1:min7 | aes1:7 | des2:6 bes2:min7 | es2:min7 aes2:7 
      | des1:maj | s2 aes2:7 | des1:maj | s2 d2:dim | es1:min7 | aes1:7 | des1:6 | des1:7 
      | ges2:7 g2:7 | ges1:7 | b2:7 c2:7 | b1:7 | e2:7 f2:7 | e1:7 | a1:7 | aes1:7 
      | des1:maj | s2 aes2:7 | des1:maj | s2 d2:dim | es1:min7 | aes1:7 | des1:6 | es2:min7 aes2:7|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 164
      \set Score.currentBarNumber = #1
     
      \bar "||" \mark \default r2 ais'8. ais'16 r4 
      | r4 r8. e''16~ e''8. cis''16~ cis''8 ais'8 
      | \tuplet 3/2 {a'8 ais'8 a'8} \tuplet 3/2 {g'4 gis'8~} gis'4 r4 
      | r8 f'8 \tuplet 3/2 {dis'4 cis'8} \tuplet 3/2 {d'4 b'8~} b'8. a'16~ 
      | \tuplet 3/2 {a'8 ais'8 ais8~} ais16 dis'8 f'16~ f'16 fis'8 gis'16~ \tuplet 6/4 {gis'16 a'16 ais'16 a'16 g'8} 
      | gis'8 fis'8~ \tuplet 3/2 {fis'8 dis'8 e'8} f'8 c'8 dis'8 c'8 
      | cis'8 dis'8 f'8 gis'8 cis'8 f'8 gis'8 b'8 
      | ais'8 ais8 dis'8 fis'8~ fis'16 d'8 a16~ a8. a16 
      \bar "||" gis4.. d'16\glissando  dis'2~ 
      | dis'4. cis'8 dis'8 e'8 dis'16 e'16 dis'16 cis'16~ 
      | \tuplet 6/4 {cis'16 gis4 gis16~} gis8. d'16\glissando  dis'2 
      | r4 r8 cis'8~ \tuplet 3/2 {cis'8 dis'8 f'8} dis'16 f'16 dis'16 cis'16~ 
      | cis'16 a8 ais16~ \tuplet 3/2 {ais8 cis'8 f'8} gis'8 fis'8 cis'8 ais8 
      | \tuplet 6/4 {a4\glissando  e'16 f'16~} f'8 c'8 \tuplet 3/2 {dis'4 cis'8} c'8 cis'8 
      | \tuplet 6/4 {f'4 gis'16 ais'16~} ais'8 cis''8 r2 
      | r2. r8. g''16\glissando  
      \bar "||" gis''4. e''16 cis''16 c''4 cis''8 r8 
      | r8. gis'16 b'8 gis'8 ais'8 gis'8 fis'8 e'8 
      | d'8 dis'8 fis'8 a'8 cis''8 ais'8 b'8 ais'8 
      | a'8 cis''8 gis'8 fis'8 b'8 a'8 fis'8 g'8 
      | gis'8 b8 d'8 fis'8 a'8 g'8 gis'8 b'8 
      | d''4 f''8. f''16~ \tuplet 5/4 {f''16 e''16 f''16 e''16 d''16~} d''16 d''16 cis''16 b'16~ 
      | b'16 gis'16 a'16 ais'16 \tuplet 3/2 {b'4 gis'8} a'8 e'8 cis'8 a8~ 
      | \tuplet 6/4 {a16 gis'16 ais'16 gis'16 fis'8} f'8 dis'8~ dis'16 d'8 gis16 d'8 gis8 
      \bar "||" dis'2. r4 
      | r4 \tuplet 6/4 {r8. dis'8 e'16~} e'4 dis'4~ 
      | dis'4.. e'16~ e'8 gis8 dis'4~ 
      | dis'4 r2. 
      | r4 r8. ais'16~ ais'16 ais'8 ais'16~ \tuplet 3/2 {ais'8 ais'8 ais'8} 
      | ais'4 ais'4 e''8 f''4. 
      | \tuplet 3/2 {cis''4 ais'8~} ais'4 ais'8 r8 r4 
      | r1 
      \bar "||" \mark \default r8 gis''8 ais''8 c'''4 cis'''8 r4 
      | r8 gis''8~ gis''16 ais''8 c'''16~ c'''16 cis'''8 c'''16 ais''8 a''8 
      | \tuplet 3/2 {ais''8 gis''8 g''8} fis''8 ais''8~ ais''16 f''8 dis''16~ dis''8. gis''16~ 
      | \tuplet 3/2 {gis''8 c'''8 f''8} dis''8 cis''8 d''8 f'8 gis'8 b'8 
      | ais'8 b8 dis'8 fis'8~ fis'16 cis'16 dis'16 e'16 \tuplet 3/2 {f'4 d'8} 
      | dis'8 fis'8 ais'8 cis''8 c''16 d''16 c''16 ais'16 \tuplet 6/4 {gis'16 ais'16 gis'8 fis'8} 
      | \tuplet 3/2 {f'8 gis'8 c''8} \tuplet 3/2 {dis''4 c''8} d''8 b'8 \tuplet 5/4 {g'16 gis'16 g'16 e'8} 
      | dis'4~ \tuplet 6/4 {dis'8 fis'16 gis'16 ais'16 cis''16} c''8 ais'8 \tuplet 6/4 {gis'16 ais'16 gis'8 fis'8} 
      \bar "||" f'8. c'16 \tuplet 5/4 {dis'16 f'16 dis'16 c'16 cis'16~} \tuplet 3/2 {cis'8 gis'8 c''8} \tuplet 3/2 {ais'4 f'8} 
      | \tuplet 3/2 {gis'4 fis'8} r2 r8 ais'16 a'16 
      | \tuplet 6/4 {gis'8 f'16 fis'16 e'16 f'16} e'16 dis'16 d'16 cis'16 gis4 gis4 
      | r2 \tuplet 3/2 {b'8 c''8 b'8} ais'8 a'8 
      | gis'16 ais'16 gis'16 g'16 \tuplet 3/2 {fis'8 ais'8 cis''8~} \tuplet 3/2 {cis''8 e''8 f''8~} f''16 dis''8 cis''16 
      | c''8 ais'8 gis'8 g'8~ g'32 fis'32~ fis'8 e''32\glissando  f''32~ f''8 c''8 
      | dis''8 cis''8 c''8 cis''8 gis'8 f'8 dis'8 cis'8 
      | c'8 cis'8 f'8 gis'8 c''8 dis''8 cis''8 b'8 
      \bar "||" gis'8 a'8 ais'4 f'8 gis'8 \tuplet 3/2 {dis'4 c'8} 
      | cis'8 dis'8 e'8 fis'8 gis'8 b'8 ais'8 dis'8 
      | a'8 fis'8 gis'8 dis'8 \tuplet 3/2 {e'4 cis'8} dis'4~ 
      | dis'8 cis''8 b'8 a'8 gis'8 fis'8 e'8 d'8 
      | dis'8 e'8 fis'8 a'16 cis''16 d''16 cis''16 b'8 a'8 g'8 
      | gis'8 r8 r4 g''8 f''8 e''16 fis''16 e''16 d''16 
      | cis''8 e'8 fis'8 gis'8 b'8 a'8 e'8 cis'8 
      | a8 g8 gis8 c'8 d'8 e'8 a'8 g'8 
      \bar "||" g'8 gis'4 ais'8~ \tuplet 6/4 {ais'8. dis'8\glissando  f'16~} f'4~ 
      | f'4~ \tuplet 3/2 {f'8 gis'8 ais'8~} ais'8 b'8 gis'8 gis'8 
      | \tuplet 3/2 {fis'8 g'8 gis'8~} gis'8 f'8 r2 
      | r2. cis''4 
      | \tuplet 3/2 {g''4 fis''8~} fis''2~ fis''8. dis''16\glissando  
      | e''8. cis''16~ cis''8 b'8 gis'8 g'8 fis'8 e'8 
      | r4 cis'8 e'8 f'8 gis'8 ais'8 gis'8 
      | b'4 gis'8 fis'8 e'4 \tuplet 3/2 {dis'4 cis'8}\bar  ".."
    }
    >>
>>
}
