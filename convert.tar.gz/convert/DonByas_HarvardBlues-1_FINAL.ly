\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Harvard Blues"
  composer = "Don Byas"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble_8"
    \key des \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              | s4 r2. 
      | des1:7 | ges2:7 g2:dim | des2 des2:7 | bes2:min7 des2:7 | ges1:7 | s2 g2:dim | des1:7 | s2 a2:dim 
      | aes1:7 | ges1:7 | des1:7|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 98
      \set Score.currentBarNumber = #0
     
      \bar "||" \mark \default r2 r8. gis16~ gis8 ais8~ 
      \bar "||" \mark \default ais4. gis16 fis16 \tuplet 3/2 {f8 dis8 cis8} b,4~ 
      | \tuplet 3/2 {b,8 ais,8 cis8} \tuplet 3/2 {dis8 fis8 ais8} e4. ais16 a16 
      | gis8 cis16 f16~ f4. gis8 cis'8 dis'16 f'16 
      | b4.^\markup{\left-align \small vib} gis8 \tuplet 3/2 {a4 d8~} d4 
      | \tuplet 3/2 {cis4 ais8~^\markup{\left-align \small vib}} ais4~ \tuplet 6/4 {ais4 dis16 fis16~} fis8 cis8 
      | \tuplet 3/2 {dis8 fis8 cis8} dis4 \tuplet 3/2 {g8 cis8 e8~} \tuplet 6/4 {e8. g8 cis16~} 
      | cis16 dis16 e16 f16 \tuplet 3/2 {gis8 cis8 f8~} f4 r4 
      | r8 fis8 \tuplet 3/2 {gis4 cis'8~} cis'16 fis16 g8 cis'8 fis8~^\markup{\left-align \small vib} 
      | fis4. d8 f16 dis16 ais4.~^\markup{\left-align \small vib} 
      | ais8 d8 \tuplet 3/2 {dis4 cis8} \tuplet 3/2 {d8 a4~^\markup{\left-align \small vib}} a4~ 
      | a8 cis4 f8 \tuplet 3/2 {fis8 cis8 fis8} \tuplet 3/2 {g8 cis8 fis8\glissando } 
      | gis2.^\markup{\left-align \small vib} r4\bar  ".."
    }
    >>
>>
}
