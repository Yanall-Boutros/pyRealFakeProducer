\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "U.M.M.G."
  composer = "Joe Henderson"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble_8"
    \key des \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              
      | f1:min5-7 | bes1:7 | es1:min7 | aes1:7 | des2:dim7 des2:6 | des1:maj | des1:min7 | ges1:7 
      | f1:min5-7 | bes1:7 | es1:min7 | aes1:7 | des2:dim7 des2:6 | des1:maj | aes2:min7 des2:7 | aes2:min7 des2:7 
      | g1:min5-7 | c1:9- | f1:maj | s1 | aes1:min5-7 | des1:9- | ges1:min | aes1:7 
      | f1:min5-7 | bes1:9- | es1:min7 | aes1:7 | des1:dim7 | des1:6 | des1:dim | des1:6 
      | f1:min5-7 | bes1:9- | es1:min7 | aes1:7 | des2:dim des2:6 | des1:maj | des1:min7 | ges1:7 
      | f1:min5-7 | bes1:9- | es1:min7 | aes1:7 | des2:dim des2:6 | des1:maj | aes1:min7 | des1:7 
      | g1:min5-7 | c1:9- | f1:maj | s1 | aes1:dim | des1:9- | ges1:min7 | aes1:7 
      | f1:min5-7 | bes1:9- | es1:min7 | aes1:7 | des1:dim | des1:6 | des1:dim | des1:6 
      | f1:min5-7|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 219
      \set Score.currentBarNumber = #1
     
      \bar "||" \mark \default f'8 r8 r2. 
      | r8. c'16 \tuplet 3/2 {dis'4 c'8} d'8 ais8~ ais8. cis'16~ 
      | cis'4 ais4 b8. c'16 r4 
      | r2 r8. c''16~ c''16 ais'8 gis'16~ 
      | gis'8 f'8 \tuplet 3/2 {dis'4 cis'8~} cis'4~ cis'16 c'8 ais16 
      | a8 gis8 fis8 f8 dis16 cis8 dis16~ dis4 
      | ais4. ais8 b8 cis'16 e'16~ \tuplet 3/2 {e'8 gis'8 ais'8~} 
      | \tuplet 3/2 {ais'8 gis'8 e'8} cis'8 b8 \tuplet 3/2 {ais4 gis8} f8 gis8 
      \bar "||" f4. g8 gis8 r8 r4 
      | ais8 b8 dis'8 fis'8 cis''8 b'8 fis'4 
      | \tuplet 3/2 {g'8 gis'4~} gis'2~ gis'8 gis'16 fis'16 
      | cis'8 c'8 \tuplet 3/2 {a4 g8} dis'8 cis'8 c'8 ais8 
      | gis8 fis8 \tuplet 6/4 {f4 dis16 d16} cis'8 r8 r4 
      | r1 
      | r8 ais'8 b'4 ais'8 gis'8 dis'8 fis'8 
      | f'8 e'8 \tuplet 3/2 {dis'4 d'8} \tuplet 3/2 {cis'4 b8} gis8 fis8 
      \bar "||" \tuplet 3/2 {gis8 a8 ais8~} ais8 c'4. cis'4 
      | e'8. g'16~ g'8 c''8 r4 e''8. b''16~ 
      | b''8 ais'4. g''8 r8 r4 
      | ais'16 b'16 c''8~ \tuplet 5/4 {c''8 b'16 a'16 fis'16} \tuplet 3/2 {e'4 f'8} r4 
      | fis'4. cis''8 \tuplet 3/2 {b'8 c''8 a'8~} \tuplet 3/2 {a'8 gis'8 fis'8} 
      | e'8 dis'8 d'16 dis'16 d'16 cis'16 b4. a8 
      | gis4 a8. e16~ e4 r4 
      | r2 r8 gis'8 g'16 gis'16 g'16 f'16 
      \bar "||" ais'4. g'8 gis'8 c'8 r4 
      | r16 g'8 f'16 c'8 dis'8 d'8 ais8 fis4 
      | gis8. ais16~ ais8. b16~ b8. gis16 r4 
      | r8 g16 gis16 ais16 c'16 d'16 e'16 \tuplet 6/4 {f'16 g'16 b'8. g'16} \tuplet 3/2 {e'4 c'8~} 
      | c'8 dis'4 dis'8~ dis'4. dis'8~ 
      | dis'4. cis'8 dis'8 cis'8 \tuplet 3/2 {c'4 ais8~} 
      | \tuplet 3/2 {ais8 gis8 fis8} f8 dis8 \tuplet 3/2 {cis4 dis8} f8 gis8 
      | cis'8 dis'8~ dis'8. gis'16 c''2~ 
      \bar "||" \mark \default c''8 cis''4. ais'4 dis'8 r8 
      | r1 
      | r8 gis'8 fis'8 f'8 gis'4.. fis'16~ 
      | \tuplet 6/4 {fis'16 gis'4 fis'16} gis'8 fis'8 e'4 c'16 cis'16 d'16 dis'16~ 
      | dis'4~ \tuplet 3/2 {dis'8 cis'8 dis'8~} dis'8 cis'8 r4 
      | r4 \tuplet 3/2 {d'4 dis'8~} dis'16 fis'8 f'16 e'8 dis'8 
      | cis'8 b8 ais8. fis16 gis8 r8 r4 
      | r16 fis8 gis16 ais4 b8 cis'4 f'8 
      \bar "||" c''8 gis'8 ais'8 gis'8 e'8 r8 r8. c'16 
      | g'4. fis'8 f'8 e'8 dis'8 d'8 
      | \tuplet 3/2 {cis'4 ais8~} ais16 fis8 d16~ \tuplet 6/4 {d16 f4 cis16} \tuplet 3/2 {f4 dis8} 
      | gis4~ gis16 g16 gis16 fis16~ fis16 d16 e8 \tuplet 3/2 {c4 gis,8~} 
      | gis,4 r4 gis4.. fis16 
      | f8. fis16 gis8 ais8 dis'8. cis'16~ cis'8 r8 
      | r2 r8 ais'8 b'4 
      | ais'8 gis'8 dis'8 fis'8 f'8 e'8 dis'8 d'8 
      \bar "||" cis'8. b'16 c''2. 
      | b'8 c''4. b'16 c''8.~ c''8 g'8~ 
      | g'2 fis'16 g'8.~ g'8 f'8 
      | e'8 d'8 \tuplet 3/2 {c'4 a8} g8 f8 e4 
      | fis4. r8 r2 
      | r8 ais'8 r4 dis'8 f'8 \tuplet 3/2 {ais'4 gis'8~} 
      | gis'4 dis'4 b16 fis'8 e'16~ e'16 dis'8 d'16 
      | cis'8 gis8 fis4 e4 \tuplet 3/2 {dis4 ais8} 
      \bar "||" b4.. dis'16~ dis'16 ais16 b8~ b8. gis16 
      | b4 dis8 d4. d8 gis8 
      | a2 gis8 a8 cis8 c8 
      | r2 gis'8 r8 r8 gis'8~ 
      | gis'8 cis'8 r4 c''8. b'16 c''4 
      | g'8. f'16 g'4 \tuplet 3/2 {e'4 c'8} e'8. c'16~ 
      | c'4 c'4 g8 e8 g4 
      | dis8 e4 c8 \tuplet 3/2 {d4 c8~} c4 
      \bar "||" \mark \default b4. r8 r2\bar  ".."
    }
    >>
>>
}
