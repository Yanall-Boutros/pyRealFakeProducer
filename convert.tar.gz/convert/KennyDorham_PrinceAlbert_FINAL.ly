\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Prince Albert"
  composer = "Kenny Dorham"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble"
    \key f \minor
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              | r1 | s1 
      | f1:min7 | bes1:min7 | es1:7 | aes1:maj | des1:maj | d2:min7 g2:7 | c1:maj | s1 
      | c1:min7 | f1:min7 | bes1:7 | es1:maj | aes1:maj | a2:min5-7 d2:7 | g1:maj | s1 
      | a1:min5-7 | d1:7 | g1:maj | s1 | fis1:min5-7 | b1:7 | e1:maj | c1:7 
      | f1:min7 | bes1:min7 | es1:7 | aes1:maj | des1:maj | des1:min7 | c1:min7 | b1:dim 
      | bes1:min7 | es1:7 | aes1:maj | g2:min5-7 c2:7 | f1:min7 | bes1:min7 | es1:7 | aes1:maj 
      | des1:maj | d2:min7 g2:7 | c1:maj | s1 | c1:min7 | f1:min7 | bes1:7 | es1:maj 
      | aes1:maj | a2:min5-7 d2:7 | g1:maj | s1 | a1:min5-7 | d1:7 | g1:maj | s1 
      | fis1:min5-7 | b1:7 | e1:maj | c1:7 | f1:min7 | bes1:min7 | es1:7 | aes1:maj 
      | des1:maj | des1:min7 | c1:min7 | b1:dim | bes1:min7 | es1:7 | aes1:maj | g2:min5-7 c2:7 
      | f1:min7 | bes1:min7 | es1:7 | aes1:maj | des1:maj | d2:min7 g2:7 | c1:maj | s1 
      | c1:min7 | f2:min7 r2 | bes1:7 | es1:maj | aes1:maj | a2:min5-7 d2:7 | g1:maj | s1 
      | a1:min5-7 | d1:7 | g1:maj | s1 | fis1:min5-7 | b1:7 | e1:maj | c1:7 
      | f1:min7 | bes1:min7 | es1:7 | aes1:maj | des1:maj | des1:min7 | c1:min7 | b1:dim 
      | bes1:min7 | es1:7 | aes1:maj | g2:min5-7 c2:7 | f1:min7|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 153
      \set Score.currentBarNumber = #-1
     
      | \tuplet 3/2 {e'8 dis'8 f'8} \tuplet 6/4 {g'8. gis'8 ais'16~} \tuplet 6/4 {ais'8. c''8 cis''16~} \tuplet 6/4 {cis''8. b'8 c''16~} 
      | c''4 ais'8 gis'16 g'16~ g'8 f'8 e'4 
      \bar "||" \mark \default \tuplet 3/2 {g'4 dis'8} \tuplet 3/2 {g'4 f'8~} f'8 c'8 dis'16 f'16 dis'16 c'16~ 
      | c'16 cis'8 dis'16 \tuplet 3/2 {f'8 gis'8 c''8~} c''16 dis''8 d''16~ d''16 cis''8 c''16~ 
      | c''16 ais'8 a'16~ \tuplet 6/4 {a'16 gis'16 a'16 gis'16 g'8} fis'8 f'8 e'8 c'8 
      | dis'8 c'4 r8 r2 
      | r8 gis''8~ \tuplet 3/2 {gis''8 f''8 dis''8} cis''8 c''8~ c''16 ais'8 gis'16\bendAfter #+4  
      | g'16 gis'8.~ \tuplet 3/2 {gis'8 g'8 f'8} ais'8 r8 r4 
      | \tuplet 6/4 {r16 g'16 g'8 g'16 g'16} e'8 g'8~ g'16 a'8 g'16~ g'8 e'8 
      | \tuplet 3/2 {e'4 d'8} r2. 
      \bar "||" r4 g'16 a'16 b'16 c''16 \tuplet 5/4 {d''8 b'16 c''16 d''16} \tuplet 5/4 {dis''8 b'16 cis''16 c''16} 
      | \tuplet 3/2 {c''8 fis'8 f'8} \tuplet 3/2 {dis'8 g'16 r8.} r4 r16 c''16 cis''16 d''16 
      | f''16 d''16 cis''16 c''16 dis''16 b'16 ais'16 fis'16 d''16 ais'16 a'16 gis'16 \tuplet 6/4 {c''16 gis'8 g'16 f'16 ais'16~} 
      | ais'16 a'16 gis'16 g'16 f'16 dis'16 fis'16 f'16 gis'16 b'16 ais'16 gis'16 \tuplet 6/4 {g'8 f'16 e'8 dis'16~} 
      | dis'16 f'16 fis'16 gis'16~ gis'16 ais'16 g'16 ais'16 \tuplet 6/4 {b'8 c''16 d''16 f''16 e''16~} e''16 dis''16 c''8~ 
      | \tuplet 6/4 {c''8. f''8 e''16~} e''16 dis''8 f''16~ f''8 d''4 c''8 
      | b'8 r8 r8. d'16~ d'8 e'4. 
      | r1 
      \bar "||" d''8. e''16 d''4 \tuplet 3/2 {d'8 d'8 d'8~} d'4~ 
      | d'8 dis'8 \tuplet 3/2 {ais'8 c''4~} \tuplet 6/4 {c''16 b'4 b'16~} b'8. a'16 
      | b'4. g'8 f'8 fis'8 cis'8 e'8~ 
      | \tuplet 6/4 {e'4~ e'16 e'16~} \tuplet 6/4 {e'4 gis'16 g'16} fis'8 gis'8~ gis'16 a'8 b'16~ 
      | b'16 cis''8 e''16~ e''16 dis''8 cis''16~ \tuplet 3/2 {cis''8 b'8 ais'8~} ais'16 a'8 a'16 
      | gis'8 fis'8 \tuplet 3/2 {e'4 dis'8~} dis'4 b'8 a'8 
      | gis'4~ gis'16 dis'16 c'8 cis'4 r4 
      | r1 
      \bar "||" r4 \tuplet 3/2 {g''4 f''8~} f''8 c''8 dis''8 c''8 
      | cis''8 dis''8 f''8 gis''8 g''8 f''8 dis''8 d''8 
      | cis''8 c''8 b'8 g'8 fis'8 fis'8 e'4 
      | dis'8. c'16~ c'4 r4 r8 ais'8 
      | gis'8 a'8 gis'16 f'8 ais'16~ ais'16 gis'8 ais'16 \tuplet 3/2 {gis'8 f'8 ais'8} 
      | gis'8 ais'16 gis'16 \tuplet 3/2 {e'4 b'8~} b'8 r8 r8. ais'16~ 
      | \tuplet 3/2 {ais'8 g'8 gis'8} g'16 dis'8 ais'16~ ais'16 g'8 g'16~ g'16 dis'8 cis''16~ 
      | cis''4~ cis''16 b'8 fis'16~ fis'8 r8 r8. ais'16~ 
      | ais'16 gis'16 ais'16 g'16 f'8 ais'8~ ais'16 gis'16 ais'16 gis'16 f'8 gis'8 
      | b'8 c''8~ c''16 cis''8 d''16~ d''16 dis''8 b'16 \tuplet 3/2 {c''4 ais'8~} 
      | ais'16 gis'8 dis'16 c'4 cis'8. dis'16 r4 
      | r4 \tuplet 6/4 {cis''16 c''8 ais'16 gis'16 g'16~} g'16 f'16 e'16 g'16 \tuplet 6/4 {ais'16 cis''8 c''16 ais'16 gis'16~} 
      \bar "||" \mark \default \tuplet 6/4 {gis'8 f'8 gis'16 g'16} f'16 e'8 fis'16 \tuplet 6/4 {f'16 e'16 f'16 fis'8 gis'16} \tuplet 3/2 {ais'8 c''8 f''8} 
      | \tuplet 5/4 {d''16 b'16 ais'16 gis'16 c''16} r2 \tuplet 6/4 {c''8 c''16 a'16 ais'16 c''16} 
      | cis''16 dis''16 f''16 gis''16 \tuplet 6/4 {g''16 f''8 dis''16 d''16 cis''16} \tuplet 6/4 {d''16 cis''16 ais'16 gis'8.} \tuplet 3/2 {d''8 cis''8 f''8} 
      | dis''16 c''16 cis''16 b'16 c''16 ais'16 a'16 g'16 gis'4 \tuplet 6/4 {ais'16 a'16 ais'16 gis'16 g'8} 
      | fis'16 gis'16 ais'16 a'16 g''16 f''16 r8 r8 c''8 dis''8 cis''8 
      | c''8 gis'8 f'4 \tuplet 6/4 {ais'16 gis'16 g'8. f'16~} f'16 d'16 dis'8 
      | e'8 g'8 a'8 b'8 d''8 b'8 c''8 d''8~ 
      | d''16 f''16 dis''16 e''16 a''8 gis''8 g''8 fis''8 f''8 e''8 
      \bar "||" dis''8 g'8 c''8 dis''8 d''8 c''8 b'8 dis'8 
      | ais'4 \tuplet 3/2 {gis'4 f'8} r4 r8 g''16 gis''16~ 
      | \tuplet 3/2 {gis''8 g''8 f''8~} f''16 e''8 d''16~ d''8 dis''8~ dis''16 cis''16 b'16 ais'16 
      | gis'16 g'8 f'16 r2. 
      | d''8 dis''4 c''8~ c''16 ais'8 gis'16 g'16 gis'8. 
      | g'4 dis'4 f'8 dis'8 d'8 c'8 
      | b8 d'8 e'8 fis'8~ \tuplet 5/4 {fis'16 a'16 ais'16 a'16 fis'16~} fis'16 g'8 a'16~ 
      | a'16 ais'8 b'16~ \tuplet 3/2 {b'8 e''8 dis''8~} dis''16 d''8 b'16~ \tuplet 6/4 {b'16 c''16 cis''16 c''16 b'8} 
      \bar "||" c''8 d''8 e''8 g''4 b''8 \tuplet 3/2 {a''4 g''8} 
      | fis''8 r8 r8 ais''8~ ais''16 f''8 e''16~ \tuplet 3/2 {e''8 dis''8 f''8} 
      | d''8 b'8 c''8 ais'8 \tuplet 3/2 {b'4 fis'8} d'4 
      | e'4 r2. 
      | r2 b''2 
      | ais''8 gis''8~ gis''16 fis''8 e''16~ e''16 dis''8 cis''16 b'8 a'8 
      | gis'8 dis'8~ dis'16 cis'8 dis'16~ dis'8 fis'8 e'4 
      | r1 
      \bar "||" r8. fis''16 g''4~ g''16 f''8 c''16~ c''16 dis''8 c''16 
      | cis''8 dis''8 f''8 gis''8~ gis''16 g''8 f''16~ f''16 dis''8 d''16~ 
      | d''16 cis''8 c''16~ \tuplet 3/2 {c''8 b'8 g'8~} g'16 fis'8 fis'16~ fis'16 e'8 c'16 
      | dis'8 c'4 r8 r4 r8 a'8 
      | ais'4 gis'8 f'8 dis'8 f'8 gis'8 ais'8 
      | b'8 c''16 b'16 gis'8 e'8 cis'8 e'8 gis'8 b'8 
      | ais'8 g'8 gis'8 ais'8~ ais'16 c''16 b'16 c''16 cis''8 d''8~ 
      | d''16 f''16 dis''8~ dis''8. cis''16~ cis''8 b'8 cis''4~ 
      | cis''16 ais'8 f'16~ f'16 gis'16 ais'16 gis'16 \tuplet 3/2 {g'4 f'8~} f'16 dis'8 c'16 
      | \tuplet 3/2 {cis'4 dis'8} \tuplet 3/2 {f'8 gis'8 c''8} b'8 g'8 fis'8 e'8~ 
      | e'16 dis'16 e'16 dis'16 c'8. dis'16 \tuplet 3/2 {gis'4 dis'8~} dis'8 r8 
      | r1 
      \bar "||" \mark \default r4 g'4 g'4.. f'16~ 
      | f'8 dis'8 dis'4 \tuplet 6/4 {cis'8 dis'8. c''16~} \tuplet 6/4 {c''4 cis''16 ais'16~} 
      | ais'8 b'8 \tuplet 3/2 {g'4 fis'8~} fis'8 e'8 \tuplet 3/2 {dis'4 cis'8} 
      | c'4 r2. 
      | r4 gis''8 f''8 dis''8 cis''8 c''8 ais'8 
      | gis'8 ais'8~ \tuplet 6/4 {ais'16 c''8. d''16 c''16} b'8 gis'8~ gis'16 g'8 f'16 
      | \tuplet 3/2 {e'4 g'8} a'8 b'8 d''8 b'8~ \tuplet 5/4 {b'16 c''16 cis''16 c''16 b'16~} 
      | b'16 c''8 b'16~ b'16 a'8 gis'16 \tuplet 3/2 {g'4 f'8} e'8 r8 
      \bar "||" r8 dis'16 g'16~ g'16 dis'8 b16 c'8 d'8 \tuplet 3/2 {dis'8 f'8 g'8} 
      | ais'8 r8 r4 gis'8 r8 r8. g'16 
      | r2 fis''8 d''8 cis''8 b'8 
      | ais'8 gis'8 g'8 f'8 fis'4 e'8 d'8 
      | dis'8 e'8 \tuplet 3/2 {dis'4 f'8} gis'8 ais'8 c''8 dis''8 
      | d''4~ d''16 c''16 cis''16 c''16 b'8 a'8~ \tuplet 6/4 {a'8 gis'16 fis'16 e'16 dis'16~} 
      | \tuplet 6/4 {dis'8 d'8. d'16~} d'4 r2 
      | r1 
      \bar "||" r8. cis'16~ cis'16 d'16 g'16 b'16~ b'8 d''8 b'4 
      | cis'8 g'8 b'8 d''8 b'8 r8 r4 
      | r2 \tuplet 6/4 {r16 c''8. cis''16 c''16} b'4 
      | d''8 fis'8~ fis'8. b'16~ b'16 c''8 d''16~ d''16 c''8 e'16 
      | b'4 c''8 r8 r2 
      | a'8 gis'8 fis'8 e'8~ e'16 dis'8 fis'16~ fis'16 b'8 a'16~ 
      | a'16 gis'8 b16~ \tuplet 6/4 {b16 c'4 cis'16~} cis'4 r4 
      | r1 
      \bar "||" r4 \tuplet 3/2 {e''8 f''4} \tuplet 3/2 {f''4 c''8~} c''8 ais'8~ 
      | ais'8 dis''8~ dis''16 dis''8 dis''16~ dis''8 cis''8 \tuplet 3/2 {gis'4 f'8} 
      | e'8. ais'16 c''4~ c''16 ais'8 g'16~ g'8 fis'16 e'16~ 
      | e'8 dis'8 dis'8 dis'8 r4 r8. gis'16 
      | ais'4 gis'8 f'8~ f'16 dis'8 c'16~ c'16 cis'8 dis'16~ 
      | dis'16 e'8 fis'16~ fis'16 gis'8 b'16~ b'16 ais'8 gis'16~ \tuplet 3/2 {gis'8 fis'8 e'8} 
      | dis'8 f'8 dis'16 c'8 dis'16~ dis'16 g'8 gis'16~ gis'16 ais'8 c''16 
      | cis''4 b'8 r8 r4 \tuplet 3/2 {r8 c''8 a'8} 
      | ais'8 f'8 r4 a'8 c''8 ais'8 a'8 
      | gis'8 ais'16 gis'16 g'8 f'8 fis'8 e'8 dis'8 cis'8 
      | \tuplet 3/2 {c'4 dis'8} g'8 gis'4 r8 r4 
      | r8 c''8 \tuplet 3/2 {a'8 f'8 cis'8~} \tuplet 6/4 {cis'16 c'4 ais16~} ais4~ 
      \bar "||" \mark \default ais8 g8~ g2 r4\bar  ".."
    }
    >>
>>
}
