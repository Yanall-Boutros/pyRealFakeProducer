\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Body and Soul"
  composer = "Coleman Hawkins"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble_8"
    \key des \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              | s2 r2 
      | es2:min d2:775+ | es2:min7 d2:7 | des2:maj es2:min7 | f2:min7 e2:dim | es1:min7 | c2:min5-7 b2:7 | bes2:min7 es4:min7 aes4:7 | des2:maj f4:min5-7 bes4:9- 
      | es2:min d2:775+ | es2:min7 d2:7 | des2:min7 es2:min7 | f2:min7 e2:dim | es1:min7 | c2:min5-7 b2:7 | bes2:min7 es4:min7 aes4:7 | des2 e4:min7 a4:7 
      | d2:maj e2:min7 | b4:min7 fis4 g4:min7 c4:7 | fis4:min7 b4:min7 e4:min7 a4:7 | d2:maj fis4:min7 e4:min7 | d2:min7 g2:7 | c2:maj es2:dim | d2:min7 g2:7 | c4:7 b4:7 bes4:7sus4 bes4:7 
      | es2:min b2:775+ | es2:min7 aes2:7 | des2:maj ges2:7 | f2:min7 e2:dim | es1:min7 | aes2:7 a2:dim | s2 es4:min7 aes4:775+ | s2 f4:min5-7 bes4:7 
      | es2:min d2:775+ | fes2:min7 d2:7 | des2:maj es2:min7 | f2:min7 e2:dim | es1:min7 | c2:min5-7 b2:7 | bes2:min7 es4:min7 aes4:7 | des2:maj f4:min5-7 bes4:9- 
      | es2:min d2:775+ | es2:min7 d2:7 | des2:maj es2:min7 | f2:min7 e2:dim | es1:min7 | c2:min5-7 b2:7 | bes2:min7 es4:min7 aes4:7 | des2 e4:min7 a4:7 
      | d2:maj e2:min7 | b4:min7 fis4 g4:min7 c4:7 | fis4:min7 b4:min7 e4:min7 a4:7 | d2:maj fis4:min7 e4:min7 | d2:min7 g2:7 | c2:maj es2:dim | d2:min7 g2:7 | c4:7 b4:7 bes4:7sus4 bes4:7 
      | es2:min d2:775+ | es2:min7 aes2:7 | des2:maj ges2:7 | f2:min7 e2:dim | es1:min7 | aes2:7 a2:dim | bes1:7|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 95
      \set Score.currentBarNumber = #0
     
      \bar "||" \mark \default r2 r8. dis16~ \tuplet 3/2 {dis8 dis8 dis8} 
      \bar "||" \mark \default r4 r16 dis16 f16 fis16 \tuplet 6/4 {f16 fis16 f4~} f8. dis16~ 
      | dis16 ais8\bendAfter #+4  ais16~ ais8 ais8~ ais4~ ais16 d16 a16 d16 
      | gis8 cis8 r4 \tuplet 3/2 {ais8 gis8 f8~} \tuplet 3/2 {f8 gis8 ais8} 
      | \tuplet 3/2 {c'8 dis'4~} dis'8. cis'16 c'4~ \tuplet 6/4 {c'16 cis'16 d'16 dis'8.} 
      | ais4 r4 \tuplet 9/8 {r32 ais16 ais32 c'16 cis'16 cis'32~} \tuplet 5/4 {cis'16 ais16 cis'16 ais16 fis16} 
      | dis8 f4. \tuplet 6/4 {c8 dis16 f16 a16 c'16} dis8 r8 
      | r4 r32 cis16 dis16 f16 gis32 fis4 cis16 e16 f16 gis16 
      | cis4 \tuplet 3/2 {dis8 f8 gis8} b16 d8. \tuplet 10/8 {dis16. f16 gis16 b16 dis32~} 
      \bar "||" dis4 r4 r8 f16 fis16 ais16 c'16 f'16 dis'16 
      | c'16 ais16 fis16 c16 ais,4 ais8 c8~ \tuplet 3/2 {c8 a8 c8~} 
      | c16 gis16 cis8 f8 r8 r4 r16 gis16 ais16 c'16 
      | \tuplet 6/4 {dis'8 c'16 dis'8 c'16} dis'8 cis'16 gis16 ais16 c'8. d'16 dis'8 ais16~ 
      | ais8 r8 r4 \tuplet 6/4 {ais16 ais16 c'16 cis'8 dis'16} f'16 dis'16 cis'16 c'16 
      | ais8 a8~ \tuplet 6/4 {a8 dis8 fis16 a16~} \tuplet 6/4 {a16 c'16 dis'8 fis'16 f'16} \tuplet 3/2 {dis'8 c'8 a8} 
      | ais4~ \tuplet 5/4 {ais8 cis'8 cis'16~} cis'16 f'16 cis'16 d'16 gis16 fis16 cis16 d16 
      | f16 fis16 gis16 f4. gis16 a8~ \tuplet 10/8 {a16 e'16. cis'16 a16 fis32~} 
      \bar "||" \tuplet 7/8 {fis32 e16 cis16 d32 fis32~} fis32 a16 d'16 b16 fis32 a2 
      | a'16 fis'16 e'16 d'16 e'16 cis'32 d'16 e'16 d'32~ \tuplet 9/8 {d'32 ais8.. e'32~} \tuplet 6/4 {e'16 d'16 ais8 g16 a16~} 
      | a8. fis16 \tuplet 3/2 {d8 a8 g8~} g8 e16 g16 \tuplet 3/2 {a8 e'4} 
      | d'4. a8~ a16 dis16 d16 g16 a16 dis'16 d'8~ 
      | \tuplet 6/4 {d'16 g16 f8 dis16 d16~} d16 a16 d16 f16~ f4~ \tuplet 6/4 {f16 g16 a16 b8 d'16~} 
      | d'16 e'16 d'16 e'16 d'8. b16 d'16 c'16 g16 f16 d16 dis16 b16 a16~ 
      | a4 c'4~ c'16 ais16 a16 ais16 b8 f16 d16 
      | g8 e8~ \tuplet 5/4 {e16 g16 a16 e'16 dis'16} c'16 a16 fis16 dis16~ dis32 d16 f16 gis16 b32~ 
      \bar "||" \tuplet 5/4 {b16 ais16 fis16 d16 dis16} \tuplet 3/2 {f8 dis4~} dis4 ais16 d'16 f'16 d'16 
      | \tuplet 6/4 {dis'4 c'16 cis'16~} \tuplet 5/4 {cis'16 ais16 fis16 dis16 cis16} c8 c'8 f16 ais8 d16 
      | c16 a8 d16 c16 dis16 gis8 r4 \tuplet 7/8 {r32 ais16 a16 gis32 e32} 
      | f4 gis16 c'16 dis'16 c'16 \tuplet 6/4 {cis'8 ais16 c'8 g16~} g4 
      | \tuplet 3/2 {c'8 g8 cis'8} fis8 r8 r4 f16 fis16 ais16 cis'16 
      | \tuplet 3/2 {f'8 f'8 f'8~} f'8~ f'32 dis'32 f'32 dis'32 fis'8 dis'16 c'16~ \tuplet 6/4 {c'16 a16 fis8 dis16 e16} 
      | f4. ais16 cis'16 f'16 cis'16 d'16 a16 fis16 cis16 d16 fis16 
      | gis16 f8.~ f8 gis16 b16 d'16 f'16 d'16 b16 gis16 f16 d16 f16 
      \bar "||" \mark \default dis'16 fis'16 dis'16 cis'16 ais16 fis16 dis16 c16 f8 dis8 r4 
      | r8 ais'32 a'32 gis'32 g'32 fis'8. dis'16 \tuplet 11/8 {c'8.. gis'32 g'32 fis'32 f'32} \tuplet 3/2 {d'4 ais8} 
      | d'8 gis'8\bendAfter #-4  cis'16 f'8 f16 gis8 r8 r4 
      | r8 ais'16 a'16 \tuplet 10/8 {gis'16. f'16 dis'16 ais16 cis'32} c'4 \tuplet 3/2 {e8 g8 c'8} 
      | \tuplet 3/2 {c'8 ais4~} ais4 \tuplet 5/4 {ais8 c'16 cis'16 f'16~} f'16 f'8 f'16 
      | \tuplet 3/2 {f8 a8 dis8} f16 fis8. a16 c'16 dis'16 fis'16 f'4~ 
      | \tuplet 6/4 {f'8. dis'16 e'16 dis'16} cis'16 ais16 dis'16 f'16~ \tuplet 5/4 {f'16 f16 gis16 d'16 ais16} d'16 e'8 f16 
      | \tuplet 6/4 {gis16 cis'8 ais16 cis'16 dis'16~} \tuplet 9/8 {dis'16. f32 gis32 c'16. ais32} c'8 cis'8~ \tuplet 6/4 {cis'16 b8. b16 ais16} 
      \bar "||" r4 r8.. ais32~ ais32 dis'16 f'16 dis'16 cis'32 ais16 fis16 dis16 c16 
      | f8. dis16 f8 dis8 \tuplet 3/2 {fis8 dis8 fis8} dis16 fis16 e8~ 
      | \tuplet 6/4 {e16 gis16 fis8 gis16 fis16} f4. ais16 a16 gis4 
      | r4 c''8 ais'8 gis'16 g'16 e'16 cis'16 c'8. ais16 
      | c'16 cis'16 dis'16 c'16 ais4 r4 ais16 c'16 cis'16 f'16~ 
      | f'16 f16 a16 c'16 \tuplet 3/2 {f'8 dis'4~} \tuplet 7/8 {dis'8 e'16 f'32} dis'16 cis'16 c'16 a16 
      | fis16 dis16 f16 ais16~ ais4 a16 fis16 dis16 d16 \tuplet 3/2 {fis8 a4} 
      | gis4~ \tuplet 6/4 {gis4 a16 ais16} \tuplet 9/8 {b8. d16 e32} \tuplet 3/2 {f8 e4~} 
      \bar "||" \tuplet 6/4 {e16 a16 e8 fis16 a16~} a16 e'16 d'8 r4 \tuplet 6/4 {r16 a'8 fis'16 a'16 fis'16} 
      | \tuplet 6/4 {a'4 fis'16 e'16~} \tuplet 7/8 {e'32 c'32~ c'8 ais32~} ais16 b16 a'16 g'16 ais4~ 
      | ais8 ais4 fis'8~ fis'16 d'16 a16 fis16 g8 e'16 d'16~ 
      | d'8. ais16 \tuplet 3/2 {g8 fis4~} \tuplet 6/4 {fis16 dis16 d16 fis8 a16~} \tuplet 6/4 {a16 dis'16 d'16 a8 fis16} 
      | dis16 d16 fis8 f4. a16 e16 g8 e16 g16 
      | d'16 c'16 c'16 b16 g16 fis16 d16 dis16 \tuplet 3/2 {b8 a8 c'8~} c'4~ 
      | \tuplet 6/4 {c'8. c'16 b16 ais16} \tuplet 6/4 {a8 b8 d16 a16~} a16 d8 g16~ g8 a16 e16 
      | dis8 fis'16 a16 \tuplet 6/4 {e'4 gis'16 fis'16} dis'16 c'16 a16 fis16~ \tuplet 6/4 {fis16 f8. gis16 d16~} 
      \bar "||" \tuplet 6/4 {d16 f16 gis8 b16 f'16} dis'4. ais16 ais16 dis'8 ais'16 ais'16 
      | \tuplet 6/4 {dis''8. ais8 ais16~} \tuplet 6/4 {ais16 e'4 b'16} e''8 ais'8 e'8 ais8~ 
      | ais8 ais16 ais16 \tuplet 3/2 {f'4 ais'8} f''8 ais'16 f'16 \tuplet 3/2 {c'8 ais4~} 
      | ais4 c''8 ais'8 g'4 e'16 cis'16 c'16 ais16 
      | \tuplet 6/4 {gis8 g8. fis16~} fis16 dis16 f16 ais16 f'8. dis'16~ dis'8 r8 
      | r8 dis'16 f'16 fis'16 a'16 fis'16 dis'16 c'16 a16 fis16 dis16 f8 c'16 cis'16 
      \bar "||" ais4. f'8~ \tuplet 10/8 {f'16. dis'8 d'16 a32~} a16 fis16 dis16 d16 
      | fis4~ fis16 e16 g16 b16 \tuplet 3/2 {e8 g4~} \tuplet 6/4 {g16 dis16 fis16 ais8 dis16} 
      | fis4 d16 fis16 a16 d16 \tuplet 6/4 {fis4~ fis16 cis16~} cis8 f8~ 
      | f1\bar  ".."
    }
    >>
>>
}
