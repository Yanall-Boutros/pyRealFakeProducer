\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Did You Call Her Today"
  composer = "Harry Edison"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble"
    \key aes \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              | r1 | s1 
      | bes1:7 | es1:7 | aes1:6 | s1 | es1:min7 | aes1:7 | des1:6 | s1 
      | des1:7 | d1:dim | aes1 | f1:7 | bes1:7 | s1 | bes1:min7 | es1:7 
      | bes1:7 | es1:7 | aes1:6 | s1 | es1:min7 | aes1:7 | des1:6 | s1 
      | des1:7 | d1:dim | aes1 | f1:7 | bes1:min7 | es1:7 | aes1 | s1 
      | bes1:7 | es1:7 | aes1:6 | s1 | es1:min7 | aes1:7 | des1:6 | s1 
      | des1:7 | d1:dim | aes1 | f1:7 | bes1:7 | s1 | bes1:min7 | es1:7 
      | bes1:7 | es1:7 | aes1:6 | s1 | es1:min7 | aes1:7 | des1:6 | s1 
      | des1:7 | d1:dim | aes1 | f1:7 | bes1:min7 | es1:7 | aes1 | s1 
      | r4 s2.|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 118
      \set Score.currentBarNumber = #-1
     
      | r4 r8. gis''16~ gis''8. fis''16~ fis''8 dis''8~ 
      | dis''8 cis''4 gis'8~ \tuplet 6/4 {gis'8 c''16 cis''16 c''16 b'16} gis'4 
      \bar "||" \mark \default ais'16\glissando  c''8 ais'32\glissando  c''32 r2. 
      | r4 f'4 \tuplet 3/2 {f''4 dis''8} \tuplet 3/2 {ais'8 b'8 gis'8~^\markup{\left-align \small vib}} 
      | gis'4 f'8\bendAfter #-4  e'8 r2 
      | r2 ais''4 \tuplet 3/2 {a''4 gis''8~} 
      | \tuplet 3/2 {gis''8 f''8 e''8} dis''8 b'16 c''16 gis'8 g'8 \tuplet 3/2 {fis'8 ais'8 cis''8} 
      | f''8 gis''8 \tuplet 3/2 {dis''8\glissando  e''8 dis''8~} dis''16 ais'8 f'16 gis'8 ais'8 
      | \tuplet 3/2 {e'8 f'8 gis'8~^\markup{\left-align \small vib}} gis'4 r2 
      | r2 \tuplet 6/4 {r4 dis'16 e'16} \tuplet 3/2 {f'8 gis'8 ais'8} 
      \bar "||" \tuplet 3/2 {b'4 f'8} \tuplet 3/2 {ais'8\glissando  b'4} gis'8 ais'8 gis'8 f'8~ 
      | f'8 ais'8 gis'8 ais'8~^\markup{\left-align \small vib} ais'4~ \tuplet 3/2 {ais'8 f'8 gis'8} 
      | \tuplet 3/2 {ais'8 b'4} ais'8 b'8 \tuplet 3/2 {gis'4 ais'8} gis'8 f'8~ 
      | f'8 c''8 \tuplet 3/2 {ais'4 g'8\glissando } \tuplet 3/2 {a'8 f'8 e'8} \tuplet 3/2 {dis'4 c'8} 
      | d'4^\markup{\left-align \small vib} f'8 gis'16 b'16 \tuplet 3/2 {g'4 f'8~^\markup{\left-align \small vib}} f'4 
      | r2 \tuplet 3/2 {r8 e'8 f'8} \tuplet 3/2 {g'8 gis'8 a'8} 
      | ais'8 cis''16 d''16 e''8 f''8 \tuplet 3/2 {g''8 gis''8 b''8} c'''8 r8 
      | r2 \tuplet 3/2 {gis''4 dis''8} gis''4 
      \bar "||" gis''4 gis''4 gis''4 gis''4 
      | gis''4 gis''4 \tuplet 3/2 {gis''4 dis''8} b'8 gis'8 
      | b'8 c''8~ c''16 cis''8 d''16~ \tuplet 3/2 {d''8 cis''8 d''8} \tuplet 3/2 {cis''8 d''8 d''8~} 
      | \tuplet 3/2 {d''8\bendAfter #-4  cis''8 b'8~} b'16 gis'8 f''16~ \tuplet 3/2 {f''8 dis''8 ais'8\glissando } \tuplet 7/8 {b'16 gis'16 g'16 dis'32~} 
      | \tuplet 6/4 {dis'8 ais8 e'16 f'16} dis'2^\markup{\left-align \small vib} r4 
      | r2 dis''16 f''8 gis''16~ gis''16 dis''16 e''16 dis''16 
      | ais'8 gis'4.^\markup{\left-align \small vib} f'8\bendAfter #-4  e'8 r4 
      | r4 r8. ais'16 b'4 ais'8 b'8 
      \bar "||" gis'8 r8 r2 \tuplet 6/4 {r4 r16 ais'16} 
      | b'8 gis'8 \tuplet 3/2 {b'4 cis''8} d''8 cis''8 r4 
      | r4 r16 gis'8 b'16~ \tuplet 3/2 {b'8 cis''8 d''8~} d''8 cis''8~ 
      | cis''8 ais'8~ \tuplet 6/4 {ais'4 gis'16 a'16~} a'16 gis'8 f'16 gis'4 
      | ais'16 b'16 c''8 f'4 gis'4.^\markup{\left-align \small vib} r8 
      | r4 r8. gis''16~^\markup{\left-align \small vib} gis''2~ 
      | gis''2 gis''8. gis''16\bendAfter #-4  r4 
      | r4 r8. b''16~ b''4 b''4 
      \bar "||" \mark \default gis''8 fis''8 dis''8 cis''4 b'8~ \tuplet 6/4 {b'16 gis'8. ais'16\glissando  b'16~} 
      | \tuplet 3/2 {b'8 gis'8 b'8} c''8 cis''8~ cis''16 d''8 dis''16~ dis''16 b'16 c''16 gis'16~ 
      | \tuplet 6/4 {gis'16 dis'8 c'16 cis'16 a16} \tuplet 3/2 {b8 c'8 dis'8~} dis'16 dis'16 e'16 f'16 gis'8 ais'16 c''16 
      | dis''4 e''16 f''8 gis''16~ gis''16 dis''16 f''8 \tuplet 3/2 {dis''4 b'8~} 
      | b'16 ais'8 ais'16~^\markup{\left-align \small vib} ais'2 r4 
      | r2 ais'4 \tuplet 3/2 {f'4 ais'8} 
      | \tuplet 3/2 {gis'4 c'8} \tuplet 3/2 {cis'8 f'8 gis'8~} gis'16 ais'16 c''8 \tuplet 3/2 {gis'4 f'8} 
      | \tuplet 3/2 {ais'4 f'8} gis'4^\markup{\left-align \small vib} r2 
      \bar "||" r8 a'8 \tuplet 3/2 {cis''4 f''8} gis''4 ais'4 
      | cis''4 \tuplet 3/2 {e''8 f''8 cis''8} r2 
      | r8. f'16 gis'8 c''8 f''4 f'4 
      | gis'8. f'16 \tuplet 6/4 {gis'4 b'16 c''16~} \tuplet 3/2 {c''8 a'8 f'8} dis'8. d'16~ 
      | d'4 r4 f'8 gis'8~ gis'16 c''8 f''16 
      | c''4~ c''16 f'8 gis'16~ gis'16\glissando  ais'16 c''8 \tuplet 6/4 {ais'16 c''8. ais'16 c''16~} 
      | c''16 f'8 ais'16~^\markup{\left-align \small vib} ais'4 f'8 e'8 r4 
      | r2. \tuplet 3/2 {gis'4 g'8} 
      \bar "||" cis''8 d''16 dis''16~^\markup{\left-align \small vib} dis''2.~ 
      | dis''2.. gis''8~ 
      | gis''8 dis''8~ dis''4~ \tuplet 6/4 {dis''4 d''16 b'16~} b'16 gis'16 c''16 cis''16 
      | \tuplet 3/2 {dis''8 b'8 c''8} \tuplet 3/2 {gis'8 dis'8 cis'8~} cis'8 b16 c'16 \tuplet 3/2 {dis'4 f'8\glissando } 
      | \tuplet 6/4 {gis'16 ais'8. a'16\glissando  ais'16~} ais'8 ais'8 f'8\bendAfter #-4  r8 r4 
      | ais'4 ais'8. ais'16~ ais'8 e'8~ \tuplet 6/4 {e'16 ais'4 f'16} 
      | gis'4 dis'8 c'16 cis'16 \tuplet 3/2 {ais'4 gis'8~^\markup{\left-align \small vib}} gis'4 
      | r1 
      \bar "||" b''4 b''4 \tuplet 3/2 {gis''4 fis''8} \tuplet 3/2 {dis''4 cis''8} 
      | b'4 \tuplet 3/2 {b'4 ais'8~^\markup{\left-align \small vib}} ais'4. gis'8~ 
      | gis'16 b'16 c''16 dis''16 f''8 dis''8~ dis''16 fis''8 dis''16 c''8 ais'8 
      | a'4^\markup{\left-align \small vib} \tuplet 3/2 {c''8 dis''8 f''8~} f''16 fis''16 gis''16 f''16~ \tuplet 6/4 {f''8 dis''8 f''16 d''16~} 
      | d''8 f'8 \tuplet 6/4 {gis'4 ais'16 c''16~^\markup{\left-align \small vib}} c''2~ 
      | c''8 gis''4. \tuplet 3/2 {gis''4 dis''8} b'8.. ais'32~^\markup{\left-align \small vib} 
      | ais'4 f'4 gis'4^\markup{\left-align \small vib} \tuplet 3/2 {f'4 gis'8~} 
      | gis'8 c''8 \tuplet 3/2 {dis''8 c''8 ais'8~} ais'16 g'16 a'16 c''16 fis'4 
      \bar "||" f'4^\markup{\left-align \small vib} r2.\bar  ".."
    }
    >>
>>
}
