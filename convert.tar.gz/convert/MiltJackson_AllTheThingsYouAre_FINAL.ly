\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "All the Things You Are"
  composer = "Milt Jackson"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble"
    \key aes \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              | g1:7 | f1:min7 | s1 
      | f1:min7 | bes1:min7 | es1:7 | aes1:maj | des1:maj | g1:7 | c1:maj | s1 
      | c1:min7 | f1:min7 | bes1:7 | es1:maj | aes1:maj | a2:min7 d2:7 | g1:maj | s1 
      | a1:min7 | d1:9+ | g1:maj | s1 | fis1:min7 | b1:7 | e1:maj | c1:775+ 
      | f1:min7 | bes1:min7 | es1:7 | aes1:maj | des1:maj | des1:min7 | c1:min7 | b1:dim 
      | bes1:min7 | es1:7 | aes1:maj | g2:7 c2:7 | f1:min7|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 167
      \set Score.currentBarNumber = #-2
     
      \bar "||" \mark \default r2. r8 b''8 
      | c'''4 e'''8 c'''8 b''8 ais''8 gis''8 f''8 
      | ais''8 g''16 gis''16 g''16 f''16 e''8 dis''8 cis''8 c''8 ais'8 
      \bar "||" \mark \default f'8 gis'8 f'8 g'8 f'8 c'8~ \tuplet 3/2 {c'8 f'8 gis'8~} 
      | gis'16 c''8 ais'16~ ais'16 c''8 ais'16~ ais'8. c''16 cis''8 dis''8 
      | \tuplet 3/2 {fis''4 e''8} \tuplet 3/2 {fis''4 e''8~} e''8 d''8 dis''8 cis''8~ 
      | cis''8 c''4 b'16 a'16 gis'8 fis'8 d'8 c'8 
      | cis'8. f'16~ f'16 fis'8 b'16 \tuplet 3/2 {cis''8 b'8 ais'8} gis'8 g'8 
      | f'4 \tuplet 3/2 {d'8 f'8 g'8} gis'8 ais'8 b'8. g'16 
      | c''8 g'8 \tuplet 3/2 {d''4 dis''8} e''8 c''8 f''8 fis''8 
      | g''8 f''4 dis''8 \tuplet 3/2 {e''8 gis''8 b''8} gis''8 a''8 
      \bar "||" ais''8 gis''8 g''8 f''8 dis''8 b'8 g'8. dis'16 
      | c''8 gis'8~ \tuplet 3/2 {gis'8 c''8 dis''8} g''8 f''8 dis''4 
      | d''4. cis'''16 b''16 ais''8 fis''8 e''4 
      | f''8 d''8 dis''8 f''8 fis''8 e''8 dis''8 cis''8 
      | \tuplet 3/2 {d''8 dis''8 g''8} ais''4 gis''8 gis''16 a''16 ais''16 g''16 fis''8 
      | f''8 dis''8 d''8 b'8 c''8 d''8 b'8 g'8 
      | a'8 g'8 a'8 b'8~ \tuplet 6/4 {b'16 g'4 d'16~} d'4~ 
      | d'2 r4 r8 dis''8 
      \bar "||" \tuplet 3/2 {e''8 g''8 b''8} d'''8. c'''16~ c'''8 g''4 e''8 
      | ais''8 b''8 a''8 g''8 \tuplet 3/2 {fis''8 fis''8 a''8} dis''8 cis''8 
      | d''8 c''8 a'8 ais'8 b'8 d''8 e''4 
      | \tuplet 6/4 {g''4 d''16 a''16~} a''8 ais''8 b''8 c'''8 b''8 g''8 
      | a''4~ \tuplet 6/4 {a''4 dis'''16 e'''16~} e'''4 d'''8 c'''8~ 
      | \tuplet 3/2 {c'''8 a''8 b''8} a''8 e''8 g''8 gis''8 e''8 b'8 
      | e''4. r8 r4 dis'''8 e'''8 
      | c'''8 gis''8 e''8 c''8 gis'8 c'8 r4 
      \bar "||" r8 e'8 \tuplet 3/2 {f'8 gis'8 c''8} f''4 c''4~ 
      | c''8 cis''8 \tuplet 3/2 {f''8 gis''8 c'''8} ais''4 gis''8 f''8 
      | \tuplet 3/2 {g''8 ais''8 cis'''8} e'''8. dis'''16~ dis'''4. cis'''8 
      | \tuplet 3/2 {b''8 c'''8 b''8} ais''8 gis''8 b''8 a''8 gis''8 fis''8 
      | f''8 gis''8 dis''8 c''8 cis''8 dis''8 e''8 g''8 
      | gis''8 fis''8~ \tuplet 6/4 {fis''16 e''8. e'16 gis'16} b'8 dis''8 \tuplet 3/2 {cis''4 b'8} 
      | c''8 dis''8 \tuplet 3/2 {f''4 dis''8} g''8 gis''8 dis''8 cis''8 
      | b'8 cis''8 d''16 cis''16 b'16 a'16 cis''8 b'8 gis'8 fis'8 
      | gis'2 \tuplet 3/2 {cis'8 f'8 gis'8} ais'4 
      | ais'8 b'8~ \tuplet 6/4 {b'16 f'4 cis'16~} cis'4. dis'8 
      | g'8 gis'8 g'8 f'8 dis'4. f'16 dis'16 
      | d'8 b8 \tuplet 3/2 {c'4 d'8} dis'8 g'8 \tuplet 3/2 {c''8 d''8 d''8} 
      \bar "||" \mark \default d''4 r2.\bar  ".."
    }
    >>
>>
}
