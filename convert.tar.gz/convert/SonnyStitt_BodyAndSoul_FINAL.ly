\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Body and Soul"
  composer = "Sonny Stitt"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble_8"
    \key des \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              | s2 r2 
      | es2:min7 bes2:9- | aes2:7sus4 aes2:7 | des2:maj ges2:7 | f2:min7 e2:dim7 | es1:min7 | c2:min5-7 b2:7 | bes4:min7 es4:7 es4:min7 aes4:7 | des2:6 bes2:7 
      | es2:min7 bes2:9- | es2:min7 d2:7 | des2:maj ges2:7 | f2:min7 e2:dim7 | es1:min7 | c2:min5-7 b2:7 | bes2:min7 d2:7 | des2:6 e4:min7 a4:7 
      | d2:maj e2:min7 | fis2:min7 g4:min7 c4:7 | fis4:min7 b4:7 e4:min7 a4:7 | d1:maj | d2:min7 g2:7 | c2:maj es2:dim | d2:min7 g2:7 | c4:7 b4:7 bes2:7 
      | es2:min7 bes2:9- | es2:min7 d2:7 | des2:maj ges2:7 | f2:min7 e2:dim7 | es1:min7 | c2:min5-7 b4:11+.9 f4:7 | bes4:min7 r4 s4 s4 | s4 s4 s4 s4 
      | s4 s4 s4 s4 | s4 s4 s4 s4 | des1:6|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 68
      \set Score.currentBarNumber = #0
     
      \bar "||" \mark \default r2. \tuplet 5/4 {r8 ais16 c'16 d'16} 
      \bar "||" \mark \default dis'4.^\markup{\left-align \small vib} \tuplet 6/4 {ais'16 fis'16 dis'16} ais16 d'8.~^\markup{\left-align \small vib} d'8~ d'32 ais'32 fis'32 d'32 
      | ais16 cis'8.~^\markup{\left-align \small vib} \tuplet 9/8 {cis'32 a'32 ais'16 c''32 ais'32 fis'32 dis'32 ais32} cis'16 c'8.^\markup{\left-align \small vib} r4 
      | r4 r16 f'32 fis'32 gis'32 ais'32 gis'32 fis'32 gis'4^\markup{\left-align \small vib} r4 
      | f'32 fis'32 gis'16 c''32 b'32 ais'32 a'32 gis'32 c'32 cis'32 fis'32 f'32 fis'32 gis'32 ais'32 c''32 gis'32 f'32 c'32 dis'32 c'32 d'32 f'32 \tuplet 6/4 {gis'16 ais'16\glissando  b'16 ais'16 e'8~} 
      | \tuplet 6/4 {e'16 ais'16 b'16 ais'16 dis'8~^\markup{\left-align \small vib}} dis'4.. c''32\glissando  cis''32 c''32 cis''32 c''32 ais'32 a'32 ais'32 a'32 g'32 
      | f'4~^\markup{\left-align \small vib} \tuplet 7/8 {f'32 e'32 dis'32 gis32 ais32 cis'32 c'32} \tuplet 3/2 {fis8 f4^\markup{\left-align \small vib}} r4 
      | r4 r8 c''32 d''32 dis''32 cis''32 c''32 ais'32 a'32 g'32 gis'32 g'32 fis'32 ais32~ ais16 f'16 ais16 gis16 
      | c'16\glissando  cis'8.^\markup{\left-align \small vib} r4 r32 ais'32 b'16 g'32\glissando  gis'32 e'32\glissando  f'32 d'16\glissando  dis'16 d'16 ais16 
      \bar "||" dis'4~^\markup{\left-align \small vib} \tuplet 10/8 {dis'8. f'32 fis'32 ais'32 d''32} f''16 dis''8. ais4 
      | dis'16 f'32 fis'32 gis'32 cis''32\glissando  f''32 dis''32 a4~ \tuplet 9/8 {a32 d'16 e'32 f'32 fis'32 a'32 b'32 e''32} d''8. gis16~ 
      | \tuplet 12/8 {gis16 cis'8 dis'32 f'32 gis'32 c''32 dis''32 ais'32} r4 \tuplet 10/8 {r8 c''32 cis''32 c''32 cis''32 c''32 gis'32~} \tuplet 6/4 {gis'16 c''16 b'16 ais'16\glissando  b'16 a'16} 
      | \tuplet 6/4 {gis'16 f'16 fis'16 f'8 gis'16} \tuplet 6/4 {c''16 dis''16 c''16 gis'8 f'16~} \tuplet 6/4 {f'8 cis''16\bendAfter #+4  d''16 c''16 b'16} g'16 e'8.~^\markup{\left-align \small vib} 
      | e'32 cis''16 c''32 b'32 ais'32 fis'32 f'32 \tuplet 6/4 {e'16 dis'16 d'16 dis'8.^\markup{\left-align \small vib}} r4 r16 gis'16 c''16 d''16\glissando  
      | dis''32 d''16 c''16 a'32\glissando  ais'32 g'32 a'8 c''16 f'16~^\markup{\left-align \small vib} f'4 r4 
      | r4 \tuplet 5/4 {e''16 f''16 cis''16 gis'16 f'16} \tuplet 10/8 {fis'4^\markup{\left-align \small vib} a'32 c''32~} \tuplet 6/4 {c''16 e''8 c''16 a'16 fis'16~} 
      | fis'16 dis''16 cis''16 cis''16 c''8 ais'8~^\markup{\left-align \small vib} ais'32 ais'32 c''32 b'32 g'32 e'16 b32 \tuplet 3/2 {d'8 cis'4^\markup{\left-align \small vib}} 
      \bar "||" r4 \tuplet 12/8 {r32 f'16\glissando  fis'8. a'32 cis''32 e''32} b'4^\markup{\left-align \small vib} r4 
      | r16 cis''16 fis'16 g'16 a'16 fis'16 e'16 d'16 c''16 ais'16 c''16 ais'16~^\markup{\left-align \small vib} ais'4 
      | \tuplet 6/4 {c''16 cis''16 a'16 fis'8 e'16~} \tuplet 10/8 {e'32 dis'16. c''32\bendAfter #+4  cis''32 c''32 cis''32 b'32 fis'32~} fis'32 a'32 ais'32 a'32 gis'32 d'32 b32 fis32~ fis16 fis'16 cis'16 a16 
      | e'4.^\markup{\left-align \small vib} \tuplet 6/4 {e'16 d'16 cis'16} a16 b8.^\markup{\left-align \small vib} r4 
      | r8 f32 g32 a32 b32 e'32 d'32 c'32 a32 b32 c'32 d'32 e'32 \tuplet 9/8 {f'16 a32 ais32 b32 e'32 d'32 c'32 a32~} \tuplet 10/8 {a32 b32 d'32 f'32 gis'16 f'32 e'32 gis'32 b'32} 
      | \tuplet 6/4 {d''16 c''16 b'16 g'16 a'8~^\markup{\left-align \small vib}} a'4 \tuplet 7/8 {ais'32 c''32 b'32 g'32 e'32 b32 d'32} \tuplet 6/4 {cis'8 a'16\glissando  ais'8 a'16~} 
      | a'32 g'32 gis'32 g'32 f'32 c''16.~^\markup{\left-align \small vib} \tuplet 7/8 {c''16. a'32 f'32 c'32 a32~} \tuplet 6/4 {a16 e'16 g'16 e'8.~^\markup{\left-align \small vib}} e'4~ 
      | \tuplet 5/4 {e'8 c'16 e'16 g'16~} g'32 gis'16 b'16. a'32 e'32 \tuplet 6/4 {gis'8 gis8 c'16 dis'16~} dis'16 e'16 g'16 f'16 
      \bar "||" \tuplet 3/2 {ais8 dis'4^\markup{\left-align \small vib}} r4 \tuplet 6/4 {r4 dis'16 f'16} dis'4~^\markup{\left-align \small vib} 
      | dis'16 dis'16 fis'16 gis'16 \tuplet 5/4 {a'16\glissando  ais'16 fis'16 dis'16 ais16~} \tuplet 10/8 {ais32 a'16. fis'16 dis'16 g'32 gis'32~} gis'8 fis'16 cis'16~ 
      | \tuplet 6/4 {cis'16 e'16 f'16 gis'16 gis'16 gis'16~^\markup{\left-align \small vib}} gis'4 r4 \tuplet 7/8 {r16 f'16 gis'32 ais'32 c''32} 
      | dis''16. cis''32 c''32 cis''32 c''32 ais'32 \tuplet 6/4 {gis'8 c'8 cis'16 fis'16~} fis'32 f'16 dis'16 d'32 f'32 gis'32 b'16 cis''16 ais'16 gis'16 
      | ais'16 fis'16 ais16 dis'16 fis'16 f'16 dis'4^\markup{\left-align \small vib} r8 r4 
      | \tuplet 6/4 {r8. a8 dis'16~} \tuplet 10/8 {dis'32 g'16. d'32 c'32 dis'32 f'32 g'32 a'32~} a'32 cis''8 a'32 f'32 dis'32 c''4 
      | r4 \tuplet 10/8 {cis''32 c''32 ais'32 fis'16 dis'32 ais32 cis'32 ais32 c'32~} \tuplet 10/8 {c'32 f'8.. cis'32 ais32~} ais32 fis32 e'16 c'32 a32 fis32 dis'32~^\markup{\left-align \small vib} 
      | dis'4 dis'32 f'32 fis'32 ais'32 cis''32 ais'32 gis'32 fis'32 ais'32 d''32 f''32 c''32 dis''32 e''32 ais'32 a'32 \tuplet 6/4 {gis'16 g'16 fis'16 f'16 dis'16 ais16} 
      | \tuplet 7/8 {cis'32 c'32 ais32 a32 g32 gis32 f32} \tuplet 6/4 {fis16 ais16 cis'16 f'4.^\markup{\left-align \small vib}} dis'8~ dis'16 gis'32 ais'32 gis'32 fis'32 cis'32 ais32 
      | fis16 e'8.^\markup{\left-align \small vib} c'16 gis16 fis16 f16~ \tuplet 7/8 {f32 gis32 c'32 dis'32 cis'32 c'32 gis32} ais4~^\markup{\left-align \small vib} 
      | ais2. r4\bar  ".."
    }
    >>
>>
}
