\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Body and Soul"
  composer = "Joe Lovano"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble_8"
    \key des \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              
      | es2:min7 b2:9- | es2:min7 d2:7 | des2:maj ges2:7 | f2:min7 e2:dim7 | es1:min7 | c2:min5-7 f2:7 | bes4:min7 es4:7 es4:min7 aes4:7 | des2:6 bes2:7 
      | es2:min7 bes2:9- | es2:min7 d2:7 | des2:maj ges2:7 | f2:min7 e2:dim7 | es1:min7 | c2:min5-7 f2:7 | bes4:min7 es4:7 es4:min7 aes4:7 | des2 a2:7 
      | d2:maj e2:min7 | d2:/fis g4:min7 c4:7 | fis4:min7 b4:7 e4:min7 a4:7 | d1:maj | d2:min7 g2:7 | c2:maj es2:dim | d2:min7 g2:7 | c4:7 b4:7 bes2:7 
      | es2:min7 bes2:9- | es2:min7 d2:7 | des2:maj ges2:7 | f2:min7 e2:dim7 | es1:min7 | c2:min5-7 f2:7 | bes4:min7 es4:7 es4:min7 aes4:7 | des2:6 bes2:7 
      | es2:7 bes2:9- | es2:min7 d2:7 | des2:maj ges2:7 | f2:min7 e2:dim7 | es1:min7 | c2:min5-7 f2:7 | bes4:min7 es4:7 es4:min7 aes4:7 | des2:6 bes2:7 
      | es2:min7 bes2:9- | es2:min7 d2:7 | des2:maj ges2:7 | f2:min7 e2:dim7 | es1:min7 | c2:min5-7 f2:7 | bes4:min7 es4:7 es4:min7 aes4:7 | des2.:maj a4:7 
      | d2:maj e2:min7 | d2:/fis g4:min7 c4:7 | fis4:min7 b4:min7 e4:min7 a4:7 | d1:maj | d2:min7 g2:7 | c2:maj es2:dim | d2:min7 g2:7 | c4:7 b4:7 bes2:7 
      | es2:min7 bes2:9- | es2:min7 d2:7 | des2:maj ges2:7 | f2:min7 e2:dim7 | es1:min7 | c2:min5-7 f2:7 | bes4:min7 es4:7 es4:min7 aes4:7 | des2:6 bes2:7|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 60
      \set Score.currentBarNumber = #1
     
      \bar "||" \mark \default r4 dis16. dis16 f32 dis32 f32~ f32 dis32 f16. f16 dis32 \tuplet 3/2 {f8 ais,4} 
      | d16 dis16 ais8~ ais8~ ais32 gis32 f32 d32 \tuplet 6/4 {dis16 gis16 e16 fis16 ais16 c'16} d'32 e'32 fis'16. e'32 c'32 ais32~ 
      | ais16 dis'16 c'8~ \tuplet 6/4 {c'8. gis16 f16 gis16~} gis8 r8 \tuplet 10/8 {r8 g32 gis16 ais32 g32 gis32} 
      | \tuplet 6/4 {ais16 c'16 cis'16 dis'16 f'16 c'16~} \tuplet 12/8 {c'8 ais32 dis'16. e'16 g'32 b'32~} \tuplet 6/4 {b'16 fis'16 cis'16 e'8 d'16} b32 fis32 a16 cis'16 a32 fis32 
      | cis16 b16 a16 ais16~ ais16 cis'16 ais16 cis'16~ cis'4~ \tuplet 5/4 {cis'16 ais16 fis16 f16 fis16} 
      | dis8~ dis32 f32 fis32 a32 \tuplet 9/8 {cis'32 dis'32 f'32 e'32 dis'32 f'32 fis'32 g'32 a'32} \tuplet 12/8 {b'8~ b'32 a'32 g'32 fis'8 fis'32~} fis'32 e'32 d'32 cis'32 b32 a32 g32 fis32~ 
      | fis8. ais'16 \tuplet 6/4 {gis'16 fis'16 f'16 f'16 e'16 dis'16} \tuplet 6/4 {dis'16 cis'16 c'8 c'16 ais16} \tuplet 5/4 {gis16 gis16 f16 dis16 gis16} 
      | dis8 f8~ f4~ f32 f16 fis32 gis32 fis32 f32 dis32 d16 fis16 d16 b,16 
      \bar "||" d16 b,16 ais,8~ ais,8. f16 dis16 fis16 ais16 f'16 \tuplet 3/2 {f'8 dis'8 dis'8} 
      | ais8 ais8~ ais16 a16 ais16 ais'16 \tuplet 6/4 {f'16 dis'16 e'8. b'16~} b'8. e'16 
      | \tuplet 3/2 {dis'8 dis'8 cis'8} c''4 r4 \tuplet 6/4 {r16 ais'16 gis'16 f'16 dis'16 gis'16} 
      | f'32 c'16 dis'16 ais32 gis32 c'32 \tuplet 5/4 {gis16 f16 b16 g16 e16} \tuplet 6/4 {a16 e16 fis16\glissando  g16 a16 e'16} \tuplet 5/4 {c'16 e'16 b16 g16 fis'16~} 
      | \tuplet 6/4 {fis'16 cis'16 f'8. dis'16} fis'8 fis'16 gis'16~ \tuplet 6/4 {gis'16 ais'16 b'16 c''16 gis'8~} gis'16 c''16 dis''16 c''16~ 
      | c''4~ \tuplet 10/8 {c''8 g'32 gis'32 a'32 f'32 fis'32 g'32} fis'16 f'16 e'32 dis'32 d'32 c'32 \tuplet 6/4 {g16 ais16 dis'16 c'16 g16 a16~} 
      | a32 f32 ais32.~ ais8 c'64 cis'16 dis'16 f'16 gis'16~ gis'16 fis'16 gis'16 ais'16 e'16\glissando  f'8. 
      | \tuplet 6/4 {gis16 dis'16 cis'4~} cis'8 r8 \tuplet 14/16 {r8 d'32 e'64 e'64 fis'64 g'64} fis'16 a'16\glissando  c''16 cis''16~ 
      \bar "||" \tuplet 5/4 {cis''16 a'16 fis'16 b'16 a'16} \tuplet 6/4 {fis'16 e'16 a'16 fis'16 cis'16 e'16} \tuplet 6/4 {d'16 cis'16 b16 e'16 cis'8~} \tuplet 5/4 {cis'8 ais16 cis'16 ais16} 
      | b16 cis'16 a16 a16~ \tuplet 6/4 {a4~ a16 g16~} \tuplet 10/8 {g32 a32 ais32 ais32 d'32 a32 ais32 d'32 f'32 a'32~} \tuplet 10/8 {a'32 c''32 ais'8 cis'32 d'32 f'32 a'32~} 
      | \tuplet 6/4 {a'16 fis'16 g'16 a'16 fis'8~} fis'4 \tuplet 6/4 {e'8 fis'8 fis'16 g'16~} g'16 b8 e'16~ 
      | \tuplet 3/2 {e'8 cis'8 a8~} a8.. f32~ f16 a16 fis4 r8 
      | r4 \tuplet 5/4 {r16 d16 e16 f16 g16} \tuplet 6/4 {a16 a16 c'16 a16 b16 b16} e'16 f'16 b'8\glissando  
      | \tuplet 6/4 {cis''16 d''16 g'8 g'8} a'32 b'32 d''32 b'32 g'32 a'32 b'32 e'32 \tuplet 9/8 {a'32 b'32 f'32 cis'32 f'32 g'32 f'32 e'32 ais32} f32 a32 cis'32 ais32 f32 e32 ais,32 e32 
      | ais,16 a,8.~ \tuplet 12/8 {a,16. a,32 b,32 cis32 e32 g32 d32 dis16 e32} \tuplet 10/8 {f32 fis32 g32 b32 gis32 a32 c'32 a32 ais32 b32} \tuplet 7/8 {c'32 e'32 gis'32 b'32 a'32 e'32 c'32~} 
      | \tuplet 12/8 {c'32 g'16~ g'4 g32~} g16 g'16 a'16 fis'16~ fis'16 f'16 ais'8~ \tuplet 6/4 {ais'4 fis'16 d'16} 
      \bar "||" \tuplet 6/4 {f'16 d'16 dis'16 f'16 dis'8} r4 \tuplet 6/4 {r8 d'16 dis'16 f'16 dis'16} \tuplet 6/4 {ais16 f16 e16 d16 dis16 f16} 
      | \tuplet 6/4 {cis16 d16 f16 dis8 ais,16~} ais,8. ais16 \tuplet 6/4 {gis16 fis16 f16 e8.} \tuplet 6/4 {e16 fis16 c'8. ais16} 
      | f8 gis8~ gis4~ \tuplet 5/4 {gis8 g16 gis16 ais16} gis16 g16 gis16 gis16~ 
      | \tuplet 6/4 {gis16 f'8 dis'8 dis'16} cis'8 r8 \tuplet 3/2 {r8 c'8 b8~} b8 cis'8 
      | ais4~ \tuplet 12/8 {ais4 cis''16 c''32 ais'32~} \tuplet 6/4 {ais'16 c''16\glissando  cis''16 c''16 ais'16 fis'16~} \tuplet 6/4 {fis'8 fis'16 g'16\bendAfter #+4  gis'16 f'16~} 
      | f'8 f'32 e'32 f'32 fis'32 \tuplet 6/4 {gis'16 ais'16 cis''16 dis''16 c''8~} c''16 ais'32 a'16 cis'32 dis'32 g'32~ \tuplet 14/16 {g'32 fis'16. e'64 f'32 cis'32 a64~} 
      | \tuplet 10/8 {a32 f16 c'16 a16 ais16 c'32~} \tuplet 9/8 {c'32 cis'16 dis'32 f'32 fis'32 gis'32 ais'32 c''32} dis''16 cis''8.~ \tuplet 5/4 {cis''8 c''16 ais'16 gis'16~} 
      | \tuplet 10/8 {gis'32 f'16. dis'16 cis'16. f'32~} \tuplet 10/8 {f'4 fis'32 gis'32~} \tuplet 6/4 {gis'16 f'16 gis'16 d'16 gis'16 d'16~} \tuplet 5/4 {d'8 f'16 gis'16 d'16~} 
      \bar "||" \mark \default \tuplet 5/4 {d'16 f'16 d'16 f'16 dis'16} f'16 dis'16 cis'16 f'16 \tuplet 10/8 {dis'32 gis32 ais32 gis32 f'32 dis'8 ais32~} ais8 r8 
      | \tuplet 10/8 {r8 r32 a'32 ais'32 a'32 dis'32 f'32~} f'32 gis'8 g'32 fis'32 g'32 \tuplet 7/8 {b'32 dis''32 e''32 cis''32 b'32 g'32 dis'32} \tuplet 6/4 {c'16 g'16 b'16 fis'8.} 
      | f'32 e'32 c'32 e'32 f'16. c'32 ais16 gis16 dis'8 c'16 gis16 f16 dis16~ \tuplet 13/16 {dis64 f16. c32 ais,32. gis,64~} 
      | gis,4~ \tuplet 10/8 {gis,8 d32 dis32 e32 g32 b32 gis32} \tuplet 10/8 {a32 e'32 ais32 b32 c'32 e'32 g'32 b'32 fis'16~} fis'8~ fis'32 f32 fis32 c'32 
      | \tuplet 9/8 {gis16 c'32 cis'32 dis'32 fis'32 gis'32 c''32 f'32~} f'16 f'16 fis'16 gis'16~ gis'8. ais'16 \tuplet 5/4 {c''16 cis''16 d''16 dis''16 cis''16} 
      | b'16\bendAfter #+4  c''16 b'16\bendAfter #+4  c''16~ c''16 ais'16 f'16 b'16~ \tuplet 12/8 {b'32 a'32 b'32 e'16. a'32 g'32 dis'32 c'32 dis'32 e'32} \tuplet 6/4 {g'16 dis'16 fis'8 e'16 f'16~} 
      | \tuplet 6/4 {f'8 c'16 dis'16 cis'16 dis'16} \tuplet 3/2 {f'8 gis'8 fis'8~} fis'8. gis16\glissando  e'16 f'16 e'8 
      | \tuplet 6/4 {dis'4 cis'16 dis'16} e'16 dis'16 cis'16 dis'16~ \tuplet 10/8 {dis'8~ dis'32 cis'16 dis'32 f'32 fis'32~} fis'32 gis'32 cis'32 d'32 f'32 f'32 d'32 ais32 
      \bar "||" fis32 dis32 d'32 dis'32 f'32 e'32 dis'16~ dis'32 ais32 cis'16 ais32 cis'32 ais32 fis32 \tuplet 6/4 {e16 f16 dis4~} \tuplet 7/8 {dis32 d32 dis32 f32 fis32 ais32 cis'32} 
      | \tuplet 14/16 {dis'32 f'64 fis'32 gis'32 ais'64 cis''32 gis'32 ais'64 a'64~} \tuplet 14/16 {a'64 f'64 gis'32 dis'64 f'32 fis'64 gis'32 a'32 b'64 dis''64~} \tuplet 12/8 {dis''32 e''16 d''32~ d''8 b'32 a'32 g'32 fis'32~} \tuplet 10/8 {fis'16 b'32 a'32 g'32 e'32 dis'32 cis'16 b32} 
      | c'8 dis'8~ dis'16 c'16 dis'16 gis'16~ gis'8. gis'16~ \tuplet 6/4 {gis'16 b'16\bendAfter #+4  c''16 d''16 dis''16 dis''16~} 
      | \tuplet 3/2 {dis''8 c''8 f'8} \tuplet 6/4 {c''16 gis'8 gis'16 f'16 b'16} \tuplet 6/4 {a'4 b'16 cis''16} d''16 fis'16 e'8~ 
      | e'8. dis'16 \tuplet 3/2 {f'8 fis'8 gis'8} \tuplet 3/2 {ais'8 cis''8 ais'8} \tuplet 10/8 {cis''16. ais'16. fis'16. gis'32~} 
      | \tuplet 12/8 {gis'8 f'16. gis'8 f'32~} \tuplet 6/4 {f'16 e'16 f'16\bendAfter #+4  e'16 f'8} dis'4~ \tuplet 12/8 {dis'16 cis'16 dis'32 f'32 b'32 a'16. f'32 cis'32} 
      | \tuplet 6/4 {dis'16 cis'16 g'16 f'16 fis'8} \tuplet 7/8 {f'16. c'32 dis'32 d'32 cis'32} a16 c'16 ais16 dis'16~ dis'16 c'16 ais16 gis16~ 
      | \tuplet 6/4 {gis8. gis16 f16 c16} \tuplet 3/2 {ais,8 gis,4~} gis,16. b'32 g'32 b'32 g'32 fis'32 \tuplet 5/4 {e'16 a'16 fis'16 cis'16 e'16~} 
      \bar "||" e'16 d'32 cis'32 b32 e'16. \tuplet 3/2 {cis'8 a4~} \tuplet 10/8 {a8 a32 ais32 a32 c'32 cis'16} d'32 dis'32 e'16 d'32 e'32 f'32 fis'32 
      | \tuplet 3/2 {a'8 cis''4~} cis''8~ cis''32 a,32 ais,32 d32 \tuplet 14/16 {f32 a64 ais32 g32 f32 e64 g32 ais64 d'64~} \tuplet 10/8 {d'32 gis32 a32 ais32 d'32 e'32 f'16 fis'32 g'32} 
      | \tuplet 12/8 {g'32 a'32 ais'32 b'32 cis''16 a'32 b'16 cis'32 e'32 b'32} a'16 g'32 fis'32 g'16 a'32 fis'32 \tuplet 6/4 {f'16 e'16 d'16 dis'8.~} dis'16 d'16 gis8 
      | b16 a8 f16 g16 fis4. cis16 \tuplet 6/4 {e16 d8 e8 f16~} 
      | \tuplet 5/4 {f16 g16 a16 c'16 a16} \tuplet 5/4 {b8 e'16 f'16 a'16} \tuplet 3/2 {b'8 d''8 e''8~} e''4~ 
      | \tuplet 5/4 {e''16 b'16\glissando  cis''16 d''16 b'16\glissando } cis''16 d''16 b'16 ais'16~ ais'4~ \tuplet 5/4 {ais'8 a'16 ais'16 cis''16} 
      | d''16 a'8. \tuplet 10/8 {f'16 e'32 g'16 d'32 f'16 d'32 e'32~} \tuplet 6/4 {e'16 gis16 e'8. d'16} \tuplet 11/8 {b16. d'16. b16 b32 ais32 b32~} 
      | b16 e16 a16 g16 fis4~ fis16. f32 fis32 ais32 e'32 ais32 b32 d'32 dis'16 gis'32 d''32 ais'32 b'32 
      \bar "||" \tuplet 10/8 {d'32 dis'32 b'32 ais'16 a'32 gis'32 g'32 f'32 fis'32} gis'16 ais'16 f'16 fis'16 dis'4~ \tuplet 6/4 {dis'8 d'16\bendAfter #+4  dis'16 dis'16 f'16} 
      | ais'8 ais'8 \tuplet 5/4 {gis'16 b'16 e'16 fis'16 c'16~} \tuplet 7/8 {c'16. e'32 c'32 gis32 e'32} c'32 gis32 e16 c32 fis16 e32 
      | c16 a,16 gis,8~ gis,4. gis16 ais16 gis16 g16 gis16 gis16 
      | \tuplet 3/2 {gis8 dis'8 dis'8~} dis'16 dis'8 dis'16 c'16 cis'16 c'8 ais8. a16 
      | ais16 cis'16 ais8~ ais4~ ais16 cis''16 c''16 ais'16 cis''16 c''16 ais'16 fis'16 
      | \tuplet 6/4 {g'16 gis'8. e'16\bendAfter #+4  f'16~} \tuplet 10/8 {f'32 dis'8. fis'32 g'32 a'32} \tuplet 10/8 {c''32 a'16. f'32\bendAfter #+4  fis'32 cis'16 dis'32 g'32~} g'32 fis'32 f'32 e'32 dis'32 ais32 f32 gis32 
      | a32 c'16 a16 ais32 c'32 cis'32 dis'32 f'32 fis'32 gis'32 ais'32 c''32 dis''16~ \tuplet 6/4 {dis''16 cis''8. cis''16 dis''16~} dis''16 c''16 gis'16 cis''16~ 
      | cis''4~ cis''16 c''16 gis'16 f'16 b'16 gis'16 f'16 dis'16 d'4 
      \bar "||" b16 ais8.~ ais8 r8 r2\bar  ".."
    }
    >>
>>
}
