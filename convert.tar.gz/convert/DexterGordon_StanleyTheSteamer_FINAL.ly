\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Stanley the Steamer"
  composer = "Dexter Gordon"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble_8"
    \key bes \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              | r1 
      | bes1:7 | es1:7 | bes1:7 | s1 | es1:7 | s1 | bes1:7 | d2:min7 g2:7 
      | c1:min7 | f1:7 | bes1:7 | f1:7 | bes1:7 | es1:7 | bes1:7 | s1 
      | es1:7 | s1 | bes1:7 | d2:min7 g2:7 | c1:min7 | g1:7 | bes2:7 g2:7 | c2:min7 f2:7 
      | bes1:7 | es1:7 | bes1:7 | s1 | es1:7 | s1 | bes1:7 | d2:min7 g2:7 
      | c1:min7 | f1:7 | bes1:7 | c2:min7 f2:7 | bes1:7 | es1:7 | bes1:7 | s1 
      | es1:7 | s1 | bes1:7 | d2:min7 g2:7 | c1:min7 | f2:7 s2 | bes2:7 g2:7 | c2:min f2:7 
      | bes1:7 | es1:7 | bes1:7 | s1 | es1:7 | s1 | bes1:7 | d2:min7 g2:7 
      | c1:min7 | f2:7 s2 | bes1:7 | c2:min7 f2:7 | bes1:7 | es1:7 | bes1:7 | s1 
      | es1:7 | s1 | bes1:7 | d2:min7 g2:7 | c1:min7 | f1:7 | bes1:7 | f1:7 
      | bes1:7 | es1:7 | bes1:7 | s2 s2 | es1:7 | s1 | bes1:7 | d2:min7 g2:7 
      | c1:min7 | f2:7 s2 | bes1:7 | c2:min7 f2:7 | bes1:7 | es2:7 e2:dim | bes1:7 | s1 
      | es1:7 | s1 | bes1:7 | d2:min7 g2:7 | c1:min7 | f1:7 | bes1:7 | f1:7 
      | bes1 | es1:7 | bes1:7 | s1 | es1:7 | s1 | bes1:7 | d2:min7 g2:7 
      | c1:min7 | f2:7 s2 | bes2:7 g2:7 | c2:min7 f2:7 | bes1:7 | es1:7 | bes1:7 | s2 s2 
      | es1:7 | s1 | bes1:7 | d2:min7 g2:7 | c1:min7 | f1:7 | bes1:7 | c2:min7 f2:7 
      | bes1:7 | es1:7 | bes1:7 | s1 | es1:7 | s1 | bes1:7 | d2:min7 g2:7 
      | c1:min7 | f2:7 s2 | bes2:7 g2:7 | c2:min f2:7 | bes1:7 | es1:7 | bes1:7 | s1 
      | es1:7 | s1 | bes1:7 | d2:min7 g2:7 | c1:min7 | f2:7 s2 | bes1:7 | c2:min7 f2:7 
      | bes1:7|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 181
      \set Score.currentBarNumber = #0
     
      \bar "||" \mark \default r2 c'8 g4. 
      \bar "||" \mark \default ais4~ ais16 ais8 c'16~ \tuplet 6/4 {c'16 d'8 d'8 c'16} ais4~ 
      | ais16 dis'8 f'16 g'4 f'8. ais'16~ ais'8 a'8 
      | ais'4 f'8. e'16~ e'8 f'8~ f'16 g'8 gis'16 
      | f'8 d'8~ \tuplet 6/4 {d'4 ais16 b16~} b16 g'8 f'16~ f'8 d'8 
      | dis'8. ais16 r2 r8 c'8 
      | cis'8 c'16 cis'16~ cis'16 f'8 e'16~ e'8 gis'8 \tuplet 3/2 {gis'8 ais'8\glissando  c''8} 
      | ais'4.^\markup{\left-align \small vib} r8 r2 
      | r4 a'8 g'8~ g'16 ais'8 g'16~ g'16 dis'8 ais16~ 
      | ais8 d'8~ \tuplet 6/4 {d'4~ d'16 f'16~} f'8 r8 r8 d'8 
      | dis'8 f'8 g'8 a'8 d''4~ d''16 f'8 ais'16 
      | r2 r16 gis'8 gis'16~ gis'16 g'8 g'16 
      | f'4.^\markup{\left-align \small vib} dis'8 \tuplet 3/2 {cis'8\glissando  d'4} f'8 ais8~^\markup{\left-align \small vib} 
      \bar "||" \mark \default ais4 c'8 ais8 cis'8\glissando  d'8 \tuplet 3/2 {f'4 dis'8~^\markup{\left-align \small vib}} 
      | dis'4 f'8 dis'8 \tuplet 3/2 {fis'8\glissando  g'8 ais8~} ais8 r8 
      | r8. a16 \tuplet 3/2 {c'4 ais8} cis'8\glissando  d'16 f'16~ f'16 g'8 gis'16~^\markup{\left-align \small vib} 
      | gis'4 g'8 fis'8 fis'8 ais8 r4 
      | r4 r8. ais16 dis'4 ais16 dis'8 g'16~ 
      | g'16 c''8 ais'16~ ais'16 g'8 dis'16~^\markup{\left-align \small vib} dis'4. r8 
      | r2 ais8. f16 ais8 d'8 
      | g'8 f'8 \tuplet 3/2 {d'4 ais8~} ais8 cis'8 d'4 
      | ais8. ais16 r2. 
      | c'8 d'8 dis'8 f'8 cis'8\glissando  d'16 f'16 g'8 ais'8~^\markup{\left-align \small vib} 
      | ais'4~ \tuplet 5/4 {ais'16 gis'16 ais'16 gis'16 f'16} \tuplet 3/2 {dis'4 f'8~^\markup{\left-align \small vib}} f'4~ 
      | f'8 ais'4 gis'16 f'16~ \tuplet 6/4 {f'16 dis'8 e'16 dis'16 cis'16~} \tuplet 3/2 {cis'8 ais8 gis8} 
      \bar "||" \mark \default ais2^\markup{\left-align \small vib} g16 ais8. ais4 
      | r8 ais'8~ \tuplet 6/4 {ais'16 gis'8 ais'16 gis'16 f'16} dis'16 f'16 dis'16 cis'16 ais8 gis8 
      | ais4.^\markup{\left-align \small vib} gis8 ais8 cis'8 r4 
      | r8 ais'8 gis'16 ais'16 gis'16 f'16~ \tuplet 5/4 {f'16 dis'16 f'16 dis'16 cis'16} ais8 gis8 
      | ais4 \tuplet 3/2 {ais4 ais8} cis'4 cis'8 cis'8 
      | ais8 cis'8 dis'4 f'4.^\markup{\left-align \small vib} dis'8~ 
      | dis'16 cis'16\glissando  d'8 \tuplet 3/2 {ais4 ais8} c'4. g8 
      | \tuplet 3/2 {ais4 c'8} d'4~ \tuplet 6/4 {d'16 c'4 ais16} r4 
      | r8. ais4.^\markup{\left-align \small vib} g8 dis16 r4 
      | r8 c'4.^\markup{\left-align \small vib} ais8 fis8 r4 
      | r8 cis'16 d'16~ d'4 ais8. g16~ g8. d'16\glissando  
      | dis'4 c'8 a4 e'8\glissando  \tuplet 3/2 {f'4 dis'8~} 
      \bar "||" \mark \default dis'16 d'8 dis'16 f'4 ais4^\markup{\left-align \small vib} r4 
      | r4 \tuplet 3/2 {c'8 d'8 dis'8} g'16 a'16 ais'16 c''16 d''8 r8 
      | r4 r8 d''8 cis''16 ais'8 f'16~^\markup{\left-align \small vib} f'4~ 
      | f'8. ais'16~ ais'16 gis'8 e'16~ e'16 g'8 f'16~ f'16 cis'8 b16~ 
      | b16 ais8 g16~ g16 gis8 ais16~ ais16 g8 dis16~ dis8 f8~^\markup{\left-align \small vib} 
      | f4 r2. 
      | \tuplet 3/2 {r8 f8 e8} dis16 f16 g16 a16 d'16 cis'16 c'16 b16 \tuplet 3/2 {ais8 g8 dis8} 
      | c4 \tuplet 6/4 {f8 e8 d16 e16~} e16 f16 g16 a16 b16 c'16 g8 
      | r4 r8 c8 \tuplet 3/2 {d8 dis8 g8} \tuplet 3/2 {ais8 a8 g8~} 
      | \tuplet 3/2 {g8 g8 d'8} \tuplet 3/2 {cis'8 c'8 b8} ais8 r8 r4 
      | e'8 f'4 dis'8 \tuplet 3/2 {d'8 dis'4} f'8 r8 
      | r4 r8. ais16 cis'8 d'8 \tuplet 3/2 {f'8 cis'8 d'8} 
      \bar "||" \mark \default f'8 ais8 ais2^\markup{\left-align \small vib} cis'16 d'16 f'16 g'16 
      | ais'4 ais'8 r8 r8. ais16 \tuplet 3/2 {cis'8 d'8 f'8} 
      | ais4 ais4^\markup{\left-align \small vib} r4 r8 f'8 
      | ais'8 ais'8~ ais'16 gis'8 gis'16~ gis'16 g'8 g'16~ g'16 f'8 f'16~ 
      | \tuplet 6/4 {f'16 dis'4 dis'16~} dis'2 dis'8 g'16 c''16 
      | ais'4 c''4 ais'4 c''8 r8 
      | r4 r8 b'8 \tuplet 3/2 {cis''4 ais'8~} ais'8 gis'8 
      | f'8 dis'8 cis'8 ais8 gis4 gis4 
      | ais8. ais16~ ais8 r8 r4 r8. ais16~ 
      | ais16 cis'8 d'16~ d'16 dis'8 e'16~ e'16 f'8 a16~ a16 cis'16\glissando  d'8 
      | ais4~ ais16 c'8 a16 cis'8 d'8 f'8. dis'16~^\markup{\left-align \small vib} 
      | dis'4 f'8 dis'8 \tuplet 3/2 {fis'8 g'8 ais'8~} ais'16 c''8 cis''16~ 
      \bar "||" \mark \default cis''4 c''8 b'8 \tuplet 3/2 {ais'4 f'8} r4 
      | r8 gis'8 g'8 fis'8~ \tuplet 6/4 {fis'16 f'4 ais16~} ais8. cis'16~^\markup{\left-align \small vib} 
      | cis'4 c'8 b8~ b16 ais8 c'16~ c'16 d'8 dis'16 
      | f'4 \tuplet 3/2 {d'8 dis'8 f'8} dis'16 d'8 fis16 gis4 
      | g8 r8 r2 \tuplet 3/2 {r8 ais,8 dis8} 
      | g4. \tuplet 6/4 {cis8 f16~} f8 gis8 fis8 b16 cis'16~ 
      | cis'4 r2 b8 dis'8 
      | fis'4 b8 d'8 g'4~ \tuplet 3/2 {g'8 d'8 f'8~} 
      | f'16 d'8 dis'16~ dis'16 g'8 ais'16~ ais'8 d''8 d''8 d''8 
      | r1 
      | r8 ais8~ ais8. c'16 d'16 ais'8 ais'16~ ais'8 ais'8~ 
      | ais'8 r8 r2. 
      \bar "||" \mark \default \tuplet 3/2 {ais'8 ais'4} \tuplet 3/2 {ais'8 ais'4} ais'8 ais'8 ais'8 ais'8 
      | ais'8 ais'8 ais'8 ais'8 ais'8 ais'8~ ais'16 ais'16 ais'8 
      | e''8 f''8~ f''2~ f''8 dis''8 
      | \tuplet 3/2 {d''8 dis''4} f''4 r4 r8 ais'8~ 
      | ais'16 e''8 dis''16~ dis''8 cis''8 ais'2~^\markup{\left-align \small vib} 
      | ais'4 \tuplet 3/2 {e''8 dis''8 cis''8} ais'4. gis'8 
      | f'4 f'8\glissando  e'8 r2 
      | r8. d'16 dis'8 f'16 ais'16~ ais'16 d'16 f'16 e'16 dis'8 cis'8 
      | ais4 fis'4 ais16 cis'16 d'8 f'8. ais'16~^\markup{\left-align \small vib} 
      | ais'4~ ais'16 g'8 dis'16 d'4~ \tuplet 6/4 {d'16 f'4 a16\glissando } 
      | ais4 c'8 ais8 cis'16 d'8. g4 
      | r4 r8. g16~ g4 g4 
      \bar "||" \mark \default g4 r2 \tuplet 3/2 {g8 g4} 
      | g4 r2 \tuplet 3/2 {g8 g4} 
      | g2^\markup{\left-align \small vib} r2 
      | \tuplet 6/4 {d8 dis8 f16 g16~} \tuplet 6/4 {g16 gis16 g8 f16 dis16} d8 f16 gis16 b8 r8 
      | r2. \tuplet 6/4 {r16 fis16 g8 fis16 g16~} 
      | \tuplet 6/4 {g16 ais8 fis16 g16 ais16~} ais16 g16 fis16 f16 dis8 r8 r4 
      | ais,8 c16 f16~ \tuplet 5/4 {f16 cis16 d16 dis16 gis16~} gis16 fis8 gis16 ais16 cis'16 ais16 cis'16 
      | dis'16 fis'16 e'8 r4 \tuplet 3/2 {r8 dis8 g8} gis16 b16 gis16 b16 
      | d'16 e'16 d'8 r2 r8 ais'8~ 
      | ais'8. d'16~ d'16 dis'8 f'16~ f'8 g'8 ais'8 a'8 
      | g'8 f'4 c'16 dis'16~ dis'8 d'16 cis'16~ cis'16 c'8 b16 
      | ais8 r8 r8. cis'16 d'8. f'16 g'4 
      \bar "||" \mark \default ais'8 ais'8 ais'8 ais'8 gis'4 \tuplet 3/2 {f'4 ais'8~} 
      | ais'8 gis'8 f'8. f'16~ f'8 r8 r4 
      | r8. ais16~ ais8 cis'4 f'4 ais'8~ 
      | ais'8 cis''8~ cis''8.\glissando  f''16~ f''2~ 
      | f''4. r8 r2 
      | r8 e''8 r2. 
      | r8 b''16 c'''16~ c'''8 e''8 dis''4. cis''8 
      | ais'4.^\markup{\left-align \small vib} cis''4 ais'8 cis''8 dis''8 
      | \tuplet 3/2 {dis''8\glissando  e''8 dis''8~} dis''4. r8 r4 
      | r4 e''16 dis''8 cis''16 ais'4.^\markup{\left-align \small vib} gis'8~ 
      | gis'16 f'8 gis'16 r2. 
      | r2 c''8\glissando  cis''4 ais'8 
      \bar "||" \mark \default \tuplet 3/2 {cis''8 ais'8 cis''8} ais'2 gis'8. gis'16~ 
      | gis'8 f'4.^\markup{\left-align \small vib} \tuplet 3/2 {dis'8 cis'8 dis'8} ais4~^\markup{\left-align \small vib} 
      | ais4~ ais16 gis16 f16 gis16 f4.. gis16 
      | c'16 dis'16 g'16 d'16~ \tuplet 6/4 {d'4 f'16 gis'16} c''16 ais'8. r4 
      | r8 dis''4. cis''4 ais'8. dis''16~ 
      | \tuplet 3/2 {dis''8 cis''8 ais'8~} ais'16 gis'8 fis'16~ fis'16 dis'8 f'16~ f'8 r8 
      | r8. dis'16~ dis'8 f'8~^\markup{\left-align \small vib} f'16 dis'8 cis'16 ais4~ 
      | \tuplet 3/2 {ais8 c'8 cis'8~} cis'16 c'8 ais16~ \tuplet 6/4 {ais8 a8. f16~} f8 r8 
      | r2. r8. c'16~ 
      | \tuplet 3/2 {c'8 d'8 dis'8} \tuplet 6/4 {g'8 ais'16 a'8 g'16} \tuplet 3/2 {f'8 e'8 dis'8} \tuplet 3/2 {d'8 c'8 ais8} 
      | a8 r8 r2 r8 e'8 
      | f'8 r8 r2. 
      \bar "||" \mark \default e'8 f'8~ f'16 f'8 f'16~ \tuplet 6/4 {f'16 e'4 f'16~} f'16 f'8 f'16~ 
      | f'16 e'8 f'16~ f'16 f'8 f'16 e'8\glissando  f'8 f'8 f'8 
      | e'8 f'8 f'8 f'8 e'8 f'8 \tuplet 3/2 {f'4 f'8~} 
      | f'8 ais'8 dis'8 e'8 dis'2^\markup{\left-align \small vib} 
      | cis'8 ais8 ais8 r8 r2 
      | r8. ais16 cis'8 d'8 \tuplet 3/2 {f'8 cis'8 d'8} \tuplet 3/2 {f'8 cis'8 d'8} 
      | \tuplet 3/2 {f'4 a8\glissando } ais4 g'4 f'4~ 
      | f'8 r8 r2. 
      | c'8 dis'8~ dis'16 d'8 c'16 f'4 c'8 dis'8 
      | \tuplet 3/2 {d'4 c'8} f'4 c'8 dis'8 d'8 c'8 
      | \tuplet 3/2 {f'4 f'8~} f'16 f'8 f'16~ f'16 cis'16\glissando  d'8 d'8 r8 
      | r1 
      \bar "||" \mark \default r8 ais'4 a'4 g'4. 
      | ais'4 f'4 f'4.^\markup{\left-align \small vib} dis'8 
      | d'4 d'4 c'4 c'4 
      | ais8 c'8 d'8 dis'8 f'8 r8 \tuplet 6/4 {r4 f'16 dis'16} 
      | cis'8. ais16~^\markup{\left-align \small vib} ais4 r2 
      | r8 g16 ais16 cis'16 f'16 a'16 cis''16 a'4 c''8 e'8\glissando  
      | f'4 r2. 
      | r16 e''16 d''16 c''16 gis'16 f'8. \tuplet 6/4 {dis''4 ais'16 gis'16} e'8 dis'8~^\markup{\left-align \small vib} 
      | dis'4~ dis'16 g'16 ais'16 cis''16 \tuplet 3/2 {d''4 c''8~} c''8 r8 
      | \tuplet 6/4 {r4 e''16\glissando  f''16~} f''4 d''8 c''8~ \tuplet 5/4 {c''8 a'8 c''16~} 
      | c''8 ais'8 f'4 r4 r8 fis'8\glissando  
      | g'8 gis'8 g'8 fis'8 f'8. ais16~ ais16 cis'16\glissando  d'8 
      \bar "||" ais4 ais4 r2\bar  ".."
    }
    >>
>>
}
