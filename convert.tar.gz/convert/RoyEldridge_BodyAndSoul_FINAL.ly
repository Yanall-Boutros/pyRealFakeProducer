\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Body and Soul"
  composer = "Roy Eldridge"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble"
    \key des \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              | r4 s2. | s1 
      | es2:min7 bes2:9- | es2:min7 d2:7 | des2:maj ges2:7 | f2:min7 e2:dim7 | es1:min7 | c2:min5-7 f2:7 | bes4:min7 es4:7 es4:min7 aes4:7 | des2:6 bes2:7 
      | es2:min7 bes2:9- | es2:min7 d2:7 | des2:maj ges2:7 | f2:min7 e2:dim7 | es1:min7 | c2:min5-7 f2:7 | bes4:min7 es4:7 es4:min7 aes4:7 | des2 a2:7 
      | d2:maj e2:min7 | d2:/fis g4:min7 c4:7 | fis4:min7 b4:min7 e4:min7 a4:7 | d1:maj | d2:min7 g2:7 | c2:maj es2:dim | d2:min7 g2:7 | c4:7 b4:7 bes2:7 
      | es2:min7 bes2:9- | es2:min7 d2:7 | des2:maj ges2:7 | f2:min7 e2:dim7 | es1:min7 | c2:min5-7 f2:7 | bes4:min7 es4:7 es4:min7 aes4:7 | des1:6 
      | s4 r2.|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 107
      \set Score.currentBarNumber = #-1
     
      \bar "||" \mark \default c''8 d''8 e''8 d''16 d''16 c''16 a'16 f'16 d'16 dis'8 g16 gis16 
      | b16 d'16 dis'16 f'32 g'32~ g'16 gis'16 ais'16 ais'16 \tuplet 3/2 {a'8 ais'4^\markup{\left-align \small vib}} gis'16 ais'16 f'8 
      \bar "||" \mark \default dis'4 f'8 dis'8 f'8^\markup{\left-align \small vib} r8 r4 
      | \tuplet 6/4 {r4 r16 ais16} dis'16 fis'16 gis'16 ais'16 a'16\glissando  a16 cis'16 e'16 a'16 cis''16 b'16 a'16 
      | gis'4^\markup{\left-align \small vib} ais'16 ais'16 gis'16 ais'16 gis'8 ais'8^\markup{\left-align \small vib} r4 
      | r4 \tuplet 6/4 {dis''8. dis''8 dis''16~} \tuplet 3/2 {dis''8 d''8 cis''8} c''8 b'8 
      | c''8\glissando  cis''8 ais'8^\markup{\left-align \small vib} r8 r8. ais'16 \tuplet 3/2 {cis''8 b'8 cis''8} 
      | ais'16\glissando  f'16 e'16 dis'16~^\markup{\left-align \small vib} dis'8 r8 r8. f''16~^\markup{\left-align \small vib} f''8 dis''16 cis''16 
      | ais'16\glissando  f'16 e'16 dis'16 \tuplet 3/2 {cis'8 gis4} a16 cis'16 e'16 fis'16 \tuplet 3/2 {a'8 a'8 gis'8~^\markup{\left-align \small vib}} 
      | gis'8 b'16 ais'16 gis'16 d'16 dis'16 f'16 gis'16 ais'16 b'16 ais'16 \tuplet 3/2 {gis'8 f'4} 
      \bar "||" dis'4^\markup{\left-align \small vib} f'4 r8. gis''16~ gis''16 gis''8 gis''16~ 
      | gis''16 f'16 f''16 gis''16 g''16 e'16 e''16 g''16 \tuplet 5/4 {fis''8 a'16 dis''16 fis''16} \tuplet 5/4 {f''8 b'16 f''16 dis''16} 
      | cis''16 ais'16 f'16 e'32 dis'32~ dis'16 cis'16 ais8 a16 ais16 cis'16 dis'16 f'16 gis'16 ais'16 a'16 
      | \tuplet 6/4 {c''8. c''8 c''16~} c''16. ais'8 cis''32~ cis''16 ais'16 c''8 \tuplet 3/2 {cis''8 ais'8 c''8} 
      | \tuplet 3/2 {cis''4 ais'8^\markup{\left-align \small vib}} r2 r16 b'16 cis''16 fis''16 
      | gis''4 f''8.^\markup{\left-align \small vib} dis''16 cis''16 ais'16 f'16 e'16 dis'16 cis'8 a16~ 
      | a4. cis'16 e'16 a'16 cis''16 b'16 a'16~ a'8. gis'16~^\markup{\left-align \small vib} 
      | gis'4~ gis'16 f'16 a'16 ais'16 b'16 d''16 b'16 c''16 \tuplet 3/2 {cis''8 e''16 r8.} 
      \bar "||" r8. b16 d'16 e'16 fis'16 a'16~ a'8 a'8^\markup{\left-align \small vib} r4 
      | r8. a'16 d''16 e''16 f''16 e''16 \tuplet 3/2 {d''8 a'8\glissando  ais'8\glissando } a'4~^\markup{\left-align \small vib} 
      | a'8. a16 \tuplet 7/8 {d'16 e'32 fis'16 gis'32 c''32~} c''8 d''8~ \tuplet 6/4 {d''8. ais'8 a'16~} 
      | a'16 a16 d'16 e'16 f'16 g'16 a'8 e'8\glissando  a16 d'16~^\markup{\left-align \small vib} d'8 r8 
      | r4 e''8 e''8 e''8 e''8 \tuplet 3/2 {e''8 e''8 e''8} 
      | dis''16 e''16 g''8 e''16 d''16 c''16 a'16 c''8.^\markup{\left-align \small vib} gis'16\glissando  a'8.^\markup{\left-align \small vib} c''16~ 
      | c''16 a'16 f'16 f'16 d'16 f'16 g'16 b'16~ b'8. cis''32\glissando  d''32~ \tuplet 3/2 {d''8 cis''8 d''8} 
      | c''16 cis''16 d''16 g'16 gis'16 ais'16 b'16 c''16 cis''16 d''16 cis''16 c''16 ais'16 gis'16 f'8 
      \bar "||" dis'4 f'8 ais16 dis'16~^\markup{\left-align \small vib} dis'8 r8 r8. ais16 
      | dis'16 f'16 gis'16 ais'16 gis'8 gis16 gis16~ \tuplet 6/4 {gis16 a8 ais16 cis'16 e'16} \tuplet 3/2 {fis'8 a'4~} 
      | a'32 gis'16. gis16. cis'32~^\markup{\left-align \small vib} cis'4. gis'8 ais'16 ais'16 gis'8 
      | dis''8 dis''8 dis''8 dis''8 \tuplet 3/2 {dis''8 d''8 cis''8} c''8 ais'8 
      | r4 cis''4 ais'4.^\markup{\left-align \small vib} cis''16 ais'16 
      | f'8 f'4.^\markup{\left-align \small vib} r4 \tuplet 6/4 {f''8. e''8 dis''16~} 
      | \tuplet 9/8 {dis''16 cis''16. ais'16. f'32~} \tuplet 6/4 {f'16 e'8 dis'8 cis'16~} \tuplet 6/4 {cis'8 ais8 cis'16 e'16~} e'16 a'16 cis''8 
      | gis'4~^\markup{\left-align \small vib} gis'16 cis''16 b'16 a'16 \tuplet 3/2 {g'8 e'8 d'8} \tuplet 3/2 {cis'8 e'8 a'8} 
      | d'4^\markup{\left-align \small vib} r2.\bar  ".."
    }
    >>
>>
}
