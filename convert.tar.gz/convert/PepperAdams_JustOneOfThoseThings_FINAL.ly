\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Just One of Those Things"
  composer = "Pepper Adams"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "bass"
    \key f \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              | d1:min7 | s1 | s1 | s1 
      | d1:min7 | d1:min7 | e1:min7 | a1:7 | f1:7 | s1 | b1:min5-7 | bes1:min6 
      | f1:/a | aes1:7 | g1:min7 | c1:7 | f1:6 | fis1:dim | g1:min7 | e2:min5-7 a2:9+ 
      | d1:min7 | s1 | e1:min7 | a1:7 | f1:7 | s1 | b1:min5-7 | bes1:min6 
      | f1:/a | aes1:7 | g1:min7 | c1:7 | f1:6 | fis1:dim7 | f1:min7 | bes1:7 
      | es1:maj | e1:dim | f1:min7 | bes1:7 | es1:6 | s1 | d1:min7 | g1:7 
      | c1:6 | s1 | fis1:min5-7 | f1:min7 | e1:min7 | es1:dim | g1:min7 | e2:min5-7 a2:9+ 
      | d1:min7 | s1 | e1:min7 | a1:7 | f1:7 | s1 | b1:min5-7 | bes1:min6 
      | f1:/a | d1:7 | g1:min7 | c1:7 | f1:maj | s1 | e1:min5-7 | a1:7 
      | d1:min7 | s1 | e1:min7 | a1:7 | f1:7 | s1 | b1:min5-7 | bes1:min6 
      | f1:/a | aes1:7 | g1:min7 | c1:7 | f1:maj | fis1:dim7 | g1:min7 | e2:min5-7 a2:9+ 
      | d1:min7 | s1 | e1:min7 | a1:7 | f1:7 | s1 | b1:min5-7 | bes1:min6 
      | f1:/a | aes1:7 | g1:min7 | c1:7 | f1:maj | fis1:dim7 | f1:min7 | bes1:7 
      | es1:6 | e1:dim | f1:min7 | bes1:7 | es1:6 | s1 | d1:min7 | g1:7 
      | c1:6 | s1 | fis1:min5-7 | f1:min7 | e1:min7 | es1:dim | g1:min7 | e2:min5-7 a2:9+ 
      | d1:min7 | s1 | e1:min7 | a1:7 | f1:7 | s1 | b1:min5-7 | bes1:min6 
      | f1:/a | d1:7 | g1:min7 | c1:7 | f1:maj | s1 | e1:min5-7 | a1:7|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 314
      \set Score.currentBarNumber = #-3
     
      | r2 g8 e8 f8 g8 
      | a8 c'8 e'8 d'8 c'8 a8 g16 f8 e16~ 
      | \tuplet 3/2 {e8 c8 d8~} d8 g8 \tuplet 3/2 {e4 f8} a8 ais8~ 
      | ais8 gis8 \tuplet 3/2 {g8 f8 e8} d8 cis4 e8~ 
      \bar "||" \mark \default \tuplet 3/2 {e8 cis8 d8~} d8 e8 f8 g16 a16~ \tuplet 3/2 {a8 ais8 e'8~} 
      | \tuplet 3/2 {e'8 d'8 e'8} d'8 b8 \tuplet 3/2 {a4 b8} a8 r8 
      | r4 r8. e16~ e8 f8 \tuplet 3/2 {g8 a8 ais8~} 
      | ais16 a8 gis16~ \tuplet 3/2 {gis8 g8 f8~} f16 e8 d16~ d8 b,8 
      | c8. b,16 \tuplet 3/2 {c4 d8} dis8 f8 g8 a8 
      | \tuplet 3/2 {d'4 b8~} \tuplet 3/2 {b8 c'8 d'8} dis'8 f'8 r4 
      | r8 cis8~ \tuplet 3/2 {cis8 f8 g8} c'8 ais8 a8 f8 
      | c'4 gis8 f8 cis16 c8. ais,8 r8 
      | r2 gis,8 c8~ c16 dis8 g16~ 
      | g16 gis8 ais16~ ais16 b8 cis'16 \tuplet 3/2 {c'8 ais8 gis8~} gis8 r8 
      | r2 g4 \tuplet 3/2 {a8 ais8 c'8~} 
      | c'8 cis'8 d'8 ais8 b8 c'8 r4 
      | r4 c'8 a8 g8 f16 e16~ e8 c8 
      | d8 e8 g8 f8 e8 d8 ais8 g8 
      | a8 r8 r4 dis8 f8 g16 a8 a16 
      | \tuplet 3/2 {ais4 a8\glissando } ais8 ais8 a8. dis16 r4 
      \bar "||" r8 cis8 \tuplet 3/2 {d4 e8} f8 g8 a8 ais8 
      | \tuplet 3/2 {dis8\glissando  e4~} e8 d'8 e'8 d'8 r4 
      | r4 r8. a16 ais4 e8. gis16 
      | a8 r8 r4 gis8 f8 cis4 
      | a,8 d4. \tuplet 3/2 {d4 b,8} \tuplet 3/2 {c4 cis8} 
      | dis8 r8 r4 \tuplet 3/2 {r8 cis8 dis8} g4 
      | c'8 d'8 f'8 c'8 r4 r8 c'8 
      | cis'8 dis8~ \tuplet 3/2 {dis8 f8 g8} c'8 ais8 r4 
      | r4 e'8 d'8 \tuplet 3/2 {c'4 a8} g8 f8 
      | e4 \tuplet 3/2 {e4 c8} d8 r8 r4 
      | r8. d16~ d8 fis8 \tuplet 3/2 {a8 c'8 a8} ais8 c'8 
      | cis'8. dis'16~ dis'8 c'4 ais8~ ais16 f8 g16 
      | a4 r2 a8 c'8 
      | e'8 d'8 c'8 a8~ \tuplet 3/2 {a8 g8 f8} \tuplet 3/2 {e4 d8} 
      | f8 e8 f8 g8 gis4. d8 
      | g8 f8 dis8 c8 d8 ais8 r4 
      \bar "||" r4 g8 ais8 d'8 c'8 ais8 g8 
      | f8 dis8 d8 ais,8 \tuplet 3/2 {cis4 b,8} c8 r8 
      | r2 ais,8. g,16 gis,8 ais,8~ 
      | \tuplet 3/2 {ais,8 c8 dis8} g8 f8 gis8 ais8 g8 f8 
      | \tuplet 3/2 {dis8 d8 ais,8} c8 d8 \tuplet 3/2 {f4 dis8} d8 dis8 
      | g8 ais8 c'8 dis'8 r2 
      | r4 e8 cis8 d8 e8 a8 g16 a16~ 
      | a8 b8 a16 ais8 b16~ b16 gis8 g16~ g8 f8 
      | e8. g16~ g8 d'8 b8 c'8 r4 
      | r8. b16~ b8 a8 g8 e8 c4 
      | fis4 a8 c'8 e'8 r8 r4 
      | dis'8 e'8 \tuplet 3/2 {dis'8 c'8 b8} gis8 g8 f8 r8 
      | r2. e8 g8 
      | b8 a8 g8 e8 d8 c8 b,8 g,8 
      | c8 r8 r2 c16 b,8 a,16 
      | gis,4 \tuplet 3/2 {ais,8 c8 dis8} d4 \tuplet 3/2 {dis4 f8} 
      \bar "||" \tuplet 3/2 {g8 a4} r2. 
      | d8 f8 a8 ais4 a8 f8 cis8 
      | g4 r2 dis'8 g8 
      | a16\glissando  ais8 dis16~ dis16 f16 g8 ais8 a8 r4 
      | r2 c'8 b8 a8 g8 
      | f8 e8 \tuplet 3/2 {dis4 f8} g8 a8 d'8 c'8~ 
      | c'8 f'8 cis'8 c'8 \tuplet 3/2 {ais8 a8 g8~} g4 
      | e'8\glissando  f'8 cis'8 c'16 ais16 dis4 fis8 r8 
      | r2 a8 c'8 e'8 g'8~ 
      | g'8 e'16 f'16 fis'8 d'8 r2 
      | e'8 f'8 d'8 ais16 a16~ a8 g8 \tuplet 3/2 {fis8 e8 f8~} 
      | \tuplet 3/2 {f8 dis8 e8~} e8 c'8 r2 
      | r4 c'8 d'8 e'8 f'8 \tuplet 3/2 {e'8 d'8 c'8~} 
      | \tuplet 3/2 {c'8 d'8 c'8~} c'16 ais8 a16~ a8 c8 d8 e8 
      | g8 f8 e8 c8 d8 a,8 ais,8 b,8 
      | cis8 dis8 e8 fis8 g8 a8 ais8 b16 cis'16~ 
      \bar "||" \mark \default cis'8 e'8 d'8 a8 g8 r8 r4 
      | \tuplet 3/2 {r8 cis'8 e'8} \tuplet 3/2 {d'4 a8} g8 f8 \tuplet 3/2 {e4 cis8} 
      | \tuplet 3/2 {d4 a,8~} a,16 ais,8 c16 cis8 dis8 e8 fis8 
      | g8 a8 ais8 c'16 cis'16~ cis'16 e'8 d'16 b4 
      | c'8 r8 r2 b16 c'8 d'16 
      | dis'8 f8 \tuplet 3/2 {g8 a8 cis'8} c'8 r8 r4 
      | r8 d'8 g'4 f'4 c'8 cis'8 
      | dis4~ \tuplet 3/2 {dis8 f8 c'8} ais8 r8 r4 
      | r8. b16~ \tuplet 3/2 {b8 e'8 d'8} r4 r8. dis'16~ 
      | dis'16 c'16 cis'16 ais16~ ais8 a8 g8 fis8 r4 
      | r8 d8 g8 a8 ais8 b,8 c8 d8 
      | a8 g16 f16~ f8 dis8 e8 d8 c8 ais,8 
      | a,8 c8 e8 c8 \tuplet 3/2 {e4 c8} r4 
      | r4 r8. c16~ c8 d8 e8 g8 
      | e8 f8 a8 c'8 e'8. d'16~ d'8 a8 
      | ais8 c'8 cis'8 e'8 fis'8 r8 r4 
      \bar "||" r2 gis2~^\markup{\left-align \small vib} 
      | gis4 r4 gis'8. a'16~ a'4~ 
      | a'4~ \tuplet 3/2 {a'8 e'8 g'8~} g'8 f'4 e'8~ 
      | e'8 d'4 cis'8~ cis'16 e'8 f'16~ f'8 gis8 
      | a8 r8 r4 c'8 b8~ b16 ais16 a16 g16~ 
      | \tuplet 3/2 {g8 f8 dis8~} dis4 \tuplet 3/2 {f4 g8} \tuplet 3/2 {a8 d'4} 
      | \tuplet 3/2 {c'8 e'8 f'8~} f'8 d'8 \tuplet 3/2 {c'4 ais8} a16 dis8 c16~ 
      | c8 cis8 \tuplet 3/2 {dis4 f8~} f16 c'8 ais16 r4 
      | r2 gis8 g8 dis'8 g'8 
      | e'4 \tuplet 3/2 {gis8 g8 gis8~} gis16 ais16 c'16 dis'16 gis'8 r8 
      | r2 \tuplet 3/2 {fis8 g4} ais16 cis'16 f'8 
      | d'8. f16 fis4 \tuplet 3/2 {gis8 cis'8 f'8} a'8 r8 
      | r2 e'8 d'8 c'8 a8 
      | \tuplet 3/2 {g8 f8 e8~} e8 c8 d4 g8 f8 
      | e8 f8 ais8 a8 gis16 g16 a8 c'8 b8 
      | c'8. d'16 dis'8 b8 \tuplet 3/2 {gis8 g8 f8} ais8 g8 
      \bar "||" f8 dis8 d8 ais,8 c8 d8 f8 dis8~ 
      | \tuplet 3/2 {dis8 cis8 dis8} gis8 ais8 cis'8 c'8 r4 
      | r4 r16 dis'8 b16 \tuplet 3/2 {gis8 f8 f8~} f8 d'8~ 
      | d'8\glissando  dis'8 c'8 gis8 fis8. ais16 r4 
      | r4 d'8 c'8 ais8 g8 f8 dis8 
      | d8 dis8 g8 ais8 d'8 c'4 d8~ 
      | d8 e8 f8 a8 c'8 r8 r4 
      | r8 c'8 a16 b8 d'16 \tuplet 3/2 {gis4 f8} \tuplet 3/2 {g4 f8} 
      | \tuplet 3/2 {e4 g8} a8 b8 \tuplet 3/2 {cis'8\glissando  d'4~} d'16 c'8 b16~ 
      | b8 c'8 b8 a8 g8 e8 d8 r8 
      | r4 \tuplet 3/2 {a,4 b,8} c16 e8 fis16 gis4 
      | \tuplet 3/2 {fis4 f8} r2 r8 f8 
      | \tuplet 3/2 {g8 gis8 ais8~} ais16 c'8 d'16 \tuplet 3/2 {c'8 b16 r8.} r4 
      | r8. cis'16~ cis'16 c'8 b16~ b8 gis8 g8 e8 
      | c4 d4 r4 r8. e16~ 
      | \tuplet 3/2 {e8 f8 g8~} g16 a8 ais16~ \tuplet 3/2 {ais8 gis8 a8~} a16 g8 f16~ 
      \bar "||" f8 r8 r2. 
      | r2 r16 gis16 fis16 f16 cis8 ais,8 
      | cis8 d4. cis4 e8 ais,8~ 
      | ais,8 r8 r4 e8 c16 a,16 \tuplet 3/2 {ais,8 ais,16 r8.} 
      | r8. d16~ d8 b,8 c8 d16 dis16~ dis8 f8 
      | \tuplet 3/2 {g8 a8 d'8} c'8 r8 r4 cis8 d8 
      | \tuplet 3/2 {f8 g8 a8~} a8 c'8 ais4 c8 cis8~ 
      | cis8 f8 g16 a8 c'16~ c'8 dis'8 r4 
      | r4 r8 e'8 \tuplet 3/2 {d'8 c'4} a8 g16 fis16 
      | \tuplet 3/2 {f8 e8 c8} \tuplet 3/2 {dis4 ais8} r4 r8. cis16 
      | d8 f8 a16 c'16 ais16 a16~ \tuplet 3/2 {a8 ais8 c'8~} c'16 cis'8 dis'16~ 
      | dis'8 c'4 ais8 f8 g16 gis16\glissando  a8 r8 
      | r4 a8 c'8 dis'16\glissando  e'16 d'8 c'8 a8 
      | \tuplet 6/4 {g4 f16 e16~} e8 c8 d8 e8 g8 e8 
      | f8 g8 r2 g8 a8 
      | \tuplet 3/2 {ais4 gis8} \tuplet 3/2 {g8\glissando  a4~} a8 f8 d4\bar  ".."
    }
    >>
>>
}
