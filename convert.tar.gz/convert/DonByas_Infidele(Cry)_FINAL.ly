\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Infidele (Cry)"
  composer = "Don Byas"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble_8"
    \key bes \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              | c4:min7 r4 s4 s4 | f1:7 | bes2:maj g2:7 | c2:min7 f2:7 
      | bes1:maj | bes1:maj | a2:min7 aes2:dim | g2:min7 d2:7/fis | g1:min7 | s1 | d2:min7 des2:dim | c2:min7 b2:dim7 
      | c1:min7 | f1:7 | bes2:maj aes2:7 | g1:7 | c1:maj | c1:min7 | f1:7 | c2:min7 f2:7 
      | bes1:maj | s1 | a2:min7 aes2:dim | g2:min7 ges2:dim | g1:min7 | s1 | d2:min7 des2:dim | c2:min7 b2:dim 
      | c1:min7 | f1:7 | bes2:maj aes2:7 | g1:7 | c1:min7 | f1:7 | bes2:maj g2:7 | c2:min7 f2:7 
      | bes1:maj|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 120
      \set Score.currentBarNumber = #-3
     
      \bar "||" \mark \default r8. g16~ \tuplet 6/4 {g16 fis8 g8 ais16~} ais16 d'16 f'16 dis'16~ dis'16 d'16 c'16 ais16 
      | g4.^\markup{\left-align \small vib} ais8~ \tuplet 3/2 {ais8 d'8 f'8} \tuplet 3/2 {d'4 ais8~^\markup{\left-align \small vib}} 
      | ais4 r4 \tuplet 3/2 {dis'8\bendAfter #+4  f'4~} f'8. fis'16 
      | \tuplet 3/2 {g'8 dis'8 d'8} \tuplet 3/2 {c'8 ais8 g8} \tuplet 3/2 {a4 f'8} cis'4 
      \bar "||" \mark \default c'4..^\markup{\left-align \small vib} ais16~ ais8 f'4^\markup{\left-align \small vib} r8 
      | r4 r16 c''8 a'16 ais'8 a'16 g'16 \tuplet 3/2 {f'8 dis'8 d'8} 
      | \tuplet 3/2 {c'8 ais8 a8} e'4. gis8~ gis16 e'8 g16~ 
      | g8 e'8 fis8^\markup{\left-align \small vib} r8 r4 \tuplet 6/4 {dis'8 dis'8. cis'16} 
      | d'4.^\markup{\left-align \small vib} r8 r8. cis16~ cis16\bendAfter #+4  dis8\bendAfter #+4  c16 
      | d4~^\markup{\left-align \small vib} \tuplet 6/4 {d4~ d16 a16~} a16 fis16 g16 ais16~ \tuplet 6/4 {ais16 d'8 g'8 e'16} 
      | f'4^\markup{\left-align \small vib} r4 \tuplet 6/4 {r8. dis'16 e'16 f'16} cis'8 f'8 
      | c'8 f'4 gis8\bendAfter #+4  ais4. gis8 
      \bar "||" g4.^\markup{\left-align \small vib} r8 r8. ais16~ ais8 d'8~ 
      | d'16 e'16\bendAfter #+4  f'16 dis'16 g'8 ais'8 \tuplet 3/2 {a'8 c''8 g'8} dis'4~^\markup{\left-align \small vib} 
      | dis'8 r8 r8 c'16 d'16 f'16 d'16 dis'16 f'16 g'4~^\markup{\left-align \small vib} 
      | \tuplet 6/4 {g'16 fis'16 g'16 fis'16 f'8} d'8.^\markup{\left-align \small vib} c'16~ \tuplet 6/4 {c'16 ais16 b16 e'16 f'16 e'16} d'16 b16 gis16 f16 
      | e4^\markup{\left-align \small vib} r4 \tuplet 6/4 {r8 d''16 c''16 b'16 ais'16} g'16 fis'16 d'16 ais16 
      | \tuplet 5/4 {fis8\bendAfter #-4  e16 f16 a16} \tuplet 3/2 {cis'8 d'8 f'8} \tuplet 6/4 {e'16 f'16 e'16 cis'8 c'16} ais16 gis16 g16 dis16 
      | e16 g16 e16 fis16 g16 gis32 a16 c'32 d'32 dis'32 \tuplet 3/2 {f'8 e'8 f'8} g'8 gis'8 
      | r4 a'8 c''8 g'8 dis'8~ dis'32 c'16. cis'16. d'32~ 
      \bar "||" \mark \default d'8 f'16 a'16 c''4 a'16 ais'8 g'16 dis'8 c'8 
      | \tuplet 3/2 {d'4 f'8~^\markup{\left-align \small vib}} f'4 r4 \tuplet 3/2 {d'4 d'8~} 
      | \tuplet 3/2 {d'8 dis'8\bendAfter #+4  e'8} fis'8. e'16 fis'16 e'4..~^\markup{\left-align \small vib} 
      | e'8 a16\bendAfter #+4  b16~ b8. a16 b16 a4..~^\markup{\left-align \small vib} 
      | a8 g8~ g8. a16 \tuplet 3/2 {ais8 c'8 d'8~} \tuplet 6/4 {d'16 dis'8. cis'16 d'16~} 
      | d'8. g16~^\markup{\left-align \small vib} g2 gis4\bendAfter #+4  
      | ais4.^\markup{\left-align \small vib} f'8~ f'16 cis'8 a16~ a8 f8 
      | c'8 a8 f8 a16 b16 ais4^\markup{\left-align \small vib} r4 
      \bar "||" r8 dis16\bendAfter #+4  fis16~ fis16 g16 ais16 d'16 f'8 dis'8~ \tuplet 3/2 {dis'8 g8 ais8} 
      | d'8 c'8 fis2~^\markup{\left-align \small vib} fis8 r8 
      | r8. f16~ \tuplet 3/2 {f8 cis8 d8~} d16 f8 a16~ \tuplet 6/4 {a16 c'4 ais16~} 
      | ais8 a8~^\markup{\left-align \small vib} a4.. fis16\bendAfter #+4  \tuplet 3/2 {g8 gis4} 
      | \tuplet 5/4 {fis16 g8 ais16 d'16~} d'16 dis'8\bendAfter #+4  f'16~^\markup{\left-align \small vib} f'4. dis'8~ 
      | dis'16 d'8 dis16~^\markup{\left-align \small vib} dis4 r4 r8 fis8 
      | \tuplet 3/2 {e8 f8 a8} \tuplet 3/2 {c'4 f'8~} f'8 b8~^\markup{\left-align \small vib} \tuplet 6/4 {b4 g16\bendAfter #+4  ais16~} 
      | ais8 fis8 \tuplet 5/4 {g16 ais16 d'16 f'16 d'16} dis'8.^\markup{\left-align \small vib} c'16~ c'32 cis'16 a16 g16 dis32 
      \bar "||" \mark \default d4^\markup{\left-align \small vib} r2.\bar  ".."
    }
    >>
>>
}
