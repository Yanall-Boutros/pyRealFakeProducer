\version "2.13.2"

#(ly:set-option 'point-and-click #f)

\header {
  title = "Un Amour Pleurait"
  composer = "Don Byas"
  tagline = ##f
}
global =
{
    \override Staff.TimeSignature #'style = #'()
    \time 4/4
    \clef "treble_8"
    \key f \major
    \override Rest #'direction = #'0
    \override MultiMeasureRest #'staff-position = #0
}
\score
{
<<
    \transpose c' c'

    \new ChordNames { \chords {
              \set majorSevenSymbol = \markup { "maj7" }
              \set minorChordModifier = \markup { \char ##x2013 }
              | r1 
      | f2:/c des2:dim | d2:min g2:min7 | c2:7 g4:min7 c4:7 | f1:maj | s2 a2:7 | d2:min7 des2:dim | c2:7 g4:min7 c4:7 | f1:maj 
      | f2:/c des2:dim | d2:min7 g2:min7 | c2:7 g4:min7 c4:7 | f1:maj | a1:7 | d2:min7 des2:dim | c1:7 | f2 f2:7 
      | bes1 | es2 c2:min7 | f2:7 c4:min7 f4:7 | bes1 | s2 d2:dim | es2:maj aes2:7 | bes2 f2 | bes4 f4 g4:7 c4:7 
      | c2:/f des2:dim | d2:min7 g2:min7 | c1:7 | f1:maj | a1:7 | d1:min7 | c2:7 g4:min7 c4:7 | f1:maj 
      | s2. r4|
              }
              }
    \new Staff
    <<
    \transpose c' c'

    {
      \global
  		%\override Score.MetronomeMark #'transparent = ##t
  		%\override Score.MetronomeMark #'stencil = ##f
  		\override HorizontalBracket #'direction = #UP
  		\override HorizontalBracket #'bracket-flare = #'(0 . 0)
  		\override TextSpanner #'dash-fraction = #1.0
  		\override TextSpanner #'bound-details #'left #'text = \markup{ \concat{\draw-line #'(0 . -1.0) \draw-line #'(1.0 . 0) }}
  		\override TextSpanner #'bound-details #'right #'text = \markup{ \concat{ \draw-line #'(1.0 . 0) \draw-line #'(0 . -1.0) }}
        \set Score.markFormatter = #format-mark-box-numbers
      \tempo 4 = 106
      \set Score.currentBarNumber = #0
     
      | r2 r8 a8 \tuplet 6/4 {ais16 c'16 e'8 gis'16 c''16} 
      \bar "||" \mark \default a'4~^\markup{\left-align \small vib} a'16 e'16 f'16 g'16 f'16 fis'8.~^\markup{\left-align \small vib} fis'16 dis'16 d'16 c'16 
      | \tuplet 3/2 {b8 ais4^\markup{\left-align \small vib}} a16 g8^\markup{\left-align \small vib} d16 \tuplet 3/2 {fis8 ais8 f8} d16 e16 r8 
      | r4 \tuplet 6/4 {r16 cis''16 c''16 b'16 ais'8} \tuplet 5/4 {fis'16 a'16 g'16 f'16 d'16} e'8 cis'16 c'16~ 
      | \tuplet 5/4 {c'16 ais16 g16 gis16 a16~} a8 g'16 e'16 \tuplet 5/4 {f'4^\markup{\left-align \small vib} d'16~} d'16 ais16 g16 e16~ 
      | \tuplet 6/4 {e16 g16 e8 f16 a16} c'16 d'16 dis'16 f'16 g'4^\markup{\left-align \small vib} r4 
      | r8 f'8~ f'16 a'16 c''16 ais'16~ ais'32 f'16. dis'16. cis'32~ cis'16 ais16 f16 cis16 
      | c16. g16 e16 f32~ \tuplet 3/2 {f8 c'8 a8} \tuplet 3/2 {ais8 e8 gis8} c'4^\markup{\left-align \small vib} 
      | r4 \tuplet 3/2 {g8\glissando  a8 f'8~^\markup{\left-align \small vib}} f'8.. fis'32 f'16 d'16 e'16 c'16 
      \bar "||" g16 e16 g16 e16 f16 a16 c'8~^\markup{\left-align \small vib} c'4. b16\glissando  c'16 
      | cis'16. d'16 f'16 d'32~ \tuplet 3/2 {d'8 e'8 g'8} c''4.^\markup{\left-align \small vib} r8 
      | r4 \tuplet 6/4 {r16 d''16 cis''16 c''16 b'16 ais'16~^\markup{\left-align \small vib}} ais'4 g'16 fis'16 dis'16 cis'16 
      | \tuplet 6/4 {a16 fis8 dis16 cis16 c16~} c16 g16 e16 f16 d'8. a16 c'4^\markup{\left-align \small vib} 
      | r4 \tuplet 6/4 {g'8 dis'8 ais16 b16} \tuplet 3/2 {d'8 c'8 cis'8~} cis'16 a16 g16 dis16 
      | d8 f8 ais8 c'4 ais8 f4~^\markup{\left-align \small vib} 
      | f4 \tuplet 6/4 {gis16\glissando  a16 ais8 a16 f16~} \tuplet 3/2 {f8 d8 e8} g16 c'8 a16~ 
      | a8 f4^\markup{\left-align \small vib} r8 \tuplet 6/4 {r8. fis16\glissando  g16 a16~} \tuplet 6/4 {a16 ais8 ais16\glissando  b16 c'16~} 
      \bar "||" \tuplet 6/4 {c'16 a16 cis'16 a16 cis'16\glissando  d'16~} \tuplet 3/2 {d'8 dis'8 e'8} f'8 f8 gis4~^\markup{\left-align \small vib} 
      | gis4 fis16 g16 ais16 d'16 f'8 dis'8 fis4^\markup{\left-align \small vib} 
      | r4 r16 dis16\glissando  f16 e16 dis8 g8 \tuplet 3/2 {f'8 cis'8 a8~} 
      | a16 dis16 d16 f16~ \tuplet 3/2 {f8 a8\glissando  c'8} ais8 f4.~^\markup{\left-align \small vib} 
      | f8 ais'8~ \tuplet 6/4 {ais'16 dis'16 e'16 f'8 g'16~} g'16 gis'16. c''16 g'32~^\markup{\left-align \small vib} g'4 
      | \tuplet 3/2 {f'8 d'8 c'8} \tuplet 6/4 {g16\bendAfter #+4  gis16 g8 ais16 dis'16\glissando } \tuplet 3/2 {f'4 dis'8~} dis'8 fis8~^\markup{\left-align \small vib} 
      | fis4~ fis32 f16. ais32 d'16 dis'32~ \tuplet 7/8 {dis'32 d'16 c'16 ais32 g32~} g16 f8 e16~ 
      | e16 dis16 cis16 d16 ais4^\markup{\left-align \small vib} g16 gis16 c'16 dis'16 g'16 fis'16 r8 
      \bar "||" r4 dis'8\glissando  f'4.^\markup{\left-align \small vib} fis'16 a'16 c'8~^\markup{\left-align \small vib} 
      | c'4. dis'16 f'16~ \tuplet 6/4 {f'16 d'16 dis'16 e'16 dis'16 cis'16} d'16\glissando  dis'8 cis'16 
      | dis'16 c'8.~^\markup{\left-align \small vib} c'4. \tuplet 6/4 {ais8 c'16} gis8\glissando  a8~^\markup{\left-align \small vib} 
      | a4~ a16 g16 a16 c16~^\markup{\left-align \small vib} c4. g8 
      | e16 f16 a16 c'16 dis'16 g'16 dis'16. ais32 b16 cis'16 dis'16 gis'16 fis'16 dis'16 cis'16 b16 
      | fis16 e16 dis16 cis16 e16 g16 e16 f16 \tuplet 6/4 {a16 d'8 f'16 ais16 b16} \tuplet 3/2 {d'8 f'8 gis'8} 
      | r8.. a'32~ \tuplet 3/2 {a'8 ais'8 b'8} \tuplet 5/4 {c''8 cis'16\glissando  d'16 dis'16~} dis'16 e'16 f'8 
      | \tuplet 3/2 {fis'8 g'8 d'8} c'2^\markup{\left-align \small vib} gis8.\bendAfter #+4  c'16~^\markup{\left-align \small vib} 
      | c'2. r4\bar  ".."
    }
    >>
>>
}
